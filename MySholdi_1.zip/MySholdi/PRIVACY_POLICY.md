# MySholdi – Pravila privatnosti / Privacy Policy

_Zadnje ažuriranje / Last updated: 20. 11. 2026._

## Hrvatski

**MySholdi** je aplikacija za praćenje osobnih financija. Razvojni programer ne prikuplja, ne pohranjuje i ne dijeli tvoje osobne podatke.

* **Gdje su podaci:** sve tablice (prihodi, rashodi, neto imovina), postavke i koš za smeće spremaju se samo na tvom uređaju, u privatnoj mapi aplikacije.
* **Oblak:** ako sam odabereš mjesto spremanja (npr. Google Drive, Dropbox, OneDrive ili mapu na uređaju), aplikacija preko Androidovog sustavnog izbornika datoteka zapisuje datoteku na to mjesto, u **tvoj** račun. Razvojni programer nema pristup tim datotekama. Na njih se primjenjuju pravila privatnosti odabranog pružatelja usluge.
* **Bez analitike i oglasa:** aplikacija ne sadrži oglase, alate za praćenje ni analitiku i ne šalje podatke razvojnom programeru ni trećim stranama.
* **Dopuštenja:** *Internet* i *stanje mreže* služe samo za prepoznavanje dostupnosti veze za sinkronizaciju s mjestom koje si odabrao. *Obavijesti* služe samo za upozorenje kad spremanje u oblak ne uspije.
* **Brisanje podataka:** podatke brišeš u aplikaciji (brisanje tablice, pražnjenje koša za smeće) ili deinstalacijom aplikacije. Datoteke koje si spremio u oblak brišeš u tom servisu.
* **Djeca:** aplikacija nije namijenjena djeci mlađoj od 13 godina.
* **Promjene:** izmjene ovih pravila objavit će se na ovoj stranici.
* **Kontakt:** _[upiši svoj e-mail]_

## English

**MySholdi** is a personal finance app. The developer does not collect, store or share your personal data.

* **Where data is stored:** all sheets (income, expenses, net worth), settings and the trash are stored only on your device, in the app's private folder.
* **Cloud:** if you choose a save location (e.g. Google Drive, Dropbox, OneDrive or a device folder), the app writes a file there through Android's system file picker, into **your own** account. The developer has no access to these files; the chosen provider's privacy policy applies.
* **No analytics or ads:** the app contains no ads, trackers or analytics and sends no data to the developer or third parties.
* **Permissions:** *Internet* and *network state* are used only to detect connectivity for syncing to the location you chose; *notifications* only to warn you when a cloud save fails.
* **Deleting data:** delete data in the app (delete a sheet, empty the trash) or by uninstalling the app. Files you saved to a cloud service are deleted in that service.
* **Children:** the app is not directed at children under 13.
* **Changes:** updates to this policy will be published on this page.
* **Contact:** _[your e-mail]_
