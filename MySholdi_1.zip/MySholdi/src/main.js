// MySholdi – glavni modul: pokretanje, okvir aplikacije, izbornik, navigacija
import { App } from '@capacitor/app';
import { state } from './state.js';
import { t, setLang } from './i18n.js';
import { esc } from './util.js';
import { icon } from './icons.js';
import { loadAll, readBudget, saveSettings, writeBudget, saveMeta } from './storage.js';
import { normalizeBudget } from './model.js';
import { startSyncWatchers, onSyncChange, syncStatus, saveNow, checkRemote, metaOf, retryPending, flushLocal, cancelCloudTimer } from './sync.js';
import { purgeOld } from './trash.js';
import { sheet, closeTopSheet, sheetOpen, toast } from './ui.js';
import { app } from './app.js';
import { refreshWidgets } from './widgets.js';
import { consumeLaunchAction, onLaunchAction } from './native.js';
import { linkCreate } from './cloud.js';
import { renderBudget, mountBudget, budgetAction, budgetActions, resetEntriesShown } from './views/budget.js';
import { renderBudgets, budgetsAction } from './views/budgets.js';
import { renderSettings, mountSettings, settingsAction } from './views/settings.js';
import { renderLoan, mountLoan } from './views/loan.js';
import { renderTrash, trashAction } from './views/trash.js';
import { renderWidgets, mountWidgets, widgetsAction } from './views/widgetsView.js';

const root = document.getElementById('app');
const history = [];

const MENU = [
  ['budgets', 'table', 'menuBudgets'],
  ['widgets', 'widgets', 'menuWidgets'],
  ['settings', 'settings', 'menuSettings'],
  ['loan', 'calc', 'menuLoan'],
  ['trash', 'trash', 'menuTrash'],
];

function titleFor(route) {
  if (route === 'budget') return state.budget ? state.budget.name : '';
  return t({ budgets: 'menuBudgets', widgets: 'menuWidgets', settings: 'menuSettings', loan: 'menuLoan', trash: 'menuTrash' }[route]);
}

// Gumb za spremanje u traci – boja i ikona pokazuju status sinkronizacije
function saveButton() {
  if (state.ui.route !== 'budget' || !state.budget) return '';
  const st = syncStatus(state.budget.id);
  const ic = { synced: 'cloudOk', unsaved: 'save', failed: 'cloudOff', saving: 'cloud', local: 'save' }[st];
  return '<button class="icon-btn save-btn st-' + st + '" data-a="save" title="' + esc(t('st_' + st)) + '">' + icon(ic) + '</button>';
}

function render() {
  const r = state.ui.route;
  const content = { budget: renderBudget, budgets: renderBudgets, settings: renderSettings, loan: renderLoan, trash: renderTrash, widgets: renderWidgets }[r]();
  const activeName = state.budget ? state.budget.name : '';
  root.innerHTML =
    '<header class="appbar"><button class="icon-btn" data-a="drawer" aria-label="' + esc(t('menu')) + '">' + icon('menu') + '</button>' +
    '<h1 class="' + (r === 'budget' ? 'clickable' : '') + '" ' + (r === 'budget' ? 'data-a="switchBudget"' : '') + '>' + esc(titleFor(r)) + (r === 'budget' ? icon('down', 'tiny') : '') + '</h1>' +
    '<div class="appbar-actions">' + (r === 'budget' ? budgetActions() : '') + '<span id="save-slot">' + saveButton() + '</span></div></header>' +
    '<aside class="drawer ' + (state.ui.drawer ? 'open' : '') + '"><div class="drawer-head"><div class="logo">' + icon('wallet') + '</div><div><b>MySholdi</b><small>' + esc(activeName) + '</small></div></div>' +
    (state.budget ? '<button class="drawer-item budget-link ' + (r === 'budget' ? 'on' : '') + '" data-a="goBudget">' + icon('home') + '<span>' + esc(t('homePage')) + '</span></button><div class="drawer-sep"></div>' : '') +
    MENU.map(([k, ic, l]) => '<button class="drawer-item ' + (r === k ? 'on' : '') + '" data-go="' + k + '">' + icon(ic) + '<span>' + esc(t(l)) + '</span>' +
      (k === 'trash' && state.trash.length ? '<em>' + state.trash.length + '</em>' : '') + '</button>').join('') +
    '</aside><div class="drawer-bg ' + (state.ui.drawer ? 'open' : '') + '" data-a="drawer"></div>' +
    '<main class="view view-' + r + (r === 'budget' ? ' tab-' + state.ui.tab : '') + '">' + content + '</main>';
  const main = root.querySelector('main');
  if (r === 'budget') mountBudget(main);
  if (r === 'settings') mountSettings(main);
  if (r === 'loan') mountLoan(main, render);
  if (r === 'widgets') mountWidgets(main, render);
}

function go(route, { push = true } = {}) {
  if (push && state.ui.route !== route) history.push({ route: state.ui.route, tab: state.ui.tab });
  state.ui.route = route; state.ui.drawer = false;
  render(); window.scrollTo(0, 0);
}

async function openBudget(id, { tab = 'home' } = {}) {
  let b = state.budget && state.budget.id === id ? state.budget : await readBudget(id);
  if (!b) { toast(t('errOpen')); return; }
  b = normalizeBudget(b);
  if (state.budget && state.budget.id !== id) { flushLocal(); cancelCloudTimer(); }
  state.budget = b;
  state.settings.activeBudgetId = id; saveSettings();
  state.ui.tab = tab;
  state.ui.month = b.year === new Date().getFullYear() ? new Date().getMonth() : 0;
  resetEntriesShown();
  history.length = 0;
  go('budget', { push: false });
  refreshWidgets();
  remoteCheck(b);
}

// Ako je na oblaku novija verzija (izmjena s drugog uređaja) – ponudi učitavanje
async function remoteCheck(b) {
  const r = await checkRemote(b);
  if (!state.budget || state.budget.id !== b.id) return;
  if (r.status === 'newer') {
    state.budget = r.remote; await writeBudget(r.remote);
    metaOf(b.id).dirty = false; await saveMeta();
    toast(t('loadedNewer')); render(); refreshWidgets();
  } else if (r.status === 'conflict') {
    const ch = await sheet({
      title: t('conflictTitle'), body: '<p class="dlg-text">' + esc(t('conflictText')) + '</p>',
      actions: [{ label: t('keepLocal'), value: 'local' }, { label: t('loadCloud'), value: 'cloud', cls: 'primary' }],
    });
    if (ch === 'cloud') { state.budget = r.remote; await writeBudget(r.remote); const m = metaOf(b.id); m.dirty = false; m.pending = false; await saveMeta(); render(); }
    else if (ch === 'local') { await saveNow(state.budget); render(); }
  }
}

async function switchBudget() {
  const v = await sheet({
    title: t('switchBudget'), body: '', cls: 'menu-sheet',
    actions: state.index.map((x) => ({ label: x.name + ' (' + x.year + ')', value: x.id, cls: state.budget && x.id === state.budget.id ? 'primary' : '' }))
      .concat([{ label: t('manageBudgets'), value: '__manage' }]),
  });
  if (!v) return;
  if (v === '__manage') return go('budgets');
  openBudget(v);
}

async function onSave() {
  const b = state.budget;
  const m = metaOf(b.id);
  if (!m.link) {
    const ch = await sheet({
      title: t('saveWhereTitle'), body: '<p class="dlg-text">' + esc(t('saveWhereText')) + '</p>',
      actions: [{ label: t('onlyLocal'), value: 'local' }, { label: t('chooseLocation'), value: 'link', cls: 'primary' }],
    });
    if (ch === 'link') { await linkCreate(b); render(); return; }
    if (ch === 'local') { await saveNow(b); toast(t('savedLocal')); render(); }
    return;
  }
  const r = await saveNow(b);
  toast(r.ok ? t('syncOk') : t('syncFailShort'), { kind: r.ok ? '' : 'bad' });
}

// Globalni klikovi (delegacija)
root.addEventListener('click', async (e) => {
  const go_ = e.target.closest('[data-go]');
  if (go_) { history.length = 0; return go(go_.dataset.go); }
  const tab = e.target.closest('[data-tab]');
  if (tab) { state.ui.tab = tab.dataset.tab; render(); window.scrollTo(0, 0); return; }
  const el = e.target.closest('[data-a]');
  if (!el) return;
  const a = el.dataset.a, d = el.dataset;
  if (a === 'drawer') { state.ui.drawer = !state.ui.drawer; root.querySelector('.drawer').classList.toggle('open', state.ui.drawer); root.querySelector('.drawer-bg').classList.toggle('open', state.ui.drawer); return; }
  if (a === 'goBudget') { state.ui.drawer = false; return go('budget'); }
  if (a === 'save') return onSave();
  if (a === 'switchBudget') return switchBudget();
  try {
    const r = state.ui.route;
    if (r === 'budget') await budgetAction(a, d);
    else if (r === 'budgets') await budgetsAction(a, d);
    else if (r === 'settings') await settingsAction(a, d);
    else if (r === 'trash') await trashAction(a, d);
    else if (r === 'widgets') await widgetsAction(a, d);
  } catch (err) { console.error(err); toast(t('errGeneric') + ': ' + (err.message || err)); }
});

// Android tipka "natrag"
function onBack() {
  if (closeTopSheet()) return;
  if (state.ui.drawer) { state.ui.drawer = false; render(); return; }
  if (state.ui.route === 'budget' && state.ui.tab !== 'home') { state.ui.tab = 'home'; render(); return; }
  const prev = history.pop();
  if (prev) { state.ui.route = prev.route; state.ui.tab = prev.tab; render(); return; }
  if (state.ui.route !== 'budget' && state.budget) { go('budget', { push: false }); return; }
  App.minimizeApp().catch(() => {});
}

async function handleLaunch(action) {
  if (action !== 'quickadd') return;
  if (!state.budget) {
    const id = state.settings.widgets.quick.budgetId || state.settings.activeBudgetId;
    if (!id) return;
    await openBudget(id);
  } else if (state.ui.route !== 'budget' || state.ui.tab !== 'home') { state.ui.tab = 'home'; go('budget', { push: false }); }
  if (!sheetOpen()) budgetAction('quickAdd', {});
}

async function boot() {
  await loadAll();
  setLang(state.settings.lang);
  document.documentElement.lang = state.settings.lang;
  await purgeOld();
  app.rerender = () => { render(); };
  app.go = go;
  app.openBudget = openBudget;
  app.refreshWidgets = () => refreshWidgets();
  onSyncChange(() => {
    const slot = document.getElementById('save-slot'); if (slot) slot.innerHTML = saveButton();
    const ban = root.querySelector('.banner.warn');
    const failed = state.budget && syncStatus(state.budget.id) === 'failed';
    if (state.ui.route === 'budget' && (!!ban !== !!failed)) render();
    refreshWidgets();
  });
  startSyncWatchers();
  try { App.addListener('backButton', onBack); } catch (e) { }
  const id = state.settings.activeBudgetId;
  if (id && state.index.some((x) => x.id === id)) await openBudget(id);
  else go('budgets', { push: false });
  // akcije iz widgeta (npr. brzi unos) – tek nakon što je tablica otvorena
  onLaunchAction(handleLaunch);
  const la = await consumeLaunchAction();
  if (la) handleLaunch(la);
  retryPending();
  refreshWidgets();
  document.body.classList.add('ready');
}
boot().catch((e) => { console.error(e); root.innerHTML = '<p style="padding:20px">Error: ' + esc(e.message || e) + '</p>'; });
