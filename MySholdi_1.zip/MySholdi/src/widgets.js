// Widgeti za početni zaslon: iscrtavaju se u sliku (PNG) koju prikazuje nativni Android widget
import { state } from './state.js';
import { t } from './i18n.js';
import { money, monthName, fmtNum, debounce } from './util.js';
import { calcSide, calcNet, itemLabel } from './model.js';
import { drawBars, drawDonut, fillRound, PALETTE } from './charts.js';
import { readBudget } from './storage.js';
import { updateWidget, isNative } from './native.js';

export const WIDGET_KINDS = ['month', 'chart', 'quick'];
export const WIDGET_SIZE = { month: [340, 170], chart: [340, 170], quick: [340, 200] };
export const THEMES = ['light', 'dark', 'glass', 'accent'];
export const ACCENTS = ['#2563eb', '#16a34a', '#dc2626', '#7c3aed', '#d97706', '#0891b2', '#db2777', '#111827'];

function hexA(hex, a) {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16);
  return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
}
function palette(cfg) {
  const op = (cfg.opacity ?? 100) / 100;
  const P = {
    light: { bg: hexA('#ffffff', op), text: '#111827', mut: '#6b7280', inc: '#15803d', exp: '#dc2626', line: '#e5e7eb', track: '#eef0f3' },
    dark: { bg: hexA('#111827', op), text: '#f9fafb', mut: '#9ca3af', inc: '#4ade80', exp: '#f87171', line: '#374151', track: '#1f2937' },
    glass: { bg: hexA('#0f172a', 0.38 * op), text: '#ffffff', mut: 'rgba(255,255,255,.75)', inc: '#86efac', exp: '#fca5a5', line: 'rgba(255,255,255,.25)', track: 'rgba(255,255,255,.18)' },
    accent: { bg: hexA(cfg.accent || '#2563eb', op), text: '#ffffff', mut: 'rgba(255,255,255,.78)', inc: '#ffffff', exp: '#ffffff', line: 'rgba(255,255,255,.3)', track: 'rgba(255,255,255,.25)' },
  }[cfg.theme] || {};
  P.acc = cfg.theme === 'accent' ? '#ffffff' : cfg.accent || '#2563eb';
  return P;
}

// Iscrtavanje widgeta u canvas (scale = gustoća piksela)
export function renderWidget(kind, cfg, budget, scale = 3) {
  const [W, H] = WIDGET_SIZE[kind];
  const cv = document.createElement('canvas');
  cv.width = W * scale; cv.height = H * scale;
  const ctx = cv.getContext('2d');
  ctx.scale(scale, scale);
  const c = palette(cfg);
  const F = 'system-ui, -apple-system, Roboto, sans-serif';
  const pad = 16;
  ctx.fillStyle = c.bg; fillRound(ctx, 0, 0, W, H, cfg.radius ?? 28); ctx.fill();
  ctx.textBaseline = 'alphabetic';
  const text = (s, x, y, size, color, weight = 400, align = 'left', maxW) => {
    ctx.font = weight + ' ' + size + 'px ' + F; ctx.fillStyle = color; ctx.textAlign = align;
    let str = String(s);
    if (maxW) while (str.length > 2 && ctx.measureText(str).width > maxW) str = str.slice(0, -2) + '…';
    ctx.fillText(str, x, y);
  };
  if (!budget) {
    text('MySholdi', pad, pad + 16, 15, c.text, 700);
    text(t('widgetNoBudget'), pad, H / 2 + 8, 13, c.mut);
    return cv;
  }
  const m = budget.year === new Date().getFullYear() ? new Date().getMonth() : 11;
  const title = cfg.title || (kind === 'quick' ? 'MySholdi' : monthName(m) + ' ' + budget.year);

  if (kind === 'month') {
    const inc = calcSide(budget, 'income'), exp = calcSide(budget, 'expense');
    const I = inc.monthly[m], E = exp.monthly[m], D = I - E;
    text(title, pad, pad + 13, 13, c.mut, 600, 'left', W - pad * 2 - 40);
    text('MySholdi', W - pad, pad + 13, 10, c.mut, 500, 'right');
    const colW = (W - pad * 2) / (cfg.showDiff ? 3 : 2);
    const cell = (i, lbl, val, col) => {
      const x = pad + i * colW;
      text(lbl, x, pad + 46, 11, c.mut, 500);
      text(val, x, pad + 70, 18, col, 700, 'left', colW - 6);
    };
    cell(0, t('income'), money(I, { dec: 0 }), c.inc);
    cell(1, t('expenses'), money(E, { dec: 0 }), c.exp);
    if (cfg.showDiff) cell(2, t('difference'), money(D, { dec: 0, sign: true }), D < 0 ? c.exp : c.acc);
    const by = H - pad - 30, bw = W - pad * 2;
    ctx.fillStyle = c.track; fillRound(ctx, pad, by, bw, 8, 4); ctx.fill();
    const p = I ? Math.min(1, E / I) : (E ? 1 : 0);
    if (p > 0) { ctx.fillStyle = E > I ? c.exp : c.acc; fillRound(ctx, pad, by, Math.max(8, bw * p), 8, 4); ctx.fill(); }
    const sub = I ? t('spentOfIncome', { p: fmtNum(E / I * 100, 0) }) : '';
    text(sub, pad, H - pad - 4, 11, c.mut);
    if (cfg.showDaily) text(t('dailyAvg') + ' ' + money(exp.daily[m], { dec: 0 }), W - pad, H - pad - 4, 11, c.mut, 400, 'right');
  } else if (kind === 'chart') {
    const type = cfg.chart || 'months';
    const ttl = cfg.title || { months: t('incomeVsExpenses') + ' ' + budget.year, categories: t('expensesIn', { m: monthName(m) }), net: t('netWorth') }[type];
    text(ttl, pad, pad + 13, 13, c.text, 600, 'left', W - pad * 2);
    if (type === 'months') {
      const P = calcSide(budget, 'income').monthly, R = calcSide(budget, 'expense').monthly;
      drawBars(ctx, pad - 2, pad + 22, W - pad * 2 + 4, H - pad * 2 - 20, {
        labels: Array.from({ length: 12 }, (_, i) => monthName(i, true).slice(0, 1)),
        series: [{ values: P, color: c.inc }, { values: R, color: c.exp }],
      }, { text: c.mut, grid: c.line, zero: c.line, fontSize: 9, font: F, noAxis: true });
    } else if (type === 'categories') {
      const S = calcSide(budget, 'expense');
      const parts = budget.expense.map((g, i) => ({ n: g.name, v: S.groups[i].m[m] })).filter((x) => x.v > 0).sort((a, b) => b.v - a.v);
      const r = (H - pad * 2 - 22) / 2;
      const cx = pad + r, cy = pad + 22 + r;
      const cols = cfg.theme === 'accent' ? ['#ffffff', 'rgba(255,255,255,.75)', 'rgba(255,255,255,.5)', 'rgba(255,255,255,.3)', 'rgba(255,255,255,.18)'] : PALETTE;
      const top = parts.slice(0, 4), rest = parts.slice(4).reduce((s, x) => s + x.v, 0);
      const vals = top.map((x) => x.v).concat(rest ? [rest] : []);
      drawDonut(ctx, cx, cy, r, vals, cols, { empty: c.track, thickness: r * 0.34 });
      text(money(S.monthly[m], { dec: 0 }), cx, cy + 5, 13, c.text, 700, 'center', r * 1.3);
      const lx = cx + r + 16; let ly = pad + 40;
      top.concat(rest ? [{ n: t('other'), v: rest }] : []).forEach((x, i) => {
        ctx.fillStyle = cols[i % cols.length]; fillRound(ctx, lx, ly - 9, 10, 10, 3); ctx.fill();
        text(x.n, lx + 16, ly, 11, c.text, 500, 'left', W - lx - 16 - 64);
        text(money(x.v, { dec: 0 }), W - pad, ly, 11, c.mut, 500, 'right');
        ly += 21;
      });
      if (!parts.length) text(t('noData'), lx, pad + 60, 12, c.mut);
    } else {
      const N = calcNet(budget);
      drawBars(ctx, pad - 2, pad + 22, W - pad * 2 + 4, H - pad * 2 - 20, {
        labels: budget.net.periods.map((p) => p.slice(0, 3)), series: [{ values: N.net.map((x) => (isNaN(x) ? 0 : x)), color: c.acc }],
      }, { text: c.mut, grid: c.line, zero: c.line, fontSize: 10, font: F, noAxis: true });
      const last = [...N.net].reverse().find((x) => !isNaN(x));
      if (last !== undefined) text(money(last, { dec: 0 }), W - pad, pad + 13, 13, c.acc, 700, 'right');
    }
  } else if (kind === 'quick') {
    text(title, pad, pad + 16, 15, c.text, 700, 'left', W - pad * 2 - 50);
    // gumb "+"
    const bx = W - pad - 34, byy = pad - 4;
    ctx.fillStyle = cfg.theme === 'accent' ? 'rgba(255,255,255,.95)' : (cfg.accent || '#22c55e');
    fillRound(ctx, bx, byy, 34, 34, 17); ctx.fill();
    ctx.strokeStyle = cfg.theme === 'accent' ? (cfg.accent || '#2563eb') : '#ffffff'; ctx.lineWidth = 3; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(bx + 17, byy + 10); ctx.lineTo(bx + 17, byy + 24); ctx.moveTo(bx + 10, byy + 17); ctx.lineTo(bx + 24, byy + 17); ctx.stroke();
    const list = budget.entries.slice(0, cfg.count || 3);
    let y = pad + 48;
    if (!list.length) text(t('widgetTapToAdd'), pad, y + 10, 12, c.mut);
    list.forEach((e) => {
      const lbl = itemLabel(budget, e.type, e.gid, e.iid) || e.label;
      const short = String(lbl).split(' › ').pop();
      const isInc = e.type === 'income';
      ctx.strokeStyle = c.line; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(pad, y - 16); ctx.lineTo(W - pad, y - 16); ctx.stroke();
      text(short, pad, y, 12.5, c.text, 500, 'left', W - pad * 2 - 100);
      const d = new Date(e.ts);
      text(d.getDate() + '.' + (d.getMonth() + 1) + '. ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'), pad, y + 14, 10, c.mut);
      text(money(isInc ? e.amount : -e.amount, { sign: true }), W - pad, y + 4, 13, isInc ? c.inc : c.exp, 700, 'right');
      y += 38;
    });
  }
  return cv;
}

async function budgetFor(cfg) {
  const id = cfg.budgetId || state.settings.activeBudgetId;
  if (!id) return null;
  if (state.budget && state.budget.id === id) return state.budget;
  return readBudget(id);
}

// Osvježavanje svih widgeta na početnom zaslonu
async function doRefresh() {
  if (!isNative) return;
  for (const k of WIDGET_KINDS) {
    const cfg = state.settings.widgets[k];
    const b = await budgetFor(cfg);
    const cv = renderWidget(k, cfg, b, 3);
    await updateWidget(k, cv.toDataURL('image/png'));
  }
}
export const refreshWidgets = debounce(doRefresh, 1200);
export { budgetFor };
