// Most prema nativnom Android dijelu (datoteke preko Storage Access Frameworka, widgeti).
// U pregledniku se koristi zamjenska (web) izvedba – za razvoj i testiranje.
import { Capacitor, registerPlugin } from '@capacitor/core';

export const isNative = Capacitor.isNativePlatform();
const Native = registerPlugin('MySholdi');

// ----- Web zamjena: "oblak" se simulira u localStorage -----
const webStore = {
  get(k) { try { return localStorage.getItem('webdoc:' + k); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem('webdoc:' + k, v); } catch (e) { } },
};
function pickFileWeb() {
  return new Promise((resolve, reject) => {
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = '.json,application/json';
    inp.onchange = () => {
      const f = inp.files[0]; if (!f) return reject(new Error('cancelled'));
      const r = new FileReader();
      r.onload = () => resolve({ uri: 'webfile:' + f.name, name: f.name, data: r.result });
      r.onerror = () => reject(new Error('read'));
      r.readAsText(f);
    };
    inp.click();
  });
}
function downloadWeb(name, data) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([data], { type: 'application/json' }));
  a.download = name; document.body.appendChild(a); a.click(); a.remove();
}

// Odabir mjesta za novu datoteku (Google Drive, Dropbox, lokalna mapa…)
export async function createDocument(fileName) {
  if (isNative) return Native.createDocument({ fileName });
  return { uri: 'web:' + fileName, name: fileName };
}
// Otvaranje postojeće datoteke
export async function openDocument() {
  if (isNative) return Native.openDocument();
  return pickFileWeb();
}
export async function writeDocument(uri, data) {
  if (isNative) return Native.writeDocument({ uri, data });
  if (window.__mockCloudFail) throw new Error('offline');
  webStore.set(uri, data);
  return { ok: true };
}
export async function readDocument(uri) {
  if (isNative) return (await Native.readDocument({ uri })).data;
  if (window.__mockCloudFail) throw new Error('offline');
  const d = webStore.get(uri);
  if (d === null) throw new Error('notfound');
  return d;
}
export async function releaseDocument(uri) {
  if (isNative) { try { await Native.releaseDocument({ uri }); } catch (e) { } }
}
// Jednokratni izvoz kopije (bez povezivanja)
export async function exportCopy(fileName, data) {
  if (isNative) { const r = await Native.createDocument({ fileName }); await Native.writeDocument({ uri: r.uri, data }); return r; }
  downloadWeb(fileName, data); return { name: fileName };
}

// ----- Widgeti -----
export async function updateWidget(kind, pngDataUrl) {
  if (!isNative) return;
  try { await Native.updateWidget({ kind, png: pngDataUrl.split(',')[1] }); } catch (e) { console.warn('widget', e); }
}
export async function pinWidget(kind) {
  if (!isNative) return { supported: false, web: true };
  return Native.pinWidget({ kind });
}
export async function getInfo() {
  if (!isNative) return { filesDir: '(preglednik) IndexedDB / localStorage', pinSupported: false };
  try { return await Native.getInfo(); } catch (e) { return { filesDir: '?', pinSupported: false }; }
}
// Akcija s kojom je aplikacija pokrenuta (npr. "quickadd" iz widgeta)
export async function consumeLaunchAction() {
  if (!isNative) return null;
  try { return (await Native.consumeLaunchAction()).action || null; } catch (e) { return null; }
}
export function onLaunchAction(cb) {
  if (isNative) Native.addListener('launchAction', (d) => cb(d.action));
}
