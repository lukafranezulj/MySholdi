// Spremanje: odmah lokalno, a u oblak (povezanu datoteku) ručno ili automatski 5 s nakon zadnje izmjene.
// Ako spremanje u oblak ne uspije, podaci ostaju lokalno i ponovno se šalju kad se steknu uvjeti.
import { LocalNotifications } from '@capacitor/local-notifications';
import { Network } from '@capacitor/network';
import { App } from '@capacitor/app';
import { state } from './state.js';
import { writeBudget, readBudget, saveMeta } from './storage.js';
import { writeDocument, readDocument, isNative } from './native.js';
import { debounce } from './util.js';
import { touch, normalizeBudget } from './model.js';
import { t } from './i18n.js';

const listeners = new Set();
export const onSyncChange = (fn) => listeners.add(fn);
const emit = () => listeners.forEach((fn) => { try { fn(); } catch (e) { console.error(e); } });

export const AUTOSAVE_MS = 5000;
let cloudTimer = null;
let pushing = new Set();

export function metaOf(id) {
  if (!state.meta[id]) state.meta[id] = { link: null, pending: false, dirty: false, lastCloudAt: 0, lastError: '' };
  return state.meta[id];
}
export function syncStatus(id) {
  const m = metaOf(id);
  if (pushing.has(id)) return 'saving';
  if (!m.link) return m.dirty ? 'local' : 'local';
  if (m.pending) return 'failed';
  if (m.dirty) return 'unsaved';
  return 'synced';
}

// Lokalni zapis s malom odgodom (da ne pišemo na disk pri svakom znaku)
const writeLocal = debounce(async (b) => {
  try { await writeBudget(b); } catch (e) { console.error('local save', e); }
}, 350);

// Pozvati nakon svake izmjene otvorene tablice
export function persist(b = state.budget) {
  if (!b) return;
  touch(b);
  writeLocal(b);
  const m = metaOf(b.id);
  m.dirty = true;
  saveMeta();
  clearTimeout(cloudTimer);
  if (state.settings.autosave && m.link) {
    cloudTimer = setTimeout(() => { cloudTimer = null; pushCloud(b.id); }, AUTOSAVE_MS);
  }
  emit();
}

// Tipka "Spremi"
export async function saveNow(b = state.budget) {
  if (!b) return { ok: false };
  clearTimeout(cloudTimer);
  writeLocal.flush(b);
  const m = metaOf(b.id);
  if (!m.link) { m.dirty = false; await saveMeta(); emit(); return { ok: true, local: true }; }
  return pushCloud(b.id);
}

export async function pushCloud(id) {
  const m = metaOf(id);
  if (!m.link || pushing.has(id)) return { ok: false };
  pushing.add(id); emit();
  try {
    const b = state.budget && state.budget.id === id ? state.budget : await readBudget(id);
    if (!b) throw new Error('no local');
    if (state.budget && state.budget.id === id) writeLocal.flush(b);
    await writeDocument(m.link.uri, JSON.stringify(b, null, 1));
    m.pending = false; m.dirty = false; m.lastCloudAt = Date.now(); m.lastError = ''; m.failNotified = false;
    return { ok: true };
  } catch (e) {
    m.pending = true; m.lastError = String(e && (e.message || e));
    notifyFailure(id);
    return { ok: false, error: m.lastError };
  } finally {
    pushing.delete(id);
    await saveMeta();
    emit();
  }
}

async function notifyFailure(id) {
  const m = metaOf(id);
  if (!state.settings.notifyFailures || m.failNotified) return;
  m.failNotified = true;
  if (!isNative) return;
  try {
    let p = await LocalNotifications.checkPermissions();
    if (p.display !== 'granted') p = await LocalNotifications.requestPermissions();
    if (p.display !== 'granted') return;
    const name = (state.index.find((x) => x.id === id) || {}).name || '';
    await LocalNotifications.schedule({ notifications: [{ id: 1001, title: t('syncFailTitle'), body: t('syncFailBody', { name }) }] });
  } catch (e) { /* obavijesti nisu dostupne */ }
}

// Ponovni pokušaj za sve tablice koje čekaju slanje u oblak
export async function retryPending() {
  for (const id of Object.keys(state.meta)) {
    const m = state.meta[id];
    if (m.link && (m.pending || (m.dirty && state.settings.autosave && !(state.budget && state.budget.id === id && cloudTimer)))) {
      if (!state.index.find((x) => x.id === id)) continue;
      const r = await pushCloud(id);
      if (r.ok && isNative) { try { await LocalNotifications.cancel({ notifications: [{ id: 1001 }] }); } catch (e) { } }
    }
  }
}

// Provjera ima li u oblaku novija verzija (npr. izmijenjena na drugom mobitelu)
export async function checkRemote(b) {
  const m = metaOf(b.id);
  if (!m.link) return { status: 'nolink' };
  try {
    const remote = normalizeBudget(JSON.parse(await readDocument(m.link.uri)));
    if (remote.id !== b.id) return { status: 'other', remote };
    if (remote.updatedAt > b.updatedAt + 1000) {
      return { status: (m.dirty || m.pending) ? 'conflict' : 'newer', remote };
    }
    return { status: 'same' };
  } catch (e) { return { status: 'error', error: String(e.message || e) }; }
}

export function startSyncWatchers() {
  try {
    Network.addListener('networkStatusChange', (s) => { if (s.connected) retryPending(); });
  } catch (e) { }
  window.addEventListener('online', () => retryPending());
  try { App.addListener('resume', () => retryPending()); } catch (e) { }
  try {
    App.addListener('pause', () => {
      if (!state.budget) return;
      writeLocal.flush(state.budget);
      // ako je autospremanje čekalo, pošalji odmah prije nego sustav uspava aplikaciju
      if (cloudTimer) { clearTimeout(cloudTimer); cloudTimer = null; pushCloud(state.budget.id); }
    });
  } catch (e) { }
  setInterval(() => { if (Object.values(state.meta).some((m) => m.pending)) retryPending(); }, 30000);
}
export function flushLocal() { if (state.budget) writeLocal.flush(state.budget); }
export function cancelCloudTimer() { clearTimeout(cloudTimer); cloudTimer = null; }
