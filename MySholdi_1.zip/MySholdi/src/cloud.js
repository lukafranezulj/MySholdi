// Povezivanje tablica s datotekama u oblaku (Google Drive, Dropbox, OneDrive) ili lokalno
import { state } from './state.js';
import { createDocument, openDocument, writeDocument, releaseDocument, exportCopy } from './native.js';
import { writeBudget, saveMeta } from './storage.js';
import { metaOf, pushCloud } from './sync.js';
import { normalizeBudget, fromLegacy, FORMAT } from './model.js';
import { sheet, toast } from './ui.js';
import { t } from './i18n.js';
import { esc, uid } from './util.js';

// Prepoznavanje pružatelja iz URI-ja (content://<authority>/...)
export function providerOf(uri) {
  const u = String(uri || '');
  if (u.startsWith('web:')) return t('provWeb');
  if (/com\.google\.android\.apps\.docs/.test(u)) return 'Google Drive';
  if (/dropbox/i.test(u)) return 'Dropbox';
  if (/skydrive|onedrive/i.test(u)) return 'OneDrive';
  if (/nextcloud|owncloud/i.test(u)) return 'Nextcloud';
  if (/mega/i.test(u)) return 'MEGA';
  if (/externalstorage/.test(u)) return t('provLocal');
  if (/providers\.downloads/.test(u)) return t('provDownloads');
  return t('provOther');
}
export const fileNameFor = (b) => ('MySholdi - ' + b.name).replace(/[\\/:*?"<>|]/g, '_') + '.json';

// Stvaranje nove datoteke na odabranom mjestu i povezivanje
export async function linkCreate(b) {
  try {
    const r = await createDocument(fileNameFor(b));
    if (!r || !r.uri) return false;
    const m = metaOf(b.id);
    if (m.link && m.link.uri !== r.uri) releaseDocument(m.link.uri);
    m.link = { uri: r.uri, name: r.name || fileNameFor(b), provider: providerOf(r.uri) };
    m.dirty = true; await saveMeta();
    const res = await pushCloud(b.id);
    toast(res.ok ? t('linkedOk', { p: m.link.provider }) : t('syncFailShort'));
    return true;
  } catch (e) {
    if (!/cancel/i.test(String(e && e.message))) toast(t('errFile') + ': ' + (e.message || e));
    return false;
  }
}
export async function unlink(id) {
  const m = metaOf(id);
  if (m.link) releaseDocument(m.link.uri);
  m.link = null; m.pending = false; m.dirty = false;
  await saveMeta();
}

// Učitavanje tablice iz datoteke (npr. na novom mobitelu)
export async function importFromFile() {
  let r;
  try { r = await openDocument(); } catch (e) { if (!/cancel/i.test(String(e && e.message))) toast(t('errFile')); return null; }
  if (!r) return null;
  let data;
  try { data = JSON.parse(r.data); } catch (e) { toast(t('errNotBudget')); return null; }
  let b, legacy = false;
  try {
    if (data && data.prihodi && data.rashodi && data.imovina) { legacy = true; b = fromLegacy(data, (r.name || 'Tablica').replace(/\.json$/i, '')); }
    else b = normalizeBudget(data);
  } catch (e) { toast(t('errNotBudget')); return null; }

  const existing = state.index.find((x) => x.id === b.id);
  if (existing) {
    const ch = await sheet({
      title: t('importExistsTitle'),
      body: '<p class="dlg-text">' + esc(t('importExists', { n: existing.name })) + '</p>',
      actions: [{ label: t('cancel'), value: null }, { label: t('keepBoth'), value: 'both' }, { label: t('replace'), value: 'replace', cls: 'primary' }],
    });
    if (!ch) return null;
    if (ch === 'both') { b.id = uid('b'); legacy = true; }
  }
  // jedinstveno ime
  let name = b.name, n = 2;
  while (state.index.some((x) => x.id !== b.id && x.name.toLowerCase() === name.toLowerCase())) name = b.name + ' (' + n++ + ')';
  b.name = name;
  await writeBudget(b);
  const m = metaOf(b.id);
  // datoteka MySholdi formata postaje mjesto sinkronizacije (ako nije kopija)
  if (!legacy && data.format === FORMAT && !String(r.uri).startsWith('webfile:')) {
    m.link = { uri: r.uri, name: r.name, provider: providerOf(r.uri) };
    m.pending = false; m.dirty = false; m.lastCloudAt = Date.now();
  }
  await saveMeta();
  toast(t('imported', { n: b.name }));
  return b;
}

export async function exportBudget(b) {
  try { await exportCopy(fileNameFor(b), JSON.stringify(b, null, 1)); toast(t('exported')); }
  catch (e) { if (!/cancel/i.test(String(e && e.message))) toast(t('errFile')); }
}
