// Lokalna pohrana u mapi aplikacije (Directory.Data/MySholdi)
import { Filesystem, Directory, Encoding } from '@capacitor/filesystem';
import { state, DEFAULT_SETTINGS } from './state.js';
import { clone } from './util.js';

const ROOT = 'MySholdi';
const opts = (path) => ({ path: ROOT + '/' + path, directory: Directory.Data });

async function readJSON(path, fallback) {
  try {
    const r = await Filesystem.readFile({ ...opts(path), encoding: Encoding.UTF8 });
    return JSON.parse(typeof r.data === 'string' ? r.data : await r.data.text());
  } catch (e) { return fallback; }
}
async function writeJSON(path, obj) {
  await Filesystem.writeFile({ ...opts(path), data: JSON.stringify(obj), encoding: Encoding.UTF8, recursive: true });
}

// Spajanje spremljenih postavki sa zadanima (nove opcije dobiju zadane vrijednosti)
function mergeDeep(def, saved) {
  if (typeof def !== 'object' || def === null || Array.isArray(def)) return saved === undefined ? def : saved;
  const out = {};
  for (const k of Object.keys(def)) out[k] = mergeDeep(def[k], saved ? saved[k] : undefined);
  if (saved) for (const k of Object.keys(saved)) if (!(k in out)) out[k] = saved[k];
  return out;
}

export async function loadAll() {
  state.settings = mergeDeep(clone(DEFAULT_SETTINGS), await readJSON('settings.json', null));
  state.index = await readJSON('index.json', []);
  state.meta = await readJSON('meta.json', {});
  state.trash = await readJSON('trash.json', []);
}
export const saveSettings = () => writeJSON('settings.json', state.settings);
export const saveIndex = () => writeJSON('index.json', state.index);
export const saveMeta = () => writeJSON('meta.json', state.meta);
export const saveTrash = () => writeJSON('trash.json', state.trash);

export async function readBudget(id) { return readJSON('budgets/' + id + '.json', null); }
export async function writeBudget(b) {
  await writeJSON('budgets/' + b.id + '.json', b);
  const i = state.index.findIndex((x) => x.id === b.id);
  const entry = { id: b.id, name: b.name, year: b.year, updatedAt: b.updatedAt };
  if (i >= 0) state.index[i] = entry; else state.index.push(entry);
  await saveIndex();
}
export async function deleteBudgetFile(id) {
  try { await Filesystem.deleteFile(opts('budgets/' + id + '.json')); } catch (e) { }
  state.index = state.index.filter((x) => x.id !== id);
  await saveIndex();
}
export async function appFolderUri() {
  try { return (await Filesystem.getUri(opts(''))).uri; } catch (e) { return null; }
}
