// Popis proračunskih tablica: nova, otvori, preimenuj, poveži s oblakom, izvezi, obriši
import { state } from '../state.js';
import { t } from '../i18n.js';
import { esc, fmtDateTime, uid, clone } from '../util.js';
import { icon } from '../icons.js';
import { newBudget, defaultBudgetName, normalizeBudget } from '../model.js';
import { writeBudget, readBudget, deleteBudgetFile, saveSettings, saveMeta } from '../storage.js';
import { syncStatus, metaOf, saveNow, persist } from '../sync.js';
import { sheet, confirmDlg, promptDlg, toast } from '../ui.js';
import { toTrash } from '../trash.js';
import { linkCreate, unlink, importFromFile, exportBudget } from '../cloud.js';
import { app } from '../app.js';

export function nameError(name, exceptId) {
  if (!name) return t('errEmpty');
  if (state.index.some((x) => x.id !== exceptId && x.name.trim().toLowerCase() === name.trim().toLowerCase())) return t('errNameTaken');
  return '';
}
export function statusBadge(id) {
  const st = syncStatus(id), m = metaOf(id);
  const map = { synced: ['cloudOk', 'ok'], unsaved: ['cloud', 'warn'], failed: ['cloudOff', 'bad'], saving: ['cloud', 'warn'], local: ['folder', ''] };
  const [ic, cls] = map[st];
  return '<span class="badge ' + cls + '">' + icon(ic) + esc(st === 'local' ? t('localOnly') : (m.link ? m.link.provider : '') + ' · ' + t('st_' + st)) + '</span>';
}

export function renderBudgets() {
  const list = [...state.index].sort((a, b) => b.updatedAt - a.updatedAt);
  if (!list.length) {
    return '<div class="welcome"><div class="logo-big">' + icon('wallet') + '</div><h2>' + esc(t('welcomeTitle')) + '</h2><p class="muted">' + esc(t('welcomeText')) + '</p>' +
      '<button class="btn primary block" data-a="newBudget">' + icon('plus') + esc(t('newBudget')) + '</button>' +
      '<button class="btn block" data-a="importBudget">' + icon('download') + esc(t('loadFromFile')) + '</button>' +
      '<p class="muted small">' + esc(t('loadHint')) + '</p></div>';
  }
  return '<div class="list-actions"><button class="btn primary" data-a="newBudget">' + icon('plus') + esc(t('newBudget')) + '</button>' +
    '<button class="btn" data-a="importBudget">' + icon('download') + esc(t('loadFromFile')) + '</button></div>' +
    list.map((x) => '<div class="card budget-card ' + (state.settings.activeBudgetId === x.id ? 'active' : '') + '">' +
      '<div class="bc-main" data-a="openBudget" data-id="' + x.id + '"><div class="bc-ic">' + icon('table') + '</div><div><b>' + esc(x.name) + '</b>' +
      '<small>' + esc(t('year')) + ' ' + x.year + ' · ' + esc(t('updated')) + ' ' + esc(fmtDateTime(x.updatedAt)) + '</small>' + statusBadge(x.id) + '</div></div>' +
      '<button class="icon-btn" data-a="budgetMenu" data-id="' + x.id + '">' + icon('more') + '</button></div>').join('') +
    '<p class="muted small center">' + esc(t('budgetsHint')) + '</p>';
}

async function createBudget() {
  const y = new Date().getFullYear();
  const r = await sheet({
    title: t('newBudget'),
    body: '<label class="fld-label">' + esc(t('budgetName')) + '</label><input class="fld" id="nb-name" value="' + esc(uniqueDefault()) + '">' +
      '<label class="fld-label">' + esc(t('year')) + '</label><input class="fld" id="nb-year" type="number" value="' + y + '">' +
      '<label class="fld-label">' + esc(t('categories')) + '</label><select class="fld" id="nb-tpl"><option value="default">' + esc(t('tplDefault')) + '</option>' +
      '<option value="blank">' + esc(t('tplBlank')) + '</option>' +
      state.index.map((x) => '<option value="copy:' + x.id + '">' + esc(t('tplCopy', { n: x.name })) + '</option>').join('') + '</select>' +
      '<div class="fld-err" id="nb-err"></div>',
    actions: [{ label: t('cancel'), value: null }, { label: t('create'), value: 'ok', cls: 'primary' }],
    onAction: (v, el) => {
      if (v !== 'ok') return null;
      const name = el.querySelector('#nb-name').value.trim();
      const err = nameError(name);
      if (err) { el.querySelector('#nb-err').textContent = err; return false; }
      return { name, year: +el.querySelector('#nb-year').value || y, tpl: el.querySelector('#nb-tpl').value };
    },
  });
  if (!r) return;
  let b;
  if (r.tpl.startsWith('copy:')) {
    const src = await readBudget(r.tpl.slice(5));
    b = normalizeBudget(clone(src));
    b.id = uid('b'); b.name = r.name; b.year = r.year; b.entries = []; b.createdAt = Date.now();
    // kopiraju se kategorije bez iznosa; neto imovina prenosi zadnje stanje
    [...b.income, ...b.expense].forEach((g) => g.items.forEach((it) => { it.vals = Array(12).fill(null); }));
    ['assets', 'liabilities'].forEach((s) => b.net[s].forEach((row) => { const last = [...row.vals].reverse().find((v) => v !== null); row.vals = row.vals.map((_, i) => (i === 0 && last !== undefined ? last : null)); }));
  } else b = newBudget(r.name, r.year, r.tpl === 'blank');
  await writeBudget(b);
  toast(t('created', { n: b.name }));
  await app.openBudget(b.id);
}
function uniqueDefault() {
  const base = defaultBudgetName() + ' ' + new Date().getFullYear();
  let n = base, i = 2;
  while (nameError(n)) n = base + ' (' + i++ + ')';
  return n;
}

async function loadBudgetObj(id) {
  if (state.budget && state.budget.id === id) return state.budget;
  return readBudget(id);
}

async function budgetMenu(id) {
  const x = state.index.find((i) => i.id === id); if (!x) return;
  const m = metaOf(id);
  const acts = [
    { label: t('open'), value: 'open' },
    { label: t('rename'), value: 'rename' },
    { label: t('changeYear'), value: 'year' },
    { label: m.link ? t('changeLocation') : t('linkCloud'), value: 'link' },
  ];
  if (m.link) acts.push({ label: t('saveNow'), value: 'save' }, { label: t('unlink'), value: 'unlink' });
  acts.push({ label: t('exportCopy'), value: 'export' }, { label: t('delete'), value: 'delete', cls: 'danger' });
  const v = await sheet({ title: x.name, body: '<div class="menu-list"></div>', actions: acts, cls: 'menu-sheet' });
  if (!v) return;
  if (v === 'open') return app.openBudget(id);
  const b = await loadBudgetObj(id);
  if (v === 'rename') {
    const n = await promptDlg(t('rename'), b.name, { label: t('budgetName'), validate: (s) => nameError(s, id) });
    if (n === null) return;
    b.name = n; await saveBudgetObj(b);
  } else if (v === 'year') {
    const n = await promptDlg(t('changeYear'), String(b.year), { validate: (s) => (+s > 1900 && +s < 3000 ? '' : t('errYear')) });
    if (n === null) return;
    b.year = +n; await saveBudgetObj(b);
  } else if (v === 'link') { await linkCreate(b); }
  else if (v === 'save') { await saveNow(b); }
  else if (v === 'unlink') { if (await confirmDlg(t('unlinkQ'))) await unlink(id); }
  else if (v === 'export') { await exportBudget(b); }
  else if (v === 'delete') {
    if (!(await confirmDlg(t('delBudgetQ', { n: b.name }), { ok: t('delete'), danger: true }))) return;
    await toTrash('budget', b.name, b, { meta: m.link ? { link: m.link } : null });
    await deleteBudgetFile(id);
    delete state.meta[id]; await saveMeta();
    if (state.settings.activeBudgetId === id) { state.settings.activeBudgetId = null; await saveSettings(); }
    if (state.budget && state.budget.id === id) state.budget = null;
    toast(t('movedToTrash'));
  }
  app.rerender();
}
async function saveBudgetObj(b) {
  if (state.budget && state.budget.id === b.id) persist(b);
  else { b.updatedAt = Date.now(); await writeBudget(b); metaOf(b.id).dirty = true; await saveMeta(); }
}

export async function budgetsAction(a, d) {
  if (a === 'newBudget') return createBudget();
  if (a === 'importBudget') { const b = await importFromFile(); if (b) await app.openBudget(b.id); return; }
  if (a === 'openBudget') return app.openBudget(d.id);
  if (a === 'budgetMenu') return budgetMenu(d.id);
}
