// Postavke: jezik, valuta, spremanje i sinkronizacija, mjesta pohrane
import { state } from '../state.js';
import { t, setLang } from '../i18n.js';
import { esc, fmtDateTime } from '../util.js';
import { icon } from '../icons.js';
import { saveSettings, appFolderUri } from '../storage.js';
import { metaOf, saveNow, syncStatus, retryPending } from '../sync.js';
import { getInfo, isNative } from '../native.js';
import { linkCreate, unlink, importFromFile } from '../cloud.js';
import { readBudget } from '../storage.js';
import { confirmDlg, toast } from '../ui.js';
import { statusBadge } from './budgets.js';
import { app } from '../app.js';

const CURRENCIES = ['EUR', 'USD', 'GBP', 'CHF', 'BAM', 'RSD', 'HUF', 'PLN', 'CZK', 'SEK', 'NOK', 'DKK', 'CAD', 'AUD', 'JPY'];
let folder = null;

export function renderSettings() {
  const s = state.settings;
  const custom = !CURRENCIES.includes(s.currency);
  const tog = (k, lbl, hint) => '<label class="set-row toggle"><div><b>' + esc(t(lbl)) + '</b>' + (hint ? '<small>' + esc(t(hint)) + '</small>' : '') + '</div>' +
    '<input type="checkbox" data-set="' + k + '"' + (s[k] ? ' checked' : '') + '><span class="sw"></span></label>';
  return '<h4 class="sec-title">' + esc(t('general')) + '</h4><div class="card">' +
    '<div class="set-row"><div><b>' + esc(t('language')) + '</b></div><div class="seg sm" id="set-lang">' +
    '<button data-v="hr" class="' + (s.lang === 'hr' ? 'on' : '') + '">Hrvatski</button><button data-v="en" class="' + (s.lang === 'en' ? 'on' : '') + '">English</button></div></div>' +
    '<div class="set-row"><div><b>' + esc(t('currency')) + '</b><small>' + esc(t('currencyHint')) + '</small></div><div class="cur-pick">' +
    '<select class="fld sm" id="set-cur">' + CURRENCIES.map((c) => '<option' + (c === s.currency ? ' selected' : '') + '>' + c + '</option>').join('') +
    '<option value="__custom"' + (custom ? ' selected' : '') + '>' + esc(t('customCurrency')) + '</option></select>' +
    '<input class="fld sm" id="set-cur-custom" maxlength="8" placeholder="KM" value="' + esc(custom ? s.currency : '') + '"' + (custom ? '' : ' hidden') + '></div></div></div>' +

    '<h4 class="sec-title">' + esc(t('saving')) + '</h4><div class="card">' +
    tog('autosave', 'autosave', 'autosaveHint') + tog('notifyFailures', 'notifyFailures', 'notifyFailuresHint') + '</div>' +

    '<h4 class="sec-title">' + esc(t('storage')) + '</h4><div class="card">' +
    '<div class="set-row col"><div class="st-ic">' + icon('folder') + '</div><div><b>' + esc(t('appFolder')) + '</b><small class="mono" id="app-folder">' + esc(folder || '…') + '</small>' +
    '<small>' + esc(t('appFolderHint')) + '</small></div></div>' +
    '<div class="set-row col"><div class="st-ic">' + icon('cloud') + '</div><div><b>' + esc(t('cloudAndLocal')) + '</b><small>' + esc(t('cloudHint')) + '</small></div></div>' +
    state.index.map((x) => {
      const m = metaOf(x.id);
      return '<div class="store-row"><div class="grow"><b>' + esc(x.name) + '</b>' + statusBadge(x.id) +
        (m.link ? '<small class="mono">' + esc(m.link.name || '') + '</small>' : '') +
        (m.lastCloudAt ? '<small>' + esc(t('lastCloudSave')) + ': ' + esc(fmtDateTime(m.lastCloudAt)) + '</small>' : '') +
        (m.pending && m.lastError ? '<small class="bad">' + esc(m.lastError) + '</small>' : '') + '</div>' +
        '<div class="store-btns">' +
        '<button class="btn small" data-a="setLink" data-id="' + x.id + '">' + icon('link') + esc(t(m.link ? 'changeLocation' : 'linkCloud')) + '</button>' +
        (m.link ? '<button class="btn small" data-a="setSave" data-id="' + x.id + '">' + icon('upload') + esc(t('saveNow')) + '</button>' +
          '<button class="btn small ghost" data-a="setUnlink" data-id="' + x.id + '">' + icon('unlink') + esc(t('unlink')) + '</button>' : '') +
        '</div></div>';
    }).join('') +
    '<div class="store-row"><button class="btn block" data-a="setImport">' + icon('download') + esc(t('loadFromFile')) + '</button></div>' +
    (Object.values(state.meta).some((m) => m.pending) ? '<div class="store-row"><button class="btn block primary" data-a="setRetry">' + icon('restore') + esc(t('retryAll')) + '</button></div>' : '') +
    '</div>' +
    '<h4 class="sec-title">' + esc(t('about')) + '</h4><div class="card"><div class="set-row"><div><b>MySholdi</b><small>' + esc(t('version')) + ' 1.0.0 · ' + (isNative ? 'Android' : 'Web') + '</small><small>' + esc(t('aboutText')) + '</small></div></div></div>';
}

export function mountSettings(root) {
  if (!folder) {
    Promise.all([appFolderUri(), getInfo()]).then(([uri, info]) => {
      folder = (isNative && info.filesDir ? info.filesDir + '/MySholdi' : uri) || info.filesDir;
      const el = document.getElementById('app-folder'); if (el) el.textContent = folder;
    });
  }
  root.querySelector('#set-lang').onclick = async (e) => {
    const b = e.target.closest('button'); if (!b) return;
    state.settings.lang = b.dataset.v; setLang(b.dataset.v); await saveSettings(); app.rerender(); app.refreshWidgets();
  };
  const cur = root.querySelector('#set-cur'), cc = root.querySelector('#set-cur-custom');
  cur.onchange = async () => {
    if (cur.value === '__custom') { cc.hidden = false; cc.focus(); return; }
    cc.hidden = true; state.settings.currency = cur.value; await saveSettings(); app.refreshWidgets(); toast(t('saved'));
  };
  cc.onchange = async () => { const v = cc.value.trim(); if (!v) return; state.settings.currency = v; await saveSettings(); app.refreshWidgets(); toast(t('saved')); };
  root.querySelectorAll('[data-set]').forEach((c) => c.onchange = async () => { state.settings[c.dataset.set] = c.checked; await saveSettings(); });
}

export async function settingsAction(a, d) {
  if (a === 'setImport') { const b = await importFromFile(); if (b) await app.openBudget(b.id); return; }
  if (a === 'setRetry') { await retryPending(); toast(Object.values(state.meta).some((m) => m.pending) ? t('syncFailShort') : t('syncOk')); return app.rerender(); }
  const b = state.budget && state.budget.id === d.id ? state.budget : await readBudget(d.id);
  if (!b) return;
  if (a === 'setLink') await linkCreate(b);
  else if (a === 'setSave') { const r = await saveNow(b); toast(t(r.ok ? 'syncOk' : 'syncFailShort')); }
  else if (a === 'setUnlink') { if (await confirmDlg(t('unlinkQ'))) await unlink(d.id); }
  app.rerender();
  void syncStatus;
}
