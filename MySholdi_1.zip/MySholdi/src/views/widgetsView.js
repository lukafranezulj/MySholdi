// Ekran "Widgets": dizajn izgleda i dodavanje na početni zaslon
import { state } from '../state.js';
import { t } from '../i18n.js';
import { esc } from '../util.js';
import { icon } from '../icons.js';
import { renderWidget, WIDGET_KINDS, WIDGET_SIZE, THEMES, ACCENTS, budgetFor, refreshWidgets } from '../widgets.js';
import { saveSettings } from '../storage.js';
import { pinWidget, isNative } from '../native.js';
import { sheet, toast } from '../ui.js';

let kind = 'month';

export function renderWidgets() {
  const cfg = state.settings.widgets[kind];
  const opt = (v, l, cur) => '<option value="' + esc(v) + '"' + (v === cur ? ' selected' : '') + '>' + esc(l) + '</option>';
  return '<div class="seg three" id="w-kind">' + WIDGET_KINDS.map((k) => '<button data-k="' + k + '" class="' + (k === kind ? 'on' : '') + '">' + esc(t('w_' + k)) + '</button>').join('') + '</div>' +
    '<p class="muted small">' + esc(t('w_' + kind + '_hint')) + '</p>' +
    '<div class="w-preview" id="w-prev"></div>' +
    '<div class="w-btns"><button class="btn primary" data-a="wPin">' + icon('pin') + esc(t('addToHome')) + '</button>' +
    '<button class="btn" data-a="wRefresh">' + icon('restore') + esc(t('refreshWidgets')) + '</button></div>' +
    '<h4 class="sec-title">' + esc(t('design')) + '</h4><div class="card pad wform">' +
    '<label class="fld-label">' + esc(t('budgetSource')) + '</label><select class="fld" data-w="budgetId">' + opt('', t('activeBudget'), cfg.budgetId || '') +
    state.index.map((x) => opt(x.id, x.name, cfg.budgetId)).join('') + '</select>' +
    '<label class="fld-label">' + esc(t('widgetTitle')) + '</label><input class="fld" data-w="title" value="' + esc(cfg.title || '') + '" placeholder="' + esc(t('automatic')) + '">' +
    '<label class="fld-label">' + esc(t('theme')) + '</label><div class="seg four" id="w-theme">' + THEMES.map((th) => '<button data-v="' + th + '" class="' + (cfg.theme === th ? 'on' : '') + '">' + esc(t('theme_' + th)) + '</button>').join('') + '</div>' +
    '<label class="fld-label">' + esc(t('accentColor')) + '</label><div class="swatches" id="w-acc">' + ACCENTS.map((c) => '<button data-v="' + c + '" style="background:' + c + '" class="' + (cfg.accent === c ? 'on' : '') + '"></button>').join('') +
    '<label class="sw-custom" style="background:' + esc(cfg.accent) + '"><input type="color" data-w="accent" value="' + esc(cfg.accent) + '"></label></div>' +
    '<label class="fld-label">' + esc(t('opacity')) + ' <span id="w-op">' + cfg.opacity + ' %</span></label><input type="range" min="20" max="100" step="5" data-w="opacity" value="' + cfg.opacity + '">' +
    '<label class="fld-label">' + esc(t('cornerRadius')) + ' <span id="w-rad">' + cfg.radius + '</span></label><input type="range" min="0" max="40" step="2" data-w="radius" value="' + cfg.radius + '">' +
    (kind === 'month' ? '<label class="set-row toggle"><div><b>' + esc(t('showDiff')) + '</b></div><input type="checkbox" data-w="showDiff"' + (cfg.showDiff ? ' checked' : '') + '><span class="sw"></span></label>' +
      '<label class="set-row toggle"><div><b>' + esc(t('showDaily')) + '</b></div><input type="checkbox" data-w="showDaily"' + (cfg.showDaily ? ' checked' : '') + '><span class="sw"></span></label>' : '') +
    (kind === 'chart' ? '<label class="fld-label">' + esc(t('chartType')) + '</label><select class="fld" data-w="chart">' +
      opt('months', t('chart_months'), cfg.chart) + opt('categories', t('chart_categories'), cfg.chart) + opt('net', t('chart_net'), cfg.chart) + '</select>' : '') +
    (kind === 'quick' ? '<label class="fld-label">' + esc(t('entriesCount')) + '</label><select class="fld" data-w="count">' + [2, 3, 4].map((n) => opt(String(n), String(n), String(cfg.count))).join('') + '</select>' : '') +
    '</div>';
}

async function drawPreview(root) {
  const el = root.querySelector('#w-prev'); if (!el) return;
  const cfg = state.settings.widgets[kind];
  const b = await budgetFor(cfg);
  const cv = renderWidget(kind, cfg, b, 2);
  const [W, H] = WIDGET_SIZE[kind];
  cv.style.width = '100%'; cv.style.maxWidth = W + 'px'; cv.style.aspectRatio = W + ' / ' + H; cv.style.height = 'auto';
  el.innerHTML = ''; el.appendChild(cv);
}

export function mountWidgets(root, rerender) {
  drawPreview(root);
  const cfg = () => state.settings.widgets[kind];
  const changed = () => { saveSettings(); drawPreview(root); refreshWidgets(); };
  root.querySelector('#w-kind').onclick = (e) => { const b = e.target.closest('button'); if (!b) return; kind = b.dataset.k; rerender(); };
  root.querySelector('#w-theme').onclick = (e) => {
    const b = e.target.closest('button'); if (!b) return; cfg().theme = b.dataset.v;
    root.querySelectorAll('#w-theme button').forEach((x) => x.classList.toggle('on', x === b)); changed();
  };
  root.querySelector('#w-acc').onclick = (e) => {
    const b = e.target.closest('button'); if (!b) return; cfg().accent = b.dataset.v;
    root.querySelectorAll('#w-acc button').forEach((x) => x.classList.toggle('on', x === b));
    root.querySelector('.sw-custom').style.background = b.dataset.v; changed();
  };
  root.querySelectorAll('[data-w]').forEach((inp) => {
    const ev = inp.tagName === 'SELECT' || inp.type === 'checkbox' ? 'change' : 'input';
    inp.addEventListener(ev, () => {
      const k = inp.dataset.w;
      let v = inp.type === 'checkbox' ? inp.checked : inp.value;
      if (k === 'opacity' || k === 'radius' || k === 'count') v = +v;
      if (k === 'budgetId' && !v) v = null;
      cfg()[k] = v;
      if (k === 'opacity') root.querySelector('#w-op').textContent = v + ' %';
      if (k === 'radius') root.querySelector('#w-rad').textContent = v;
      if (k === 'accent') { root.querySelector('.sw-custom').style.background = v; root.querySelectorAll('#w-acc button').forEach((x) => x.classList.remove('on')); }
      changed();
    });
  });
}

export async function widgetsAction(a) {
  if (a === 'wRefresh') { refreshWidgets.flush(); toast(t('widgetsRefreshed')); return; }
  if (a === 'wPin') {
    let r = null;
    try { r = await pinWidget(kind); } catch (e) { r = { supported: false }; }
    refreshWidgets.flush();
    if (r && r.supported) { toast(t('pinRequested')); return; }
    await sheet({
      title: t('addToHome'),
      body: '<p class="dlg-text">' + esc(isNative ? t('pinManual') : t('pinWeb')) + '</p><ol class="steps"><li>' + esc(t('pinStep1')) + '</li><li>' + esc(t('pinStep2')) + '</li><li>' + esc(t('pinStep3', { w: t('w_' + kind) })) + '</li></ol>',
      actions: [{ label: t('ok'), value: true, cls: 'primary' }],
    });
  }
}
