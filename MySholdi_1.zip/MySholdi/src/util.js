// Pomoćne funkcije: ID-evi, brojevi, formatiranje, datumi
import { getLang, t } from './i18n.js';
import { state } from './state.js';

export const uid = (p = '') => p + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export const sum = (a) => a.reduce((s, x) => s + (x || 0), 0);
// Prosjek bez praznih i nultih vrijednosti (kao u Excel tablici)
export const avgNZ = (a) => { const f = a.filter((x) => x); return f.length ? sum(f) / f.length : 0; };
export const stdevNZ = (a) => {
  const f = a.filter((x) => x); if (f.length < 2) return 0;
  const m = sum(f) / f.length; return Math.sqrt(sum(f.map((x) => (x - m) ** 2)) / (f.length - 1));
};
export const round2 = (x) => Math.round((x + Number.EPSILON) * 100) / 100;
export const daysIn = (y, m) => new Date(y, m + 1, 0).getDate();

// Parsiranje unosa: broj ("1.234,56", "1234.56") ili izraz ("9600+5000")
export function parseAmount(raw) {
  if (raw === null || raw === undefined) return null;
  let s = String(raw).trim().replace(/\s/g, '').replace(/€|\$|£/g, '');
  if (s === '') return null;
  // hrvatski zapis s točkom za tisućice i zarezom za decimale
  if (/^-?\d{1,3}(\.\d{3})+(,\d+)?$/.test(s)) s = s.replace(/\./g, '').replace(',', '.');
  else if (getLang() === 'en' && /^-?\d{1,3}(,\d{3})+(\.\d+)?$/.test(s)) s = s.replace(/,/g, '');
  else s = s.replace(/,/g, '.');
  const n = Number(s);
  if (!isNaN(n)) return n;
  if (/^[0-9+\-*/().]+$/.test(s)) {
    try {
      // eslint-disable-next-line no-new-func
      const r = Function('"use strict";return (' + s + ')')();
      if (typeof r === 'number' && isFinite(r)) return round2(r);
    } catch (e) { /* neispravan izraz */ }
  }
  return NaN;
}

const ISO = /^[A-Z]{3}$/;
function locale() { return getLang() === 'en' ? 'en-GB' : 'hr-HR'; }

export function fmtNum(x, dec = 2) {
  if (x === null || x === undefined || isNaN(x)) return '—';
  return new Intl.NumberFormat(locale(), { minimumFractionDigits: dec, maximumFractionDigits: dec }).format(x);
}
// Iznos s valutom; valuta može biti ISO kod (EUR, USD) ili proizvoljan tekst (npr. KM)
export function money(x, opts = {}) {
  if (x === null || x === undefined || isNaN(x)) return '—';
  const cur = (state.settings?.currency || 'EUR').trim();
  const dec = opts.dec ?? 2;
  const sign = opts.sign && x > 0 ? '+' : '';
  if (ISO.test(cur.toUpperCase())) {
    try {
      return sign + new Intl.NumberFormat(locale(), { style: 'currency', currency: cur.toUpperCase(), minimumFractionDigits: dec, maximumFractionDigits: dec }).format(x);
    } catch (e) { /* nepoznat kod – padamo na tekst */ }
  }
  return sign + fmtNum(x, dec) + ' ' + cur;
}
export const moneyShort = (x) => {
  const a = Math.abs(x);
  if (a >= 1e6) return fmtNum(x / 1e6, 1) + 'M';
  if (a >= 1e4) return fmtNum(x / 1e3, 1) + 'k';
  return fmtNum(x, 0);
};

export function monthName(i, short = false) { return t((short ? 'mShort' : 'm') + i); }

export function fmtDateTime(ts) {
  const d = new Date(ts);
  return new Intl.DateTimeFormat(locale(), { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }).format(d);
}
export function fmtDate(ts) {
  return new Intl.DateTimeFormat(locale(), { day: '2-digit', month: '2-digit', year: 'numeric' }).format(new Date(ts));
}
export function relDays(ts) { return Math.floor((Date.now() - ts) / 86400000); }

export function debounce(fn, ms) {
  let tm;
  const d = (...a) => { clearTimeout(tm); tm = setTimeout(() => fn(...a), ms); };
  d.flush = (...a) => { clearTimeout(tm); fn(...a); };
  d.cancel = () => clearTimeout(tm);
  return d;
}

export const clone = (o) => JSON.parse(JSON.stringify(o));
export const clamp = (x, a, b) => Math.min(b, Math.max(a, x));
