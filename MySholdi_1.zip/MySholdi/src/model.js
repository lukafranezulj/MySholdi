// Model podataka proračunske tablice: zadane kategorije, izračuni i izmjene
import { uid, sum, avgNZ, daysIn, round2 } from './util.js';
import { getLang } from './i18n.js';

export const FORMAT = 'mysholdi-budget';
const empty12 = () => Array(12).fill(null);

// Zadane (intuitivne) kategorije – naslovi i podnaslovi
const DEFAULTS = {
  hr: {
    income: [
      ['Redovni prihodi', ['Plaća', 'Honorari i dodatni rad', 'Bonusi i nagrade', 'Mirovina i naknade']],
      ['Ostali prihodi', ['Povrat poreza', 'Pokloni', 'Prodaja stvari', 'Kamate i dividende', 'Ostalo']],
    ],
    expense: [
      ['Stanovanje', ['Najam ili rata stana', 'Režije (struja, voda, plin)', 'Internet i TV', 'Održavanje i popravci']],
      ['Hrana i piće', ['Namirnice', 'Restorani i dostava', 'Kava i grickalice', 'Hrana na poslu']],
      ['Prijevoz', ['Gorivo', 'Javni prijevoz', 'Registracija i osiguranje', 'Servis i dijelovi']],
      ['Financije', ['Bankovne naknade', 'Rate kredita i kartica', 'Štednja i investicije', 'Osiguranja', 'Porezi i kazne']],
      ['Pretplate i komunikacije', ['Mobitel', 'Streaming i aplikacije', 'Članarine']],
      ['Zdravlje i njega', ['Ljekarna i liječnici', 'Higijena i kozmetika', 'Frizer', 'Teretana i sport']],
      ['Odjeća i kućanstvo', ['Odjeća i obuća', 'Elektronika i uređaji', 'Namještaj i oprema za dom']],
      ['Slobodno vrijeme', ['Izlasci', 'Hobiji i igre', 'Putovanja', 'Kino i događanja']],
      ['Obrazovanje', ['Školarine i tečajevi', 'Knjige i materijali']],
      ['Pokloni i prigode', ['Pokloni', 'Vjenčanja i slavlja', 'Donacije']],
      ['Ostalo', ['Ostali troškovi']],
    ],
    periods: ['Ožujak', 'Lipanj', 'Rujan', 'Prosinac'],
    assets: ['Nekretnine', 'Vozila', 'Bankovni računi i štednja', 'Gotovina', 'Mirovinski fondovi', 'Investicije (ETF, dionice, fondovi)', 'Ostala imovina'],
    liabilities: ['Stambeni kredit', 'Ostali krediti', 'Kartice i dopušteni minus', 'Dugovi'],
    name: 'Moje financije',
  },
  en: {
    income: [
      ['Regular income', ['Salary', 'Freelance and side jobs', 'Bonuses and rewards', 'Pension and benefits']],
      ['Other income', ['Tax refund', 'Gifts', 'Selling things', 'Interest and dividends', 'Other']],
    ],
    expense: [
      ['Housing', ['Rent or mortgage', 'Utilities (power, water, gas)', 'Internet and TV', 'Maintenance and repairs']],
      ['Food and drinks', ['Groceries', 'Restaurants and delivery', 'Coffee and snacks', 'Food at work']],
      ['Transport', ['Fuel', 'Public transport', 'Registration and insurance', 'Service and parts']],
      ['Finance', ['Bank fees', 'Loan and card payments', 'Savings and investments', 'Insurance', 'Taxes and fines']],
      ['Subscriptions and phone', ['Mobile phone', 'Streaming and apps', 'Memberships']],
      ['Health and care', ['Pharmacy and doctors', 'Hygiene and cosmetics', 'Hairdresser', 'Gym and sports']],
      ['Clothing and household', ['Clothes and shoes', 'Electronics and devices', 'Furniture and home']],
      ['Leisure', ['Going out', 'Hobbies and games', 'Travel', 'Cinema and events']],
      ['Education', ['Tuition and courses', 'Books and materials']],
      ['Gifts and occasions', ['Gifts', 'Weddings and celebrations', 'Donations']],
      ['Other', ['Other expenses']],
    ],
    periods: ['March', 'June', 'September', 'December'],
    assets: ['Real estate', 'Vehicles', 'Bank accounts and savings', 'Cash', 'Pension funds', 'Investments (ETF, stocks, funds)', 'Other assets'],
    liabilities: ['Mortgage', 'Other loans', 'Credit cards and overdraft', 'Debts'],
    name: 'My finances',
  },
};

export function defaultBudgetName() { return DEFAULTS[getLang()].name; }

export function newBudget(name, year, blank = false) {
  const D = DEFAULTS[getLang()];
  const mk = (list) => list.map(([g, items]) => ({ id: uid('g'), name: g, items: items.map((n) => ({ id: uid('i'), name: n, vals: empty12() })) }));
  return {
    format: FORMAT, version: 1, id: uid('b'), name, year: year || new Date().getFullYear(),
    createdAt: Date.now(), updatedAt: Date.now(),
    income: blank ? [{ id: uid('g'), name: D.income[0][0], items: [{ id: uid('i'), name: D.income[0][1][0], vals: empty12() }] }] : mk(D.income),
    expense: blank ? [{ id: uid('g'), name: D.expense[0][0], items: [{ id: uid('i'), name: D.expense[0][1][0], vals: empty12() }] }] : mk(D.expense),
    net: {
      periods: [...D.periods],
      assets: D.assets.map((n) => ({ id: uid('a'), name: n, vals: [null, null, null, null] })),
      liabilities: D.liabilities.map((n) => ({ id: uid('l'), name: n, vals: [null, null, null, null] })),
    },
    entries: [],
  };
}

// Provjera i popravak strukture učitane datoteke
export function normalizeBudget(b) {
  if (!b || typeof b !== 'object') throw new Error('bad');
  if (b.format !== FORMAT && !(b.income && b.expense)) throw new Error('bad');
  const fixGroups = (gs, p) => (Array.isArray(gs) ? gs : []).map((g) => ({
    id: g.id || uid('g'), name: String(g.name ?? ''),
    items: (Array.isArray(g.items) ? g.items : []).map((it) => ({
      id: it.id || uid('i'), name: String(it.name ?? ''),
      vals: Array.from({ length: 12 }, (_, i) => { const v = it.vals?.[i]; return v === null || v === undefined || v === '' || isNaN(+v) ? null : +v; }),
    })),
  }));
  const net = b.net || {};
  const P = Array.isArray(net.periods) && net.periods.length ? net.periods.map(String) : [...DEFAULTS[getLang()].periods];
  const fixRows = (rows, p) => (Array.isArray(rows) ? rows : []).map((r) => ({
    id: r.id || uid(p), name: String(r.name ?? ''),
    vals: P.map((_, i) => { const v = r.vals?.[i]; return v === null || v === undefined || v === '' || isNaN(+v) ? null : +v; }),
  }));
  return {
    format: FORMAT, version: 1, id: b.id || uid('b'), name: String(b.name || defaultBudgetName()),
    year: +b.year || new Date().getFullYear(), createdAt: b.createdAt || Date.now(), updatedAt: b.updatedAt || Date.now(),
    income: fixGroups(b.income), expense: fixGroups(b.expense),
    net: { periods: P, assets: fixRows(net.assets, 'a'), liabilities: fixRows(net.liabilities, 'l') },
    entries: (Array.isArray(b.entries) ? b.entries : []).filter((e) => e && e.id && isFinite(+e.amount)),
  };
}

// Uvoz iz izvoza stare HTML/Excel tablice (format {year, imovina, prihodi, rashodi})
export function fromLegacy(d, name) {
  const val = (s) => {
    if (s === '' || s === null || s === undefined) return null;
    const n = Number(String(s).replace(',', '.'));
    if (!isNaN(n)) return n;
    if (/^[0-9+\-*/().\s]+$/.test(String(s))) { try { return Function('"use strict";return (' + s + ')')(); } catch (e) { return null; } }
    return null;
  };
  const groups = (gs) => gs.map((g) => ({ id: uid('g'), name: g.name, items: g.items.filter((it) => it.name || it.vals.some((v) => v !== '')).map((it) => ({ id: uid('i'), name: it.name || '—', vals: it.vals.map(val) })) }));
  const rows = (rs, p) => rs.map((r) => ({ id: uid(p), name: r.name, vals: r.vals.map(val) }));
  return normalizeBudget({
    format: FORMAT, name, year: d.year, income: groups(d.prihodi), expense: groups(d.rashodi),
    net: { periods: d.imovina.periods, assets: rows(d.imovina.assets, 'a'), liabilities: rows(d.imovina.liabilities, 'l') }, entries: [],
  });
}

// ---------- Izračuni ----------
export function calcSide(b, type) {
  const groups = b[type].map((g) => {
    const rows = g.items.map((it) => { const m = it.vals.map((v) => v || 0); return { m, total: sum(m), avg: avgNZ(m) }; });
    const m = Array.from({ length: 12 }, (_, i) => sum(rows.map((r) => r.m[i])));
    return { rows, m, total: sum(m), avg: avgNZ(m) };
  });
  const monthly = Array.from({ length: 12 }, (_, i) => sum(groups.map((g) => g.m[i])));
  const daily = monthly.map((x, i) => x / daysIn(b.year, i));
  return { groups, monthly, daily, total: sum(monthly), avgMonthly: avgNZ(monthly), avgDaily: avgNZ(daily) };
}

export function calcNet(b) {
  const P = b.net.periods.length;
  const col = (rows, i) => sum(rows.map((r) => r.vals[i] || 0));
  const assets = Array.from({ length: P }, (_, i) => col(b.net.assets, i));
  const liab = Array.from({ length: P }, (_, i) => col(b.net.liabilities, i));
  const net = assets.map((a, i) => (a - liab[i] === 0 ? NaN : a - liab[i]));
  const avgExp = calcSide(b, 'expense').avgMonthly;
  const months = net.map((n) => (isNaN(n) || !avgExp ? NaN : n / avgExp));
  return { assets, liab, net, months, years: months.map((m) => m / 12), avgExp };
}

// ---------- Izmjene ----------
export function findItem(b, type, gid, iid) {
  const g = b[type].find((x) => x.id === gid);
  const it = g && g.items.find((x) => x.id === iid);
  return { g, it };
}
export function addToCell(b, type, gid, iid, month, delta) {
  const { it } = findItem(b, type, gid, iid);
  if (!it) return false;
  const nv = round2((it.vals[month] || 0) + delta);
  it.vals[month] = nv === 0 && it.vals[month] === null ? null : nv;
  return true;
}
export function itemLabel(b, type, gid, iid) {
  const { g, it } = findItem(b, type, gid, iid);
  return g && it ? g.name + ' › ' + it.name : null;
}
// Zapis u dnevnik promjena (prikazuje se na naslovnoj)
export function logEntry(b, e) {
  const entry = { id: uid('e'), ts: Date.now(), note: '', src: 'quick', ...e, amount: round2(e.amount) };
  entry.label = itemLabel(b, entry.type, entry.gid, entry.iid) || entry.label || '';
  b.entries.unshift(entry);
  if (b.entries.length > 2000) b.entries.length = 2000;
  return entry;
}
export function touch(b) { b.updatedAt = Date.now(); }
