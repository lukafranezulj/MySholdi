// Središnje "kuke" aplikacije – postavlja ih main.js (izbjegava kružne importe)
export const app = {
  rerender: () => {},          // ponovno iscrtaj trenutni ekran
  go: (route, opts) => {},     // navigacija
  openBudget: async (id) => {},
  refreshWidgets: () => {},
};
