package com.mysholdi.app.widget;

/** Widget "quick" – slika se iscrtava u aplikaciji. */
public class QuickWidget extends WidgetBase {
    @Override
    protected String kind() {
        return "quick";
    }
}
