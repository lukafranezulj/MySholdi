package com.mysholdi.app;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.OpenableColumns;
import android.util.Base64;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.mysholdi.app.widget.WidgetBase;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * MySholdi nativni dodatak:
 *  - datoteke preko Storage Access Frameworka (Google Drive, Dropbox, OneDrive, lokalna memorija)
 *  - slike widgeta i dodavanje widgeta na početni zaslon
 *  - akcija pokretanja iz widgeta (brzi unos)
 */
@CapacitorPlugin(name = "MySholdi")
public class MySholdiPlugin extends Plugin {

    public static final String EXTRA_ACTION = "mysholdi_action";
    private static String pendingAction = null;

    // Pozvati iz MainActivity.onCreate – zapamti akciju iz widgeta
    public static void captureLaunchIntent(Intent intent) {
        if (intent == null) return;
        String a = intent.getStringExtra(EXTRA_ACTION);
        if (a != null) {
            pendingAction = a;
            intent.removeExtra(EXTRA_ACTION);
        }
    }

    @Override
    protected void handleOnNewIntent(Intent intent) {
        super.handleOnNewIntent(intent);
        if (intent == null) return;
        String a = intent.getStringExtra(EXTRA_ACTION);
        if (a != null) {
            intent.removeExtra(EXTRA_ACTION);
            JSObject d = new JSObject();
            d.put("action", a);
            notifyListeners("launchAction", d, true);
        }
    }

    @PluginMethod
    public void consumeLaunchAction(PluginCall call) {
        JSObject r = new JSObject();
        r.put("action", pendingAction);
        pendingAction = null;
        call.resolve(r);
    }

    @PluginMethod
    public void getInfo(PluginCall call) {
        JSObject r = new JSObject();
        r.put("filesDir", getContext().getFilesDir().getAbsolutePath());
        boolean pin = false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            pin = AppWidgetManager.getInstance(getContext()).isRequestPinAppWidgetSupported();
        }
        r.put("pinSupported", pin);
        call.resolve(r);
    }

    // ---------- Datoteke (SAF) ----------

    @PluginMethod
    public void createDocument(PluginCall call) {
        String name = call.getString("fileName", "MySholdi.json");
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(call, i, "onCreateDocument");
    }

    @ActivityCallback
    private void onCreateDocument(PluginCall call, ActivityResult result) {
        if (call == null) return;
        Uri uri = resultUri(result);
        if (uri == null) {
            call.reject("cancelled");
            return;
        }
        persist(uri);
        JSObject r = new JSObject();
        r.put("uri", uri.toString());
        r.put("name", displayName(uri));
        call.resolve(r);
    }

    @PluginMethod
    public void openDocument(PluginCall call) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        // neki pružatelji (npr. Drive) JSON označavaju različito – dopuštamo sve
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[] { "application/json", "text/plain", "application/octet-stream", "text/json" });
        startActivityForResult(call, i, "onOpenDocument");
    }

    @ActivityCallback
    private void onOpenDocument(PluginCall call, ActivityResult result) {
        if (call == null) return;
        Uri uri = resultUri(result);
        if (uri == null) {
            call.reject("cancelled");
            return;
        }
        persist(uri);
        new Thread(() -> {
            try {
                String data = readUri(uri);
                JSObject r = new JSObject();
                r.put("uri", uri.toString());
                r.put("name", displayName(uri));
                r.put("data", data);
                call.resolve(r);
            } catch (Exception e) {
                call.reject("read failed: " + e.getMessage(), e);
            }
        }).start();
    }

    @PluginMethod
    public void writeDocument(PluginCall call) {
        String uriStr = call.getString("uri");
        String data = call.getString("data", "");
        if (uriStr == null) {
            call.reject("missing uri");
            return;
        }
        new Thread(() -> {
            try {
                writeUri(Uri.parse(uriStr), data);
                JSObject r = new JSObject();
                r.put("ok", true);
                call.resolve(r);
            } catch (Exception e) {
                call.reject("write failed: " + e.getMessage(), e);
            }
        }).start();
    }

    @PluginMethod
    public void readDocument(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) {
            call.reject("missing uri");
            return;
        }
        new Thread(() -> {
            try {
                JSObject r = new JSObject();
                r.put("data", readUri(Uri.parse(uriStr)));
                call.resolve(r);
            } catch (Exception e) {
                call.reject("read failed: " + e.getMessage(), e);
            }
        }).start();
    }

    @PluginMethod
    public void releaseDocument(PluginCall call) {
        String uriStr = call.getString("uri");
        try {
            if (uriStr != null) {
                getContext().getContentResolver()
                    .releasePersistableUriPermission(Uri.parse(uriStr), Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            }
        } catch (Exception ignored) {}
        call.resolve();
    }

    private Uri resultUri(ActivityResult result) {
        if (result == null || result.getResultCode() != Activity.RESULT_OK) return null;
        Intent data = result.getData();
        return data == null ? null : data.getData();
    }

    // Trajno dopuštenje – datoteka ostaje dostupna i nakon ponovnog pokretanja
    private void persist(Uri uri) {
        try {
            getContext().getContentResolver()
                .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (Exception e) {
            try {
                getContext().getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
        }
    }

    private String displayName(Uri uri) {
        try (Cursor c = getContext().getContentResolver().query(uri, new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                String n = c.getString(0);
                if (n != null) return n;
            }
        } catch (Exception ignored) {}
        String last = uri.getLastPathSegment();
        return last == null ? "MySholdi.json" : last;
    }

    private String readUri(Uri uri) throws Exception {
        ContentResolver cr = getContext().getContentResolver();
        try (InputStream in = cr.openInputStream(uri)) {
            if (in == null) throw new Exception("cannot open");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        }
    }

    private void writeUri(Uri uri, String data) throws Exception {
        ContentResolver cr = getContext().getContentResolver();
        byte[] bytes = data.getBytes(StandardCharsets.UTF_8);
        Exception last = null;
        // "wt" = zapiši i skrati; neki pružatelji podržavaju samo "w" ili "rwt"
        for (String mode : new String[] { "wt", "rwt", "w" }) {
            try (OutputStream out = cr.openOutputStream(uri, mode)) {
                if (out == null) throw new Exception("cannot open");
                out.write(bytes);
                out.flush();
                return;
            } catch (SecurityException se) {
                throw se;
            } catch (Exception e) {
                last = e;
            }
        }
        throw last != null ? last : new Exception("write failed");
    }

    // ---------- Widgeti ----------

    @PluginMethod
    public void updateWidget(PluginCall call) {
        String kind = call.getString("kind");
        String png = call.getString("png");
        if (kind == null || png == null) {
            call.reject("missing args");
            return;
        }
        new Thread(() -> {
            try {
                Context ctx = getContext();
                File dir = new File(ctx.getFilesDir(), "widgets");
                if (!dir.exists() && !dir.mkdirs()) throw new Exception("mkdir");
                File tmp = new File(dir, kind + ".tmp");
                try (FileOutputStream fo = new FileOutputStream(tmp)) {
                    fo.write(Base64.decode(png, Base64.DEFAULT));
                }
                File dst = new File(dir, kind + ".png");
                if (!tmp.renameTo(dst)) throw new Exception("rename");
                WidgetBase.updateAll(ctx, kind);
                call.resolve();
            } catch (Exception e) {
                call.reject("widget update failed: " + e.getMessage(), e);
            }
        }).start();
    }

    @PluginMethod
    public void pinWidget(PluginCall call) {
        String kind = call.getString("kind", "month");
        JSObject r = new JSObject();
        boolean ok = false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AppWidgetManager mgr = AppWidgetManager.getInstance(getContext());
            if (mgr.isRequestPinAppWidgetSupported()) {
                ComponentName cn = new ComponentName(getContext(), WidgetBase.providerFor(kind));
                ok = mgr.requestPinAppWidget(cn, null, null);
            }
        }
        r.put("supported", ok);
        call.resolve(r);
    }
}
