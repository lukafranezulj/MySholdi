package com.mysholdi.app.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.widget.RemoteViews;
import com.mysholdi.app.MainActivity;
import com.mysholdi.app.MySholdiPlugin;
import com.mysholdi.app.R;
import java.io.File;

/**
 * Zajednička logika widgeta: prikazuje sliku koju iscrtava aplikacija
 * (files/widgets/<vrsta>.png). Dodir otvara aplikaciju; widget "quick" otvara brzi unos.
 */
public abstract class WidgetBase extends AppWidgetProvider {

    protected abstract String kind();

    @Override
    public void onUpdate(Context context, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) {
            mgr.updateAppWidget(id, build(context, kind()));
        }
    }

    public static Class<? extends WidgetBase> providerFor(String kind) {
        if ("chart".equals(kind)) return ChartWidget.class;
        if ("quick".equals(kind)) return QuickWidget.class;
        return MonthWidget.class;
    }

    public static void updateAll(Context ctx, String kind) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, providerFor(kind)));
        if (ids == null || ids.length == 0) return;
        RemoteViews views = build(ctx, kind);
        for (int id : ids) mgr.updateAppWidget(id, views);
    }

    static RemoteViews build(Context ctx, String kind) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_image);
        File f = new File(new File(ctx.getFilesDir(), "widgets"), kind + ".png");
        Bitmap bm = f.exists() ? BitmapFactory.decodeFile(f.getAbsolutePath()) : null;
        if (bm != null) {
            v.setImageViewBitmap(R.id.widget_image, bm);
            v.setViewVisibility(R.id.widget_image, View.VISIBLE);
            v.setViewVisibility(R.id.widget_empty, View.GONE);
        } else {
            v.setViewVisibility(R.id.widget_image, View.GONE);
            v.setViewVisibility(R.id.widget_empty, View.VISIBLE);
        }
        Intent i = new Intent(ctx, MainActivity.class);
        // vlastita akcija (ne LAUNCHER), da Android pozove onNewIntent kad je aplikacija već otvorena
        i.setAction("com.mysholdi.app.WIDGET_" + kind.toUpperCase(java.util.Locale.ROOT));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if ("quick".equals(kind)) i.putExtra(MySholdiPlugin.EXTRA_ACTION, "quickadd");
        int req = "quick".equals(kind) ? 3 : ("chart".equals(kind) ? 2 : 1);
        PendingIntent pi = PendingIntent.getActivity(ctx, req, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.widget_root, pi);
        return v;
    }
}
