package com.mysholdi.app.widget;

/** Widget "chart" – slika se iscrtava u aplikaciji. */
public class ChartWidget extends WidgetBase {
    @Override
    protected String kind() {
        return "chart";
    }
}
