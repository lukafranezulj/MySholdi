package com.mysholdi.app.widget;

/** Widget "month" – slika se iscrtava u aplikaciji. */
public class MonthWidget extends WidgetBase {
    @Override
    protected String kind() {
        return "month";
    }
}
