# MySholdi

Android aplikacija za praćenje osobnih financija – prihodi, rashodi, neto imovina i kalkulator kredita. Logika je ista kao u Excel tablici „Prihodi i rashodi“: zbrojevi po naslovima i podnaslovima, prosjek mjesečno i dnevno (bez praznih mjeseci i nula), sažetak sa statistikom (SR, σ, Cv, MAX, MIN) i „bogatstvo“ u mjesecima i godinama.

**Tehnologija:** [Capacitor 8](https://capacitorjs.com) (web sučelje u JavaScriptu) + mali nativni Android dio u Javi (datoteke u oblaku i widgeti).

---

## Što aplikacija radi

| Dio | Opis |
|---|---|
| **Naslovna** | Stanje za mjesec (prihodi, rashodi, razlika) i popis zadnjih unosa s datumom, vremenom, iznosom i kategorijom. Olovka uređuje unos, a kanta ga briše i oduzima iznos od kategorije. |
| **Gumb +** | Brzi unos: Rashod/Prihod, mjesec (zadano tekući), iznos i podnaslov kojem se iznos pribraja. |
| **Prihodi / Rashodi** | Ikona oka prebacuje između prikaza jednog mjeseca i svih mjeseci (tablica kao u Excelu). Olovka uključuje uređivanje naslova i podnaslova (preimenovanje, dodavanje i brisanje). Dodir na naziv otvara grafikon naslova ili podnaslova. |
| **Imovina** | Neto imovina po kvartalima (imovina − obveze) i bogatstvo u mjesecima i godinama. |
| **Sažetak** | Grafikon prihoda i rashoda po mjesecima, tablica, statistika i udio kategorija. |
| **Proračunske tablice** | Više tablica s različitim nazivima (npr. po godinama). Možeš ih preimenovati, povezati s oblakom, izvesti ili obrisati. |
| **Widgets** | Tri widgeta: trenutni mjesec, grafikon i brzi unos. Izgled se uređuje u aplikaciji (tema, boja, prozirnost, zaobljenost), a widget se dodaje na početni zaslon. |
| **Postavke** | Jezik (hrvatski je zadan, može i engleski), valuta (zadano EUR, a može se upisati bilo koja druga), automatska sinkronizacija i popis mjesta pohrane. |
| **Kalkulator kredita** | Tri načina: po rati, po iznosu i po trajanju. Klizači i ručni unos, a u naprednim postavkama inflacija (stvarni trošak u današnjem novcu), naknada, EKS i otplatni plan. |
| **Koš za smeće** | Obrisane tablice, naslovi, podnaslovi i unosi čuvaju se 30 dana, a zatim se trajno brišu. |

### Spremanje i sinkronizacija
* Sve se **uvijek** sprema lokalno u mapu aplikacije, pa radi i bez interneta.
* Tipka **Spremi** (ikona u gornjem desnom kutu) nudi izbor mjesta: **Google Drive, Dropbox, OneDrive ili mapa na mobitelu**. Za to se koristi Androidov sustavni izbornik datoteka, pa ne trebaju nikakvi API ključevi. Dovoljno je da je na mobitelu instalirana aplikacija Drive ili Dropbox.
* **Automatska sinkronizacija** (u Postavkama): ako ne pritisneš Spremi, tablica se u oblak sprema sama 5 s nakon zadnje izmjene.
* Ako spremanje u oblak ne uspije, pojavi se obavijest i crveni natpis. Podaci tada ostaju lokalno i šalju se automatski čim se vrati veza (ili pri sljedećem otvaranju aplikacije).
* **Na novom mobitelu:** instaliraj aplikaciju, odaberi **„Učitaj iz datoteke (Drive, Dropbox, lokalno)“** i otvori svoju datoteku `MySholdi - <naziv>.json`. Tablica se učita i ostaje povezana s tom datotekom.
* Ako se ista tablica uređuje na dva mobitela, aplikacija pri otvaranju prepozna noviju verziju u oblaku i ponudi njezino učitavanje.
* Možeš uvesti i JSON izvoz iz stare HTML tablice „Prihodi i rashodi“.

---

## Kako dobiti APK (bez instalacije ičega na računalo)

1. Na GitHubu napravi **novi privatni repozitorij** (npr. `MySholdi`).
2. Raspakiraj ZIP i u repozitorij prenesi **sadržaj** mape `MySholdi` (uključujući skrivenu mapu `.github`). Najlakše je s aplikacijom GitHub Desktop ili naredbama:
   ```bash
   cd MySholdi
   git init
   git add .
   git commit -m "MySholdi 1.0"
   git branch -M main
   git remote add origin https://github.com/<tvoje-ime>/MySholdi.git
   git push -u origin main
   ```
   > Ako prenosiš kroz web sučelje (Add file → Upload files), provjeri je li se prenijela i mapa `.github/workflows`. Neki preglednici skrivene mape preskaču, a bez nje se build neće pokrenuti.
3. Otvori karticu **Actions**. Workflow **„Android build“** pokreće se sam i traje oko 5–8 minuta.
4. Kad završi (zelena kvačica), otvori taj build i pod **Artifacts** preuzmi `MySholdi-1.0.x` (ZIP). Unutra je `MySholdi-1.0.x-debug.apk`.
5. Prebaci APK na mobitel i otvori ga. Android će tražiti dopuštenje za instalaciju iz nepoznatih izvora.

### Preporučeno: potpisani APK (da nadogradnje ne brišu podatke)
Debug APK potpisuje se privremenim ključem GitHub poslužitelja, a on se može razlikovati od builda do builda. Tada Android ne dopušta nadogradnju preko stare verzije, pa aplikaciju moraš deinstalirati, a time se brišu i lokalni podaci (zato koristi sinkronizaciju s Driveom). Uz vlastiti ključ svaka nova verzija instalira se preko stare bez gubitka podataka:

1. **Actions → „Create signing key“ → Run workflow.**
2. Preuzmi artefakt `mysholdi-signing-key`. Sadrži `mysholdi-release.jks`, `KEYSTORE_BASE64.txt` i `UPUTE.txt` s lozinkom.
3. Pohrani `.jks` i lozinku **na sigurno, zauvijek** (npr. u upravitelj lozinki ili na USB). Bez toga ključa na Google Playu ne možeš objaviti nadogradnju.
4. **Settings → Secrets and variables → Actions → New repository secret:** dodaj `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS` i `KEY_PASSWORD` (vrijednosti su u `UPUTE.txt`).
5. Obriši artefakt s ključem (Actions → taj build → Artifacts → kanta).
6. Pokreni **Android build** ponovno (Actions → Android build → Run workflow). Sada dobivaš i `MySholdi-1.0.x.apk` (potpisani release) i `MySholdi-1.0.x.aab` (za Google Play).

### Izdanja (Releases)
Kad napraviš oznaku, npr. `git tag v1.1.0 && git push --tags`, workflow uz artefakt napravi i **GitHub Release** s APK-om i AAB-om, a verzija aplikacije bude `1.1.0`. Broj verzije (versionCode) raste automatski sa svakim buildom.

---

## Lokalni razvoj (neobavezno)

Potrebno: Node.js 22+, JDK 21 i Android Studio (Android SDK 36).

```bash
npm install
npm run serve          # web sučelje u pregledniku na http://localhost:8080 (oblak se simulira)
npm run sync           # izgradi web dio i kopira ga u android/
npx cap open android   # otvori u Android Studiju → Run
# ili iz naredbenog retka:
cd android && ./gradlew assembleDebug    # APK: android/app/build/outputs/apk/debug/
```

Za lokalno potpisani release kopiraj `android/keystore.properties.example` u `android/keystore.properties`, upiši podatke i pokreni `./gradlew assembleRelease bundleRelease`.

### Struktura projekta
```
src/                 web aplikacija (JavaScript, bez frameworka; esbuild je spaja u www/)
  main.js            pokretanje, izbornik, navigacija, tipka natrag
  model.js           zadane kategorije, izračuni (kao u Excelu), izmjene
  sync.js            lokalno + oblak, autospremanje nakon 5 s, ponovni pokušaji, obavijesti
  cloud.js           povezivanje s Drive/Dropbox/lokalnom datotekom, uvoz/izvoz
  widgets.js         iscrtavanje widgeta u PNG
  loanCalc.js        izračuni kredita (anuitet, rok, inflacija, EKS)
  trash.js           koš za smeće (30 dana)
  i18n.js            prijevodi HR/EN
  views/             ekrani
android/             nativni projekt (Capacitor)
  app/src/main/java/com/mysholdi/app/MySholdiPlugin.java   datoteke (SAF), widgeti
  app/src/main/java/com/mysholdi/app/widget/               pružatelji widgeta
.github/workflows/   automatska izgradnja APK/AAB i stvaranje ključa
store/               ikona 512×512 i grafika 1024×500 za Google Play
PLAY_STORE_UPUTE.md  upute za objavu na Google Play
PRIVACY_POLICY.md    pravila privatnosti (potrebna za Google Play)
```

### Napomene
* Widgeti prikazuju sliku koju iscrtava aplikacija. Osvježavaju se pri svakoj izmjeni, a kad počne novi mjesec, dovoljno je otvoriti aplikaciju.
* Neki pokretači (launcheri) ne podržavaju tipku „Dodaj na početni zaslon“. Tada widget dodaješ dugim pritiskom na početni zaslon → Widgeti → MySholdi.
* Google uvodi provjeru razvojnih programera za instalaciju aplikacija izvan Google Playa. U 2026. ona vrijedi samo u Brazilu, Indoneziji, Singapuru i Tajlandu, a globalno se širi 2027. Ako tada instalacija vlastitog APK-a bude tražila dodatni korak, Android nudi napredni postupak instalacije ili instalaciju preko ADB-a. Alternativa je objava na Google Playu (vidi `PLAY_STORE_UPUTE.md`).
