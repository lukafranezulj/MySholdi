// Web inačica MySholdi (radi u pregledniku na računalu, tabletu i mobitelu)
//  web/index.html (+ app.js, chunks/)  – za objavu na web stranici (npr. GitHub Pages), može se "instalirati" (PWA)
//  web/MySholdi-offline.html           – JEDNA datoteka za preuzimanje: otvori dvoklikom, radi bez interneta
import { build } from 'esbuild';
import { copyFileSync, mkdirSync, rmSync, readFileSync, writeFileSync, readdirSync, statSync } from 'fs';
import { join } from 'path';

const pkg = JSON.parse(readFileSync('package.json', 'utf8'));
const common = { bundle: true, target: ['chrome89', 'safari15', 'firefox100'], minify: true, legalComments: 'none', loader: { '.ttf': 'base64' } };

rmSync('web', { recursive: true, force: true });
mkdirSync('web', { recursive: true });

// 1) web stranica (više datoteka, brže učitavanje)
await build({ ...common, entryPoints: { app: 'src/main.js' }, outdir: 'web', format: 'esm', splitting: true, chunkNames: 'chunks/[name]-[hash]' });
copyFileSync('src/app.css', 'web/app.css');
const icon = readFileSync('store/play-icon-512.png');
writeFileSync('web/icon-512.png', icon);
const html = readFileSync('src/index.html', 'utf8')
  .replace('</title>', '</title>\n  <link rel="manifest" href="manifest.webmanifest">\n  <link rel="icon" href="icon-512.png">');
writeFileSync('web/index.html', html.replace('</body>', '  <script>if (\'serviceWorker\' in navigator && location.protocol === \'https:\') navigator.serviceWorker.register(\'sw.js\');</script>\n</body>'));
writeFileSync('web/manifest.webmanifest', JSON.stringify({
  name: 'MojiSholdi', short_name: 'MojiSholdi', start_url: './', display: 'standalone', background_color: '#f4f6fa', theme_color: '#2563eb',
  icons: [{ src: 'icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any maskable' }],
}, null, 2));

// 2) jedna samostalna HTML datoteka (sav kod i stil unutra)
const r = await build({ ...common, entryPoints: ['src/main.js'], format: 'iife', write: false });
const js = r.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
const css = readFileSync('src/app.css', 'utf8');
const single = readFileSync('src/index.html', 'utf8')
  // funkcija kao zamjena: inače bi znakovi poput $& ili $' u kodu imali posebno značenje
  .replace('<link rel="stylesheet" href="app.css">', () => '<link rel="icon" href="data:image/png;base64,' + icon.toString('base64') + '">\n  <style>\n' + css + '\n</style>')
  .replace('<script type="module" src="app.js"></script>', () => '<script>window.__OFFLINE_FILE__ = true;</script>\n  <script>\n' + js + '\n</script>');
writeFileSync('web/MySholdi-offline.html', single);

// 3) service worker: popis svih datoteka za rad bez interneta
const files = [];
const walk = (d) => { for (const f of readdirSync(d)) { const p = join(d, f); if (statSync(p).isDirectory()) walk(p); else files.push(p.slice(4).replace(/\\/g, '/')); } };
walk('web');
const list = ['./', ...files.filter((f) => f !== 'sw.js')];
writeFileSync('web/sw.js', `// Predmemorija za rad bez interneta (verzija ${pkg.version})
const C = 'mysholdi-${pkg.version}-${Date.now().toString(36)}';
const FILES = ${JSON.stringify(list)};
self.addEventListener('install', (e) => { e.waitUntil(caches.open(C).then((c) => c.addAll(FILES)).then(() => self.skipWaiting())); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== C).map((k) => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', (e) => { if (e.request.method !== 'GET') return; e.respondWith(caches.match(e.request, { ignoreSearch: true }).then((r) => r || fetch(e.request))); });
`);
console.log('web/ izgrađen (' + files.length + ' datoteka), samostalna datoteka: web/MySholdi-offline.html (' + Math.round(single.length / 1024) + ' kB)');
