package com.mysholdi.app.widget;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Pohrana za widgete:
 *  files/widgets/d_<dizajn>.png  – slika dizajna (iscrtava je aplikacija)
 *  files/widgets/designs.json     – popis dizajna [{id, kind, name, entryType}]
 *  SharedPreferences "widgets"    – koji widget (appWidgetId) koristi koji dizajn
 */
public final class WidgetStore {

    private WidgetStore() {}

    static File dir(Context ctx) {
        File d = new File(ctx.getFilesDir(), "widgets");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    public static void writeImage(Context ctx, String designId, byte[] png) throws Exception {
        File tmp = new File(dir(ctx), "d_" + safe(designId) + ".tmp");
        try (FileOutputStream fo = new FileOutputStream(tmp)) {
            fo.write(png);
        }
        File dst = new File(dir(ctx), "d_" + safe(designId) + ".png");
        if (!tmp.renameTo(dst)) throw new Exception("rename");
    }

    public static File image(Context ctx, String designId) {
        return new File(dir(ctx), "d_" + safe(designId) + ".png");
    }

    public static void writeDesigns(Context ctx, String json) throws Exception {
        try (FileOutputStream fo = new FileOutputStream(new File(dir(ctx), "designs.json"))) {
            fo.write(json.getBytes(StandardCharsets.UTF_8));
        }
    }

    public static JSONArray designs(Context ctx) {
        try {
            File f = new File(dir(ctx), "designs.json");
            if (!f.exists()) return new JSONArray();
            byte[] b = new byte[(int) f.length()];
            try (FileInputStream in = new FileInputStream(f)) {
                int off = 0;
                while (off < b.length) {
                    int n = in.read(b, off, b.length - off);
                    if (n < 0) break;
                    off += n;
                }
            }
            return new JSONArray(new String(b, StandardCharsets.UTF_8));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    /** Dizajn za widget: dodijeljeni ili prvi dizajn te vrste. */
    public static JSONObject designFor(Context ctx, int appWidgetId, String kind) {
        JSONArray all = designs(ctx);
        String assigned = prefs(ctx).getString("w_" + appWidgetId, null);
        JSONObject first = null;
        for (int i = 0; i < all.length(); i++) {
            JSONObject d = all.optJSONObject(i);
            if (d == null || !kind.equals(d.optString("kind"))) continue;
            if (first == null) first = d;
            if (d.optString("id").equals(assigned)) return d;
        }
        return first;
    }

    public static void assign(Context ctx, int appWidgetId, String designId) {
        prefs(ctx).edit().putString("w_" + appWidgetId, designId).apply();
    }

    public static void unassign(Context ctx, int appWidgetId) {
        prefs(ctx).edit().remove("w_" + appWidgetId).apply();
    }

    static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences("widgets", Context.MODE_PRIVATE);
    }

    private static String safe(String s) {
        return s == null ? "x" : s.replaceAll("[^A-Za-z0-9_-]", "_");
    }
}
