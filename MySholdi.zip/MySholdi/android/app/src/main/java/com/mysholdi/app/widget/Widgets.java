package com.mysholdi.app.widget;

/** Pružatelji widgeta – po jedan za svaku veličinu/vrstu. */
public final class Widgets {

    private Widgets() {}

    public static class Month extends WidgetBase {
        @Override
        protected String kind() {
            return "month";
        }
    }

    /** Rashodi trenutnog mjeseca kao krafna (pie) s legendom od većeg prema manjem. */
    public static class Pie extends WidgetBase {
        @Override
        protected String kind() {
            return "pie";
        }
    }

    public static class Chart extends WidgetBase {
        @Override
        protected String kind() {
            return "chart";
        }
    }

    public static class Quick extends WidgetBase {
        @Override
        protected String kind() {
            return "quick";
        }
    }

    public static class AddSmall extends WidgetBase {
        @Override
        protected String kind() {
            return "add1";
        }
    }

    public static class AddBar extends WidgetBase {
        @Override
        protected String kind() {
            return "add2";
        }
    }
}
