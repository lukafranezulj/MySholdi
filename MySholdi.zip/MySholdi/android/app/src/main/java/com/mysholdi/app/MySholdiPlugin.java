package com.mysholdi.app;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.pm.PackageManager;
import android.content.UriPermission;
import android.provider.DocumentsContract;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import com.mysholdi.app.widget.PinReceiver;
import com.mysholdi.app.widget.WidgetStore;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.OpenableColumns;
import android.util.Base64;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.mysholdi.app.widget.WidgetBase;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * MySholdi nativni dodatak:
 *  - datoteke preko Storage Access Frameworka (Google Drive, Dropbox, OneDrive, lokalna memorija)
 *  - slike widgeta i dodavanje widgeta na početni zaslon
 *  - akcija pokretanja iz widgeta (brzi unos)
 */
@CapacitorPlugin(name = "MySholdi")
public class MySholdiPlugin extends Plugin {

    public static final String EXTRA_ACTION = "mysholdi_action";
    private static String pendingAction = null;

    // Pozvati iz MainActivity.onCreate – zapamti akciju iz widgeta
    public static void captureLaunchIntent(Intent intent) {
        if (intent == null) return;
        String a = intent.getStringExtra(EXTRA_ACTION);
        if (a != null) {
            pendingAction = a;
            intent.removeExtra(EXTRA_ACTION);
        }
    }

    @Override
    protected void handleOnNewIntent(Intent intent) {
        super.handleOnNewIntent(intent);
        if (intent == null) return;
        String a = intent.getStringExtra(EXTRA_ACTION);
        if (a != null) {
            intent.removeExtra(EXTRA_ACTION);
            JSObject d = new JSObject();
            d.put("action", a);
            notifyListeners("launchAction", d, true);
        }
    }

    @PluginMethod
    public void consumeLaunchAction(PluginCall call) {
        JSObject r = new JSObject();
        r.put("action", pendingAction);
        pendingAction = null;
        call.resolve(r);
    }

    @PluginMethod
    public void getInfo(PluginCall call) {
        JSObject r = new JSObject();
        r.put("filesDir", getContext().getFilesDir().getAbsolutePath());
        boolean pin = false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            pin = AppWidgetManager.getInstance(getContext()).isRequestPinAppWidgetSupported();
        }
        r.put("pinSupported", pin);
        call.resolve(r);
    }

    // ---------- Datoteke (SAF) ----------

    @PluginMethod
    public void createDocument(PluginCall call) {
        String name = call.getString("fileName", "MySholdi.json");
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(call.getString("mime", "application/json"));
        i.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(call, i, "onCreateDocument");
    }

    @ActivityCallback
    private void onCreateDocument(PluginCall call, ActivityResult result) {
        if (call == null) return;
        Uri uri = resultUri(result);
        if (uri == null) {
            call.reject("cancelled");
            return;
        }
        persist(uri);
        JSObject r = new JSObject();
        r.put("uri", uri.toString());
        r.put("name", displayName(uri));
        call.resolve(r);
    }

    @PluginMethod
    public void openDocument(PluginCall call) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        // neki pružatelji (npr. Drive) JSON označavaju različito – dopuštamo sve
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[] { "application/json", "text/plain", "application/octet-stream", "text/json" });
        startActivityForResult(call, i, "onOpenDocument");
    }

    @ActivityCallback
    private void onOpenDocument(PluginCall call, ActivityResult result) {
        if (call == null) return;
        Uri uri = resultUri(result);
        if (uri == null) {
            call.reject("cancelled");
            return;
        }
        persist(uri);
        new Thread(() -> {
            try {
                String data = readUri(uri);
                JSObject r = new JSObject();
                r.put("uri", uri.toString());
                r.put("name", displayName(uri));
                r.put("data", data);
                call.resolve(r);
            } catch (Exception e) {
                call.reject("read failed: " + e.getMessage(), e);
            }
        }).start();
    }

    @PluginMethod
    public void writeDocument(PluginCall call) {
        String uriStr = call.getString("uri");
        String data = call.getString("data", "");
        boolean isBase64 = Boolean.TRUE.equals(call.getBoolean("base64", false));
        if (uriStr == null) {
            call.reject("missing uri");
            return;
        }
        new Thread(() -> {
            try {
                // tekst (JSON tablice) ili binarno (PDF, Excel) poslano kao base64
                writeUri(Uri.parse(uriStr), isBase64 ? Base64.decode(data, Base64.DEFAULT) : data.getBytes(StandardCharsets.UTF_8));
                JSObject r = new JSObject();
                r.put("ok", true);
                call.resolve(r);
            } catch (Exception e) {
                call.reject("write failed: " + e.getMessage(), e);
            }
        }).start();
    }

    @PluginMethod
    public void readDocument(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) {
            call.reject("missing uri");
            return;
        }
        new Thread(() -> {
            try {
                JSObject r = new JSObject();
                r.put("data", readUri(Uri.parse(uriStr)));
                call.resolve(r);
            } catch (Exception e) {
                call.reject("read failed: " + e.getMessage(), e);
            }
        }).start();
    }

    @PluginMethod
    public void releaseDocument(PluginCall call) {
        String uriStr = call.getString("uri");
        try {
            if (uriStr != null) {
                getContext().getContentResolver()
                    .releasePersistableUriPermission(Uri.parse(uriStr), Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            }
        } catch (Exception ignored) {}
        call.resolve();
    }

    // Dijagnostika: dopuštenje, postoji li datoteka, može li se čitati i pisati
    @PluginMethod
    public void checkDocument(PluginCall call) {
        String uriStr = call.getString("uri");
        if (uriStr == null) {
            call.reject("missing uri");
            return;
        }
        Uri uri = Uri.parse(uriStr);
        new Thread(() -> {
            JSObject r = new JSObject();
            ContentResolver cr = getContext().getContentResolver();
            boolean pr = false, pw = false;
            try {
                for (UriPermission p : cr.getPersistedUriPermissions()) {
                    if (p.getUri().equals(uri)) {
                        pr = p.isReadPermission();
                        pw = p.isWritePermission();
                    }
                }
            } catch (Exception ignored) {}
            r.put("permRead", pr);
            r.put("permWrite", pw);
            boolean exists = false;
            long flags = -1;
            try (Cursor c = cr.query(uri, new String[] { DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_LAST_MODIFIED, DocumentsContract.Document.COLUMN_FLAGS }, null, null, null)) {
                if (c != null && c.moveToFirst()) {
                    exists = true;
                    r.put("name", c.getString(0));
                    if (!c.isNull(1)) r.put("lastModified", c.getLong(1));
                    if (!c.isNull(2)) flags = c.getLong(2);
                }
            } catch (Exception e) {
                r.put("queryError", e.getClass().getSimpleName() + ": " + e.getMessage());
            }
            r.put("exists", exists);
            if (flags >= 0) r.put("writable", (flags & DocumentsContract.Document.FLAG_SUPPORTS_WRITE) != 0);
            boolean readable = false;
            try (InputStream in = cr.openInputStream(uri)) {
                readable = in != null;
            } catch (Exception e) {
                r.put("readError", e.getClass().getSimpleName() + ": " + e.getMessage());
            }
            r.put("readable", readable);
            call.resolve(r);
        }).start();
    }

    @PluginMethod
    public void appInstalled(PluginCall call) {
        JSObject r = new JSObject();
        boolean ok = false;
        try {
            getContext().getPackageManager().getPackageInfo(call.getString("package", ""), 0);
            ok = true;
        } catch (Exception ignored) {}
        r.put("installed", ok);
        call.resolve(r);
    }

    private Uri resultUri(ActivityResult result) {
        if (result == null || result.getResultCode() != Activity.RESULT_OK) return null;
        Intent data = result.getData();
        return data == null ? null : data.getData();
    }

    // Trajno dopuštenje – datoteka ostaje dostupna i nakon ponovnog pokretanja
    private void persist(Uri uri) {
        try {
            getContext().getContentResolver()
                .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (Exception e) {
            try {
                getContext().getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
        }
    }

    private String displayName(Uri uri) {
        try (Cursor c = getContext().getContentResolver().query(uri, new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                String n = c.getString(0);
                if (n != null) return n;
            }
        } catch (Exception ignored) {}
        String last = uri.getLastPathSegment();
        return last == null ? "MySholdi.json" : last;
    }

    private String readUri(Uri uri) throws Exception {
        ContentResolver cr = getContext().getContentResolver();
        try (InputStream in = cr.openInputStream(uri)) {
            if (in == null) throw new Exception("cannot open");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        }
    }

    private void writeUri(Uri uri, byte[] bytes) throws Exception {
        ContentResolver cr = getContext().getContentResolver();
        Exception last = null;
        // "wt" = zapiši i skrati; neki pružatelji podržavaju samo "w" ili "rwt"
        for (String mode : new String[] { "wt", "rwt", "w" }) {
            try (OutputStream out = cr.openOutputStream(uri, mode)) {
                if (out == null) throw new Exception("cannot open");
                out.write(bytes);
                out.flush();
                return;
            } catch (SecurityException se) {
                throw se;
            } catch (Exception e) {
                last = e;
            }
        }
        throw last != null ? last : new Exception("write failed");
    }

    // ---------- Widgeti (dizajni; svaki widget na zaslonu ima svoj dizajn) ----------

    @PluginMethod
    public void updateWidget(PluginCall call) {
        String id = call.getString("id");
        String png = call.getString("png");
        if (id == null || png == null) {
            call.reject("missing args");
            return;
        }
        new Thread(() -> {
            try {
                WidgetStore.writeImage(getContext(), id, Base64.decode(png, Base64.DEFAULT));
                call.resolve();
            } catch (Exception e) {
                call.reject("widget update failed: " + e.getMessage(), e);
            }
        }).start();
    }

    @PluginMethod
    public void setWidgetDesigns(PluginCall call) {
        try {
            WidgetStore.writeDesigns(getContext(), call.getString("json", "[]"));
            call.resolve();
        } catch (Exception e) {
            call.reject("designs failed: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void refreshWidgets(PluginCall call) {
        WidgetBase.updateAll(getContext());
        call.resolve();
    }

    @PluginMethod
    public void pinWidget(PluginCall call) {
        String kind = call.getString("kind", "month");
        String designId = call.getString("designId");
        JSObject r = new JSObject();
        boolean ok = false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Context ctx = getContext();
            AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
            if (mgr.isRequestPinAppWidgetSupported()) {
                ComponentName cn = new ComponentName(ctx, WidgetBase.providerFor(kind));
                // povratni poziv: sustav doda ID novog widgeta, a mi ga povežemo s odabranim dizajnom
                Intent cb = new Intent(ctx, PinReceiver.class);
                cb.putExtra(PinReceiver.EXTRA_DESIGN, designId);
                cb.putExtra(PinReceiver.EXTRA_KIND, kind);
                int flags = PendingIntent.FLAG_UPDATE_CURRENT;
                if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
                PendingIntent pi = PendingIntent.getBroadcast(ctx, designId == null ? 0 : designId.hashCode(), cb, flags);
                ok = mgr.requestPinAppWidget(cn, null, pi);
            }
        }
        r.put("supported", ok);
        call.resolve(r);
    }

    // ---------- Vanjske poveznice, druge aplikacije, dijeljenje ----------

    @PluginMethod
    public void openUri(PluginCall call) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(Uri.parse(call.getString("uri", "")), call.getString("mime", "*/*"));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(Intent.createChooser(i, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            call.resolve();
        } catch (Exception e) {
            call.reject("cannot open: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void openUrl(PluginCall call) {
        try {
            String url = call.getString("url", "");
            Intent i = new Intent(url.startsWith("mailto:") ? Intent.ACTION_SENDTO : Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
            call.resolve();
        } catch (Exception e) {
            call.reject("cannot open: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void openApp(PluginCall call) {
        JSObject r = new JSObject();
        boolean opened = false;
        try {
            PackageManager pm = getContext().getPackageManager();
            Intent i = pm.getLaunchIntentForPackage(call.getString("package", ""));
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
                opened = true;
            }
        } catch (Exception ignored) {}
        r.put("opened", opened);
        call.resolve(r);
    }

    @PluginMethod
    public void shareText(PluginCall call) {
        try {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_SUBJECT, call.getString("title", ""));
            send.putExtra(Intent.EXTRA_TEXT, call.getString("text", ""));
            Intent chooser = Intent.createChooser(send, call.getString("title", "MySholdi"));
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(chooser);
            call.resolve();
        } catch (Exception e) {
            call.reject("share failed: " + e.getMessage(), e);
        }
    }

    // ---------- Biometrija (otisak prsta / lice) ----------

    private static final int AUTH = BiometricManager.Authenticators.BIOMETRIC_WEAK;

    @PluginMethod
    public void biometricAvailable(PluginCall call) {
        JSObject r = new JSObject();
        r.put("available", BiometricManager.from(getContext()).canAuthenticate(AUTH) == BiometricManager.BIOMETRIC_SUCCESS);
        call.resolve(r);
    }

    @PluginMethod
    public void biometricAuth(PluginCall call) {
        getActivity().runOnUiThread(() -> {
            try {
                BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                    .setTitle(call.getString("title", "MySholdi"))
                    .setSubtitle(call.getString("subtitle", ""))
                    .setNegativeButtonText(call.getString("cancel", "PIN"))
                    .setAllowedAuthenticators(AUTH)
                    .build();
                BiometricPrompt prompt = new BiometricPrompt(getActivity(), ContextCompat.getMainExecutor(getContext()),
                    new BiometricPrompt.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                            JSObject r = new JSObject();
                            r.put("success", true);
                            call.resolve(r);
                        }

                        @Override
                        public void onAuthenticationError(int code, CharSequence msg) {
                            JSObject r = new JSObject();
                            r.put("success", false);
                            r.put("error", String.valueOf(msg));
                            call.resolve(r);
                        }
                    });
                prompt.authenticate(info);
            } catch (Exception e) {
                JSObject r = new JSObject();
                r.put("success", false);
                r.put("error", e.getMessage());
                call.resolve(r);
            }
        });
    }
}
