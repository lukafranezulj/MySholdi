package com.mysholdi.app;

import android.content.Intent;
import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // Vlastiti nativni dodatak mora se registrirati prije super.onCreate
        registerPlugin(MySholdiPlugin.class);
        super.onCreate(savedInstanceState);
        MySholdiPlugin.captureLaunchIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }
}
