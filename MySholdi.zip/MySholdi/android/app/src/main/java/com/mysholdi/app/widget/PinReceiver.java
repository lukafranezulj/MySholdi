package com.mysholdi.app.widget;

import android.appwidget.AppWidgetManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Nakon "Dodaj na početni zaslon" iz aplikacije: novi widget dobiva odabrani dizajn. */
public class PinReceiver extends BroadcastReceiver {

    public static final String EXTRA_DESIGN = "designId";
    public static final String EXTRA_KIND = "kind";

    @Override
    public void onReceive(Context context, Intent intent) {
        int id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        String design = intent.getStringExtra(EXTRA_DESIGN);
        String kind = intent.getStringExtra(EXTRA_KIND);
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID || design == null) return;
        WidgetStore.assign(context, id, design);
        WidgetBase.updateOne(context, id, kind == null ? "month" : kind);
    }
}
