package com.mysholdi.app.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.widget.RemoteViews;
import com.mysholdi.app.MainActivity;
import com.mysholdi.app.MySholdiPlugin;
import com.mysholdi.app.R;
import java.io.File;
import org.json.JSONObject;

/**
 * Zajednička logika widgeta. Svaki widget na zaslonu prikazuje sliku svog dizajna.
 * Vrste: month (4×2), chart (4×2), quick (4×3), add1 (1×1), add2 (2×1).
 */
public abstract class WidgetBase extends AppWidgetProvider {

    protected abstract String kind();

    public static final String[] KINDS = { "month", "chart", "quick", "add1", "add2" };

    @Override
    public void onUpdate(Context context, AppWidgetManager mgr, int[] ids) {
        for (int id : ids) mgr.updateAppWidget(id, build(context, id, kind()));
    }

    @Override
    public void onDeleted(Context context, int[] ids) {
        for (int id : ids) WidgetStore.unassign(context, id);
    }

    public static Class<? extends WidgetBase> providerFor(String kind) {
        switch (kind == null ? "" : kind) {
            case "chart": return Widgets.Chart.class;
            case "quick": return Widgets.Quick.class;
            case "add1": return Widgets.AddSmall.class;
            case "add2": return Widgets.AddBar.class;
            default: return Widgets.Month.class;
        }
    }

    public static String kindOfProvider(String className) {
        for (String k : KINDS) if (providerFor(k).getName().equals(className)) return k;
        return "month";
    }

    /** Osvježi sve widgete svih vrsta. */
    public static void updateAll(Context ctx) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
        for (String k : KINDS) {
            int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, providerFor(k)));
            if (ids == null) continue;
            for (int id : ids) mgr.updateAppWidget(id, build(ctx, id, k));
        }
    }

    public static void updateOne(Context ctx, int appWidgetId, String kind) {
        AppWidgetManager.getInstance(ctx).updateAppWidget(appWidgetId, build(ctx, appWidgetId, kind));
    }

    static RemoteViews build(Context ctx, int appWidgetId, String kind) {
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_image);
        JSONObject d = WidgetStore.designFor(ctx, appWidgetId, kind);
        Bitmap bm = null;
        if (d != null) {
            File f = WidgetStore.image(ctx, d.optString("id"));
            if (f.exists()) bm = BitmapFactory.decodeFile(f.getAbsolutePath());
        }
        if (bm != null) {
            v.setImageViewBitmap(R.id.widget_image, bm);
            v.setViewVisibility(R.id.widget_image, View.VISIBLE);
            v.setViewVisibility(R.id.widget_empty, View.GONE);
        } else {
            v.setViewVisibility(R.id.widget_image, View.GONE);
            v.setViewVisibility(R.id.widget_empty, View.VISIBLE);
        }
        Intent i = new Intent(ctx, MainActivity.class);
        // vlastita akcija (ne LAUNCHER), da Android pozove onNewIntent kad je aplikacija već otvorena
        i.setAction("com.mysholdi.app.WIDGET_" + appWidgetId);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if ("quick".equals(kind)) i.putExtra(MySholdiPlugin.EXTRA_ACTION, "quickadd");
        if ("add1".equals(kind) || "add2".equals(kind)) {
            String type = d != null ? d.optString("entryType", "expense") : "expense";
            i.putExtra(MySholdiPlugin.EXTRA_ACTION, "quickadd:" + (type.isEmpty() ? "expense" : type));
        }
        PendingIntent pi = PendingIntent.getActivity(ctx, appWidgetId, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.widget_root, pi);
        return v;
    }
}
