package com.mysholdi.app.widget;

import android.app.Activity;
import android.app.AlertDialog;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.Intent;
import android.os.Bundle;
import com.mysholdi.app.R;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/** Odabir izgleda (dizajna) za widget – pri dodavanju ili dugim pritiskom na widget. */
public class WidgetConfigActivity extends Activity {

    private int widgetId = AppWidgetManager.INVALID_APPWIDGET_ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setResult(RESULT_CANCELED);
        Bundle extras = getIntent().getExtras();
        if (extras != null) widgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }
        AppWidgetProviderInfo info = AppWidgetManager.getInstance(this).getAppWidgetInfo(widgetId);
        final String kind = info != null ? WidgetBase.kindOfProvider(info.provider.getClassName()) : "month";
        JSONArray all = WidgetStore.designs(this);
        final List<String> ids = new ArrayList<>();
        List<String> names = new ArrayList<>();
        for (int i = 0; i < all.length(); i++) {
            JSONObject d = all.optJSONObject(i);
            if (d != null && kind.equals(d.optString("kind"))) {
                ids.add(d.optString("id"));
                names.add(d.optString("name", d.optString("id")));
            }
        }
        if (ids.size() <= 1) {
            if (ids.size() == 1) WidgetStore.assign(this, widgetId, ids.get(0));
            finishOk(kind);
            return;
        }
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Light_Dialog_Alert)
            .setTitle(R.string.widget_choose_design)
            .setItems(names.toArray(new String[0]), (dlg, which) -> {
                WidgetStore.assign(this, widgetId, ids.get(which));
                finishOk(kind);
            })
            .setOnCancelListener((dlg) -> finishOk(kind))
            .show();
    }

    private void finishOk(String kind) {
        WidgetBase.updateOne(this, widgetId, kind);
        Intent r = new Intent();
        r.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        setResult(RESULT_OK, r);
        finish();
    }
}
