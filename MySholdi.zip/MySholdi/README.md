# MySholdi

Android aplikacija za praćenje osobnih financija – prihodi, rashodi, neto imovina i kalkulator kredita. Logika je ista kao u Excel tablici „Prihodi i rashodi“: zbrojevi po naslovima i podnaslovima, prosjek mjesečno i dnevno (bez praznih mjeseci i nula), sažetak sa statistikom (SR, σ, Cv, MAX, MIN) i „bogatstvo“ u mjesecima i godinama.

**Verzija 1.3** · **Tehnologija:** [Capacitor 8](https://capacitorjs.com) (web sučelje u JavaScriptu) + mali nativni Android dio u Javi (datoteke u oblaku i widgeti).

---

## Što aplikacija radi

| Dio | Opis |
|---|---|
| **Naslovna** | Stanje za mjesec (prihodi, rashodi, razlika) i popis zadnjih unosa s datumom, vremenom, iznosom, kategorijom i **mjesecom za koji je iznos upisan**. Unosi se razvrstavaju po mjesecima (zadano, s razdjelnikom i zbrojem za svaki mjesec), po vremenu unosa ili po iznosu (najveći / najmanji prvo). Olovka uređuje unos, a kanta ga briše i oduzima iznos od kategorije. |
| **Lokot** | Ikona lokota lijevo od tipke Spremi. Zaključana tablica služi samo za pregled: nema gumba +, olovaka ni kanti, a polja se ne mogu mijenjati. Zadano je otključano. |
| **Gumb +** | Brzi unos: Rashod/Prihod, mjesec (zadano tekući), iznos i podnaslov kojem se iznos pribraja. |
| **Prihodi / Rashodi** | Ikona oka prebacuje između prikaza jednog mjeseca i svih mjeseci (tablica kao u Excelu). Olovka uključuje uređivanje naslova i podnaslova (preimenovanje, dodavanje i brisanje). Dodir na naziv otvara grafikon naslova ili podnaslova. |
| **Imovina** | Neto imovina po kvartalima (imovina − obveze) i bogatstvo u mjesecima i godinama. Ikona **i** objašnjava što se upisuje. Kartica je skrivena dok je ne uključiš u Postavkama → Tablice; tada je zadnja u donjem izborniku, nakon Sažetka. |
| **Sažetak** | Grafikon prihoda i rashoda, tablica, statistika (ikona **i** objašnjava SR, σ, Cv, MAX i MIN), udio rashoda po naslovima ili po svim podnaslovima za cijelu godinu te custom grafovi. Ikona **pisača** sprema cijelu tablicu za ispis na A4, kao **PDF** ili **Excel (.xlsx)**, s običnim tablicama ili s bojama i grafikonima; po želji s neto imovinom i popisom svih unosa. |
| **Boje** | Prihodi imaju blijedozelenu pozadinu, Rashodi blijedocrvenu, a Sažetak blijedožutu. Boje grafova (prihodi, rashodi, razlika i 12 boja kategorija) mijenjaju se u Postavkama; svaka serija u custom grafu može imati svoju boju. Grafovi imaju i prikaz pitom. |
| **Prebaci svoju tablicu** | Stavka u izborniku (zeleni tekst). Daje upute i gotov tekst za AI alat (ChatGPT, Claude, Gemini…) koji postojeću tablicu pretvori u MySholdi format. Rezultat zalijepiš u aplikaciju ili učitaš kao .json datoteku. |
| **Proračunske tablice** | Više tablica s različitim nazivima (npr. po godinama). Možeš ih preimenovati, povezati s oblakom, izvesti ili obrisati. Gumb **Primjer tablice** stvara tablicu popunjenu prosjekom za Hrvatsku (neto plaća ≈ 1.542 € prema DZS-u, struktura potrošnje kućanstava prema DZS-u). ⋯ → **Sakrij tablicu** skriva tablicu iz cijele aplikacije (popisi, widgeti, grafovi); vraća se gumbom **Skrivene tablice** → ⋯ → **Otkrij tablicu**. |
| **Zajedničke tablice** | Više ljudi upisuje u istu tablicu spremljenu na Google Driveu ili Dropboxu jednog korisnika. Izmjene se spajaju automatski (iznosi se zbrajaju, unosi se dodaju, a uz svaki unos piše tko ga je upisao). Upute korak po korak otvara ikona **i**, a gumb „Pozovi suradnike“ otvara Drive i šalje poruku s uputama. Izmjene se šalju u oblak odmah nakon unosa. ⋯ nudi **Izvezi kopiju** i **Kopiraj u Proračunske tablice** (osobna kopija koja se ne dijeli). U Postavkama se može uključiti da su zajedničke tablice bez interneta samo za pregled. |
| **Custom grafovi** | Vlastiti grafovi s odabranim naslovima, podnaslovima i mjesecima, i iz više tablica (npr. usporedba 2025. i 2026.). Iznad „+ Dodaj na graf“ vidi se boja sljedećeg podatka (dodirom se bira druga). Ikona ⛶ otvara graf preko cijelog zaslona s legendom i tablicom po mjesecima (izlaz: Natrag ili X). Dostupni su u izborniku, u Sažetku i kao widget (Widgets → Novi widget → Graf iz Custom grafova ili ikona widgeta na kartici grafa). |
| **Widgets** | Pet vrsta: trenutni mjesec (4×2), grafikon (4×2: prihodi i rashodi, kategorije, podnaslovi za cijelu godinu, neto imovina ili custom graf), zadnji unosi (4×3) te brzi unos troška 1×1 i 2×1. Možeš imati više widgeta iste vrste, svaki sa svojim izgledom. |
| **Postavke** | Prikaz neto imovine, prosjek s nulama ili bez njih (zadano: bez praznih ćelija i nula), boje grafova, jezik (hrvatski je zadan, može i engleski), valuta (zadano EUR, a može se upisati bilo koja druga), tvoje ime za zajedničke tablice, **zaključavanje aplikacije PIN-om i otiskom prsta ili licem**, automatska sinkronizacija i popis mjesta pohrane. |
| **Kalkulator kredita** | Tri načina: po rati, po iznosu i po trajanju. Klizači i ručni unos, a u naprednim postavkama inflacija (stvarni trošak u današnjem novcu), naknada, EKS i otplatni plan. |
| **Koš za smeće** | Obrisane tablice, naslovi, podnaslovi i unosi čuvaju se 30 dana, a zatim se trajno brišu. |
| **Tablet i rotacija** | Na tabletu je izbornik stalno otvoren, a kategorije su u dva ili tri stupca. U vodoravnom položaju sučelje se prilagođava nižem ekranu. |

### Spremanje i sinkronizacija
* Sve se **uvijek** sprema lokalno u mapu aplikacije, pa radi i bez interneta.
* Tipka **Spremi** (ikona u gornjem desnom kutu) nudi izbor mjesta: **Google Drive, Dropbox, OneDrive ili mapa na mobitelu**, te **iCloud** (s uputama, jer ga Android ne podržava). Za to se koristi Androidov sustavni izbornik datoteka, pa ne trebaju nikakvi API ključevi. Dovoljno je da je na mobitelu instalirana aplikacija Drive ili Dropbox.
* **Automatska sinkronizacija** (u Postavkama): ako ne pritisneš Spremi, tablica se u oblak sprema sama 5 s nakon zadnje izmjene.
* Ikona oblaka gore desno: **zelena** samo kad je tablica stvarno zapisana u oblak, **narančasta** kad nema interneta (spremljeno lokalno, šalje se čim se spojiš), **crvena** kad zapis u oblak ne uspije.
* Ako spremanje u oblak ne uspije, pojavi se obavijest i crveni natpis s tipkom **Pokušaj ponovno**, izbornikom **⋯** (Spremi na novu lokaciju, **Provjeri pristup datoteci u oblaku** – pokazuje korak po korak gdje zapinje: internet, aplikacija oblaka, dopuštenje, postoji li datoteka, čitanje, pisanje, sadržaj) i ikonom **i** s uputama. Podaci tada ostaju lokalno i šalju se automatski čim se vrati veza.
* **Na novom mobitelu:** instaliraj aplikaciju, odaberi **„Učitaj iz datoteke (Drive, Dropbox, lokalno)“** i otvori svoju datoteku `MySholdi - <naziv>.json`. Tablica se učita i ostaje povezana s tom datotekom.
* Ako se ista tablica uređuje na dva mobitela (ili je dijeli više ljudi), aplikacija izmjene **spaja, a nikad ne prepisuje**: prije svakog zapisa pročita datoteku u oblaku i spoji je s lokalnom (unija unosa, naslova i podnaslova). Svaki unos ima svoj ID, pa unos koji je netko upisao bez interneta samo se doda kad se spoji – tuđi unosi ostaju. Brisanje se pamti kao oznaka s vremenom (ne kao „nedostaje“), pa ga stariji mobitel ne može vratiti. Za nazive vrijedi najnovija izmjena.
* Zašto ne zasebna datoteka za svakog člana: Android preko Drivea daje aplikaciji pristup samo odabranoj datoteci, ne cijeloj mapi, pa aplikacija ne bi mogla pročitati datoteke drugih članova. Spajanje u jednoj datoteci daje isti rezultat (ničiji podaci se ne gube).
* Možeš uvesti i JSON izvoz iz stare HTML tablice „Prihodi i rashodi“.

---

## Web inačica (računalo, tablet, mobitel u pregledniku)

Ista aplikacija radi i u pregledniku. Prilagođava se zaslonu (mobitel / tablet / računalo), a u Postavkama → **Izgled sučelja** izgled se može odabrati i ručno (na računalu se tada prikaže u okviru).

* **Na webu:** workflow `.github/workflows/web.yml` pri svakom pushu izgradi stranicu i objavi je na **GitHub Pages** – jednokratno uključi u repozitoriju *Settings → Pages → Source: GitHub Actions*. Adresa: `https://<korisnik>.github.io/<repozitorij>/`. Stranica se može i „instalirati“ (Chrome/Edge: ikona u adresnoj traci).
* **Brave:** izravno spremanje u datoteku je u Braveu isključeno – uključuje se u `brave://flags` → *File System Access API* → *Enabled* (ili koristi Chrome / Edge). Bez toga se učitava kopija, a sprema s „Izvezi kopiju“.
* **Lokalno na računalu:** u izborniku web stranice **Preuzmi za korištenje na računalu** preuzima `MySholdi.html` – jednu datoteku sa svim kodom. Otvori je dvoklikom (Chrome ili Edge); radi bez interneta. Ista datoteka je i u artefaktu **MySholdi-web** svakog pokretanja workflowa.
* **iCloud:** na računalu instaliraj **iCloud za Windows** (Microsoft Store) – u Exploreru se pojavi mapa **iCloud Drive** (zadano `C:\Users\<ime>\iCloud Drive`); na Macu je iCloud Drive u Finderu. Datoteka se učita i ostaje povezana kao i kod Google Drivea. Na iPhoneu/iPadu (Safari) datoteka se bira preko *Pregledaj → iCloud Drive*, ali učitava se kopija, a izmjene se spremaju s „Izvezi kopiju“ (Datoteke → iCloud Drive). **Na Androidu iCloud nije moguć** – Apple ne nudi iCloud Drive za Android, pa ga izbornik datoteka ne prikazuje; u aplikaciji opcija *iCloud* objašnjava mogućnosti (web inačica, izvoz kopije, ili Google Drive / Dropbox / OneDrive koji rade na oba sustava).
* **Google Drive na računalu:** preglednik ne može izravno otvoriti Drive na internetu, nego samo datoteke na računalu. Jednom instaliraj **Google Drive za računalo** (google.com/drive/download) – Drive se pojavi kao disk **G:**. Zatim „Učitaj iz datoteke“ → *Ovaj PC → Google Drive (G:) → Moj disk* → `MySholdi - <naziv>.json` → dopusti uređivanje. Tablica ostaje povezana s datotekom (Chrome i Edge), izmjene se spremaju u nju, a Drive ih šalje u oblak, pa ih vidi i mobitel. Isto vrijedi za Dropbox i OneDrive. Preglednik pamti mapu, a nakon ponovnog otvaranja stranice pri prvom kliku ponovo pita za dopuštenje.
* U Firefoxu i Safariju podaci se čuvaju u pregledniku, a kopija se sprema s „Izvezi kopiju“.
* U pregledniku nema widgeta ni otiska prsta (PIN radi).
* Lokalna izgradnja: `npm run build:web` → mapa `web/`.

---

## Kako dobiti APK (bez instalacije ičega na računalo)

1. Na GitHubu napravi **novi privatni repozitorij** (npr. `MySholdi`).
2. Raspakiraj ZIP i u repozitorij prenesi **sadržaj** mape `MySholdi` (uključujući skrivenu mapu `.github`). Najlakše je s aplikacijom GitHub Desktop ili naredbama:
   ```bash
   cd MySholdi
   git init
   git add .
   git commit -m "MySholdi 1.0"
   git branch -M main
   git remote add origin https://github.com/<tvoje-ime>/MySholdi.git
   git push -u origin main
   ```
   > Ako prenosiš kroz web sučelje (Add file → Upload files), provjeri je li se prenijela i mapa `.github/workflows`. Neki preglednici skrivene mape preskaču, a bez nje se build neće pokrenuti.
3. Otvori karticu **Actions**. Workflow **„Android build“** pokreće se sam i traje oko 5–8 minuta.
4. Kad završi (zelena kvačica), otvori taj build i pod **Artifacts** preuzmi `MySholdi-1.0.x` (ZIP). Unutra je `MySholdi-1.0.x-debug.apk`.
5. Prebaci APK na mobitel i otvori ga. Android će tražiti dopuštenje za instalaciju iz nepoznatih izvora.

### Preporučeno: potpisani APK (da nadogradnje ne brišu podatke)
Debug APK potpisuje se privremenim ključem GitHub poslužitelja, a on se može razlikovati od builda do builda. Tada Android ne dopušta nadogradnju preko stare verzije, pa aplikaciju moraš deinstalirati, a time se brišu i lokalni podaci (zato koristi sinkronizaciju s Driveom). Uz vlastiti ključ svaka nova verzija instalira se preko stare bez gubitka podataka:

1. **Actions → „Create signing key“ → Run workflow.**
2. Preuzmi artefakt `mysholdi-signing-key`. Sadrži `mysholdi-release.jks`, `KEYSTORE_BASE64.txt` i `UPUTE.txt` s lozinkom.
3. Pohrani `.jks` i lozinku **na sigurno, zauvijek** (npr. u upravitelj lozinki ili na USB). Bez toga ključa na Google Playu ne možeš objaviti nadogradnju.
4. **Settings → Secrets and variables → Actions → New repository secret:** dodaj `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS` i `KEY_PASSWORD` (vrijednosti su u `UPUTE.txt`).
5. Obriši artefakt s ključem (Actions → taj build → Artifacts → kanta).
6. Pokreni **Android build** ponovno (Actions → Android build → Run workflow). Sada dobivaš i `MySholdi-1.0.x.apk` (potpisani release) i `MySholdi-1.0.x.aab` (za Google Play).

### Izdanja (Releases)
Kad napraviš oznaku, npr. `git tag v1.1.0 && git push --tags`, workflow uz artefakt napravi i **GitHub Release** s APK-om i AAB-om, a verzija aplikacije bude `1.1.0`. Broj verzije (versionCode) raste automatski sa svakim buildom.

---

## Lokalni razvoj (neobavezno)

Potrebno: Node.js 22+, JDK 21 i Android Studio (Android SDK 36).

```bash
npm install
npm run serve          # web sučelje u pregledniku na http://localhost:8080
npm run build:web      # web inačica u web/ (stranica + MySholdi-offline.html)
npm run sync           # izgradi web dio i kopira ga u android/
npx cap open android   # otvori u Android Studiju → Run
# ili iz naredbenog retka:
cd android && ./gradlew assembleDebug    # APK: android/app/build/outputs/apk/debug/
```

Za lokalno potpisani release kopiraj `android/keystore.properties.example` u `android/keystore.properties`, upiši podatke i pokreni `./gradlew assembleRelease bundleRelease`.

### Struktura projekta
```
src/                 web aplikacija (JavaScript, bez frameworka; esbuild je spaja u www/)
  main.js            pokretanje, izbornik, navigacija, tipka natrag
  model.js           zadane kategorije, izračuni (kao u Excelu), izmjene, spajanje verzija (unija + oznake brisanja)
  sync.js            lokalno + oblak, autospremanje nakon 5 s, zajedničke odmah, ponovni pokušaji, obavijesti
  cloudDiag.js       izbornik greške spremanja i provjera pristupa datoteci korak po korak
  cloud.js           povezivanje s Drive/Dropbox/lokalnom datotekom, uvoz/izvoz
  widgets.js         iscrtavanje widgeta u PNG
  loanCalc.js        izračuni kredita (anuitet, rok, inflacija, EKS)
  trash.js           koš za smeće (30 dana)
  graphs.js          custom grafovi (podaci iz više tablica)
  lock.js            zaključavanje (PIN + biometrija)
  sample.js          primjer tablice (prosjek za Hrvatsku)
  config.js          verzija, poveznica za donaciju
  export.js          ispis/izvoz: PDF (jsPDF + autotable, font Roboto s hrvatskim slovima) i Excel
  xlsx.js            vlastiti zapis .xlsx datoteke (fflate)
  importOwn.js       "Prebaci svoju tablicu" – prompt za AI i uvoz JSON-a
  fonts/             Roboto (Apache 2.0) za PDF
  i18n.js            prijevodi HR/EN
  views/             ekrani
android/             nativni projekt (Capacitor)
  app/src/main/java/com/mysholdi/app/MySholdiPlugin.java   datoteke (SAF), widgeti
  app/src/main/java/com/mysholdi/app/widget/               pružatelji widgeta, odabir izgleda, pohrana dizajna
.github/workflows/   automatska izgradnja APK/AAB, web inačice (GitHub Pages) i stvaranje ključa
build-web.mjs        izgradnja web inačice i samostalne HTML datoteke
store/               ikona 512×512 i grafika 1024×500 za Google Play
PLAY_STORE_UPUTE.md  upute za objavu na Google Play
PRIVACY_POLICY.md    pravila privatnosti (potrebna za Google Play)
```

### Napomene
* Widgeti prikazuju sliku koju iscrtava aplikacija. Osvježavaju se pri svakoj izmjeni, a kad počne novi mjesec, dovoljno je otvoriti aplikaciju.
* Widget dodan iz aplikacije dobiva odabrani izgled. Widget dodan izravno s početnog zaslona dobiva prvi izgled te vrste, a drugi se bira dugim pritiskom na widget → postavke widgeta (Android 12+).
* Zajedničke tablice: aplikacija ne može sama dijeliti datoteke na Google Driveu, nego pristup daješ ti u aplikaciji Drive ili Dropbox (upute su pod ikonom **i**). Izmjene drugih stižu unutar otprilike pola minute dok je tablica otvorena, a odmah kad pritisneš „Osvježi“.
* Zaboravljeni PIN ne može se vratiti. Tada treba obrisati podatke aplikacije i ponovno učitati tablice iz oblaka.
* Poveznica „Počasti developera kavom“ nalazi se u `src/config.js` (`DONATE_URL`).
* Neki pokretači (launcheri) ne podržavaju tipku „Dodaj na početni zaslon“. Tada widget dodaješ dugim pritiskom na početni zaslon → Widgeti → MySholdi.
* Google uvodi provjeru razvojnih programera za instalaciju aplikacija izvan Google Playa. U 2026. ona vrijedi samo u Brazilu, Indoneziji, Singapuru i Tajlandu, a globalno se širi 2027. Ako tada instalacija vlastitog APK-a bude tražila dodatni korak, Android nudi napredni postupak instalacije ili instalaciju preko ADB-a. Alternativa je objava na Google Playu (vidi `PLAY_STORE_UPUTE.md`).

---
Prijedlozi i pitanja: **lukafrane.zulj@gmail.com** (i u izborniku aplikacije).
