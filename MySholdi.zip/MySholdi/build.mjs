// Izgradnja web dijela: src/ -> www/ (esbuild)
import { build } from 'esbuild';
import { copyFileSync, mkdirSync, rmSync } from 'fs';

const dev = process.argv.includes('--dev');
rmSync('www', { recursive: true, force: true });
mkdirSync('www', { recursive: true });
await build({
  entryPoints: { app: 'src/main.js' }, bundle: true, outdir: 'www', format: 'esm', splitting: true,
  chunkNames: 'chunks/[name]-[hash]', target: ['chrome89'], minify: !dev, sourcemap: dev, legalComments: 'none',
  loader: { '.ttf': 'base64' },
});
copyFileSync('src/index.html', 'www/index.html');
copyFileSync('src/app.css', 'www/app.css');
console.log('www/ izgrađen');
