# Objava aplikacije MojiSholdi na Google Play

Ovo je redoslijed koraka od GitHub buildova do aplikacije u trgovini. Za prvu objavu računaj s oko 3 tjedna, uglavnom zbog obveznog zatvorenog testiranja.

> Pravila Google Playa se mijenjaju. Prije objave provjeri trenutne zahtjeve u Play Consoleu (pravila su ažurna na dan izrade ovih uputa, studeni 2026.).

---

## 0. Što ti treba

| Stvar | Gdje je |
|---|---|
| Potpisani **AAB** (`MojiSholdi-x.y.z.aab`) | GitHub → Actions → Android build → Artifacts (nakon postavljanja ključa, vidi README) |
| Ključ za potpisivanje (`mysholdi-release.jks` + lozinka) | iz workflowa „Create signing key“. **Čuvaj ga zauvijek.** |
| Ikona 512×512 | `store/play-icon-512.png` |
| Naslovna grafika 1024×500 | `store/feature-graphic-1024x500.png` |
| Snimke zaslona (1080×1920) | `store/screenshots/hr_*.png` i `en_*.png` |
| Tekstovi za trgovinu | `store/listing.md` |
| Pravila privatnosti (javni URL) | sadržaj datoteke `PRIVACY_POLICY.md` (vidi korak 4) |

Aplikacija već cilja **Android 16 (API 36)** (`targetSdkVersion = 36` u `android/variables.gradle`), a to je obvezno za nove aplikacije i nadogradnje od 31. 8. 2026. Kad Google sljedeće godine podigne zahtjev, povećaj `compileSdkVersion` i `targetSdkVersion` (najlakše nadogradnjom Capacitora: `npm i @capacitor/core@latest @capacitor/android@latest @capacitor/cli@latest && npx cap sync`).

---

## 1. Račun razvojnog programera

1. Otvori <https://play.google.com/console> i prijavi se Google računom.
2. Odaberi vrstu računa:
   * **Osobni (Personal)**. Jednostavniji je, ali novi osobni računi moraju prije objave proći **zatvoreno testiranje s najmanje 12 testera kroz 14 dana zaredom** (korak 7).
   * **Organizacija**. Zahtijeva D-U-N-S broj tvrtke ili OPG-a (može potrajati i do 30 dana), ali za nju nema obveze od 12 testera.
3. Plati jednokratnu pristojbu od **25 USD**.
4. Dovrši **provjeru identiteta** (osobna iskaznica, adresa, broj mobitela). Odobrenje obično traje nekoliko dana.

## 2. Stvaranje aplikacije

**Play Console → Create app:**
* Naziv: **MojiSholdi**
* Zadani jezik: **hrvatski – hr**
* Aplikacija ili igra: **App**; besplatna ili plaćena: **Free**
* Potvrdi izjave (Developer Program Policies, US export laws).

## 3. Potpisivanje (Play App Signing)

Kod prvog izdanja Play Console nudi **Play App Signing**. Prihvati ga. Tvoj ključ `mysholdi-release.jks` tada postaje **upload key**: njime potpisuješ AAB koji šalješ, a Google aplikaciju potpisuje vlastitim ključem za distribuciju.
* Ako ikad izgubiš upload key, u Play Consoleu (Setup → App signing) možeš zatražiti njegovu zamjenu.
* Paket aplikacije je `com.mysholdi.app` i **nakon objave se ne može mijenjati**. Ako želiš drukčiji naziv paketa, promijeni ga prije prve objave u `capacitor.config.json` (`appId`), `android/app/build.gradle` (`namespace` i `applicationId`) i u mapi `android/app/src/main/java/com/mysholdi/app/`.

## 4. Pravila privatnosti (obvezno)

Google traži **javni URL** s pravilima privatnosti. Tekst je spreman u `PRIVACY_POLICY.md`. Najjednostavnije opcije:
* **GitHub Gist:** <https://gist.github.com> → zalijepi sadržaj → *Create public gist* → kopiraj URL.
* ili **Google Sites** ili **Notion** (javna stranica).
* GitHub Pages iz privatnog repozitorija radi samo uz plaćeni GitHub plan.

U `PRIVACY_POLICY.md` prije objave upiši svoj e-mail za kontakt.

## 5. App content (Policy → App content)

Ispuni sve odjeljke. Prijedlozi odgovora za MojiSholdi:

| Odjeljak | Odgovor |
|---|---|
| **Privacy policy** | URL iz koraka 4 |
| **App access** | „All functionality is available without special access“ (nema prijave) |
| **Ads** | No, my app does not contain ads |
| **Content rating** | Upitnik → kategorija *Utility, Productivity, Communication, or Other* → na sva pitanja o nasilju, kockanju i sl. odgovori **No**. Rezultat bi trebao biti PEGI 3 / Everyone. |
| **Target audience** | **18+** (financijska aplikacija; tako izbjegavaš dodatna pravila za djecu) |
| **News app** | No |
| **Data safety** | vidi tablicu ispod |
| **Government app** | No |
| **Financial features** | Aplikacija ne nudi kredite, plaćanja ni ulaganja. Kalkulator samo računa. Odaberi opciju da aplikacija **ne pruža** regulirane financijske usluge (npr. „My app doesn't provide any financial features“ ili najbližu opciju za alate za budžetiranje). |
| **Health** | No |

### Data safety (sigurnost podataka)
* **Does your app collect or share any of the required user data types?** → **No**.
  Obrazloženje: svi podaci ostaju na uređaju. Kad korisnik sam odabere Google Drive ili Dropbox, datoteku zapisuje sustavni izbornik datoteka u **korisnikov** račun. Razvojni programer ne prima nikakve podatke, a aplikacija nema analitiku ni oglase.
* **Is all of the user data collected by your app encrypted in transit?** → nije primjenjivo (nema prikupljanja).
* **Do you provide a way for users to request that their data is deleted?** → podaci se brišu iz aplikacije (koš za smeće, brisanje tablice) ili deinstalacijom.
* **Zajedničke tablice:** i dalje „No“. Datoteku dijeli sam korisnik preko svog Google Drivea ili Dropboxa, a podaci ne prolaze kroz poslužitelje razvojnog programera.
* **Biometrija:** provjeru otiska prsta ili lica obavlja Android (BiometricPrompt). Aplikacija ne dobiva biometrijske podatke, nego samo rezultat „uspjelo/neuspjelo“. PIN se čuva kao sažetak (hash) samo na uređaju.

## 6. Izgled u trgovini (Grow → Store presence → Main store listing)

* **App name:** MojiSholdi
* **Short description** (do 80 znakova) i **Full description**: kopiraj iz `store/listing.md` (hrvatski i engleski; engleski dodaj kao prijevod).
* **App icon:** `store/play-icon-512.png`
* **Feature graphic:** `store/feature-graphic-1024x500.png`
* **Phone screenshots:** najmanje 2, a preporuka je 4–6, iz `store/screenshots/`.
* **Category:** Finance; **Tags:** Budget, Personal finance.
* **Contact details:** e-mail (obvezno).

## 7. Zatvoreno testiranje (obvezno za nove osobne račune)

1. **Test and release → Testing → Closed testing → Create track** (ili koristi zadani „Alpha“).
2. **Testers:** napravi popis e-mail adresa (Gmail) s **najmanje 12 osoba**; preporuka je 14–15 za slučaj da netko odustane.
3. **Create new release** → prenesi `MojiSholdi-x.y.z.aab` → upiši bilješke izdanja → **Review release → Start rollout**.
4. Kad Google odobri izdanje (obično 1–3 dana), pošalji testerima **link za pristup** (opt-in URL). Svaki tester mora prihvatiti poziv i instalirati aplikaciju s Google Playa.
5. Testeri moraju ostati prijavljeni **14 dana zaredom**. Ako broj padne ispod 12, odbrojavanje kreće ispočetka.
6. Tijekom testa nemoj objavljivati puno novih verzija. Popravke ostavi za kasnije.

## 8. Zahtjev za produkciju i objava

1. Nakon 14 dana: **Dashboard → Apply for production**. Odgovori na pitanja o testiranju: kako su testeri koristili aplikaciju, koje su povratne informacije dali i što si popravio.
2. Nakon odobrenja: **Production → Create new release** → isti ili noviji AAB → odaberi države (npr. sve) → **Start rollout to Production**.
3. Pregled obično traje od nekoliko sati do nekoliko dana.

## 9. Nadogradnje

1. Promijeni kod, napravi commit i označi novu verziju:
   ```bash
   git tag v1.1.0
   git push && git push --tags
   ```
2. GitHub Actions napravi `MySholdi-1.1.0.aab`. Broj verzije (versionCode) raste sam s brojem buildova.
3. Play Console → Production (ili Closed testing) → **Create new release** → prenesi AAB → objavi.

> Korisnici koji su aplikaciju instalirali s Google Playa ne mogu preko nje instalirati APK s GitHuba (i obrnuto), jer Google aplikaciju potpisuje svojim ključem. Kad se aplikacija preseli na Play, instaliraj je odande. Podatke sačuvaj tako da tablicu prije deinstalacije povežeš s Driveom.

---

### Česti problemi
* **„Your app must target API level 36“**: provjeri `android/variables.gradle` (`targetSdkVersion = 36`).
* **„You uploaded an APK or Android App Bundle that was signed in debug mode“**: prenesi release AAB, koji nastaje tek kad su postavljene GitHub tajne za ključ.
* **„Version code X has already been used“**: pokreni novi build. Svaki build ima veći versionCode.
* **Odbijeno zbog pravila privatnosti**: URL mora biti javan, bez prijave, i navoditi naziv aplikacije te kontakt.
