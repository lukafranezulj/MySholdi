// Most prema nativnom Android dijelu (datoteke preko Storage Access Frameworka, widgeti).
// U pregledniku se koristi zamjenska (web) izvedba – za razvoj i testiranje.
import { Capacitor, registerPlugin } from '@capacitor/core';

export const isNative = Capacitor.isNativePlatform();
const Native = registerPlugin('MySholdi');

// ----- Web inačica -----
// U pregledniku na računalu (Chrome, Edge) koristi se File System Access API: korisnik odabere datoteku,
// npr. u mapi Google Drive / Dropbox / OneDrive na računalu, i aplikacija u nju sprema automatski.
// window.__testCloud = true: simulirani "oblak" u localStorage (za automatske testove).
const webStore = {
  get(k) { try { return localStorage.getItem('webdoc:' + k); } catch (e) { return null; } },
  set(k, v) { try { localStorage.setItem('webdoc:' + k, v); } catch (e) { } },
};
export const fsaSupported = () => !isNative && typeof window !== 'undefined' && 'showSaveFilePicker' in window && !window.__testCloud;
// spremanje "ručki" datoteka u IndexedDB (ostaju i nakon zatvaranja preglednika)
function idb() {
  return new Promise((res, rej) => {
    const r = indexedDB.open('mysholdi-handles', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('h');
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  });
}
async function idbOp(mode, fn) { const db = await idb(); return new Promise((res, rej) => { const tx = db.transaction('h', mode); const st = tx.objectStore('h'); const q = fn(st); tx.oncomplete = () => res(q && q.result); tx.onerror = () => rej(tx.error); }); }
const handleCache = new Map(); // ručke u memoriji (IndexedDB se čita samo nakon ponovnog otvaranja)
const putHandle = (k, h) => { handleCache.set(k, h); return idbOp('readwrite', (st) => st.put(h, k)); };
const getHandle = async (k) => { if (!handleCache.has(k)) handleCache.set(k, await idbOp('readonly', (st) => st.get(k))); return handleCache.get(k); };
// uvijek tražimo čitanje i pisanje odjednom (jedno pitanje preglednika umjesto dva)
async function ensurePerm(h) {
  if ((await h.queryPermission({ mode: 'readwrite' })) === 'granted') return true;
  try { return (await h.requestPermission({ mode: 'readwrite' })) === 'granted'; } catch (e) { return false; }
}
const JSON_TYPES = [{ description: 'MySholdi', accept: { 'application/json': ['.json'] } }];
// id: preglednik pamti zadnju mapu (npr. G:\Moj disk\MySholdi) pa se sljedeći put otvara ondje
const PICK = { id: 'mysholdi', startIn: 'documents', types: JSON_TYPES };
// Nakon ponovnog otvaranja stranice preglednik ponovo traži dopuštenje za datoteku.
// Traži se pri prvom dodiru/kliku (preglednik dopušta pitanje samo nakon radnje korisnika).
const asked = new Set();
export async function webRegrant(uri) {
  if (isNative || !String(uri).startsWith('fsa:') || asked.has(uri)) return false;
  const h = await getHandle(uri); if (!h) return false;
  if ((await h.queryPermission({ mode: 'readwrite' })) === 'granted') return false;
  asked.add(uri);
  try { return (await h.requestPermission({ mode: 'readwrite' })) === 'granted'; } catch (e) { return false; }
}

function pickFileWeb() {
  return new Promise((resolve, reject) => {
    const inp = document.createElement('input');
    inp.type = 'file'; inp.accept = '.json,application/json';
    inp.onchange = () => {
      const f = inp.files[0]; if (!f) return reject(new Error('cancelled'));
      const r = new FileReader();
      r.onload = () => resolve({ uri: 'webfile:' + f.name, name: f.name, data: r.result });
      r.onerror = () => reject(new Error('read'));
      r.readAsText(f);
    };
    inp.click();
  });
}
function downloadWeb(name, data) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([data], { type: 'application/json' }));
  a.download = name; document.body.appendChild(a); a.click(); a.remove();
}

// Odabir mjesta za novu datoteku (Google Drive, Dropbox, lokalna mapa…)
export async function createDocument(fileName) {
  if (isNative) return Native.createDocument({ fileName });
  if (fsaSupported()) {
    const h = await window.showSaveFilePicker({ ...PICK, suggestedName: fileName });
    const uri = 'fsa:' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    await putHandle(uri, h);
    return { uri, name: h.name };
  }
  if (window.__testCloud) return { uri: 'web:' + fileName, name: fileName };
  throw new Error('nolink');
}
// Otvaranje postojeće datoteke
export async function openDocument() {
  if (isNative) return Native.openDocument();
  if (fsaSupported()) {
    const [h] = await window.showOpenFilePicker({ ...PICK, multiple: false });
    const uri = 'fsa:' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    await putHandle(uri, h);
    // odmah zatraži i pisanje (dok još vrijedi korisnikov klik), da se izmjene mogu spremati u istu datoteku
    try { await h.requestPermission({ mode: 'readwrite' }); } catch (e) { }
    return { uri, name: h.name, data: await (await h.getFile()).text() };
  }
  return pickFileWeb();
}
export async function writeDocument(uri, data) {
  if (isNative) return Native.writeDocument({ uri, data });
  if (String(uri).startsWith('fsa:')) {
    const h = await getHandle(uri); if (!h) throw new Error('notfound');
    if (!(await ensurePerm(h))) throw new Error('permission');
    const w = await h.createWritable(); await w.write(data); await w.close();
    return { ok: true };
  }
  if (window.__mockCloudFail) throw new Error('write failed: provider error');
  webStore.set(uri, data);
  return { ok: true };
}
export async function readDocument(uri) {
  if (isNative) return (await Native.readDocument({ uri })).data;
  if (String(uri).startsWith('fsa:')) {
    const h = await getHandle(uri); if (!h) throw new Error('notfound');
    if (!(await ensurePerm(h))) throw new Error('permission');
    return (await h.getFile()).text();
  }
  if (window.__mockCloudFail) throw new Error('read failed: provider error');
  const d = webStore.get(uri);
  if (d === null) throw new Error('notfound');
  return d;
}
export async function releaseDocument(uri) {
  if (isNative) { try { await Native.releaseDocument({ uri }); } catch (e) { } }
}
// Provjera pristupa datoteci (za dijagnostiku)
export async function checkDocument(uri) {
  if (isNative) return Native.checkDocument({ uri });
  try { await readDocument(uri); return { web: true, exists: true }; } catch (e) { return { web: true, exists: false, error: String(e.message || e) }; }
}
export async function appInstalled(pkg) {
  if (!isNative) return true;
  try { return (await Native.appInstalled({ package: pkg })).installed === true; } catch (e) { return false; }
}
// Jednokratni izvoz kopije (bez povezivanja)
export async function exportCopy(fileName, data) {
  if (isNative) { const r = await Native.createDocument({ fileName }); await Native.writeDocument({ uri: r.uri, data }); return r; }
  downloadWeb(fileName, data); return { name: fileName };
}

// Spremanje binarne datoteke (PDF, Excel): korisnik bira mjesto (Preuzimanja, Drive…)
export async function saveBinary(fileName, mime, base64) {
  if (isNative) {
    const r = await Native.createDocument({ fileName, mime });
    await Native.writeDocument({ uri: r.uri, data: base64, base64: true });
    return r;
  }
  const bin = atob(base64); const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([bytes], { type: mime }));
  a.download = fileName; document.body.appendChild(a); a.click(); a.remove();
  return { name: fileName };
}
export async function openSavedFile(uri, mime) {
  if (!isNative || !uri) return;
  try { await Native.openUri({ uri, mime }); } catch (e) { }
}

// ----- Widgeti (svaki dizajn ima svoju sliku; svaki widget na zaslonu ima svoj dizajn) -----
export async function updateWidget(designId, pngDataUrl) {
  if (!isNative) return;
  try { await Native.updateWidget({ id: designId, png: pngDataUrl.split(',')[1] }); } catch (e) { console.warn('widget', e); }
}
export async function setWidgetDesigns(list) {
  if (!isNative) return;
  try { await Native.setWidgetDesigns({ json: JSON.stringify(list) }); } catch (e) { console.warn('designs', e); }
}
export async function refreshAllWidgets() {
  if (!isNative) return;
  try { await Native.refreshWidgets(); } catch (e) { }
}
export async function pinWidget(kind, designId) {
  if (!isNative) return { supported: false, web: true };
  return Native.pinWidget({ kind, designId });
}

// ----- Ostalo: vanjske poveznice, dijeljenje, druge aplikacije -----
export async function openUrl(url) {
  if (isNative) { try { await Native.openUrl({ url }); return; } catch (e) { } }
  if (url.startsWith('mailto:')) { location.href = url; return; }
  window.open(url, '_blank', 'noopener');
}
export async function openApp(pkg, fallbackUrl) {
  if (isNative) {
    try { const r = await Native.openApp({ package: pkg }); if (r.opened) return true; } catch (e) { }
  }
  if (fallbackUrl) { await openUrl(fallbackUrl); return true; }
  return false;
}
export async function shareText(title, text) {
  if (isNative) { try { await Native.shareText({ title, text }); return true; } catch (e) { } }
  if (navigator.share) { try { await navigator.share({ title, text }); return true; } catch (e) { } }
  try { await navigator.clipboard.writeText(text); } catch (e) { }
  return false;
}

// ----- Biometrija (otisak prsta / lice) -----
export async function biometricAvailable() {
  if (!isNative) return false;
  try { return (await Native.biometricAvailable()).available === true; } catch (e) { return false; }
}
export async function biometricAuth(title, subtitle, cancel) {
  if (!isNative) return false;
  try { return (await Native.biometricAuth({ title, subtitle, cancel })).success === true; } catch (e) { return false; }
}
export async function getInfo() {
  if (!isNative) return { filesDir: '(preglednik) IndexedDB', pinSupported: false };
  try { return await Native.getInfo(); } catch (e) { return { filesDir: '?', pinSupported: false }; }
}
// Akcija s kojom je aplikacija pokrenuta (npr. "quickadd" iz widgeta)
export async function consumeLaunchAction() {
  if (!isNative) return null;
  try { return (await Native.consumeLaunchAction()).action || null; } catch (e) { return null; }
}
export function onLaunchAction(cb) {
  if (isNative) Native.addListener('launchAction', (d) => cb(d.action));
}
