// Zaključavanje aplikacije: PIN (obavezno) + otisak prsta / lice (ako uređaj podržava)
import { APP_NAME } from './config.js';
import { state } from './state.js';
import { t } from './i18n.js';
import { esc, uid } from './util.js';
import { icon } from './icons.js';
import { saveSettings } from './storage.js';
import { biometricAvailable, biometricAuth } from './native.js';
import { sheet, toast } from './ui.js';

const L = () => { if (!state.settings.lock) state.settings.lock = { enabled: false }; return state.settings.lock; };
export const lockEnabled = () => !!(L().enabled && L().pinHash);

async function sha(s) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
}
const hashPin = (pin, salt) => sha(salt + ':' + pin);

// Postavljanje novog PIN-a (unos + potvrda)
export async function setupPin() {
  const r = await sheet({
    title: t('setPin'),
    body: '<label class="fld-label">' + esc(t('newPin')) + '</label><input class="fld pin-in" id="p1" type="password" inputmode="numeric" maxlength="8" autocomplete="off">' +
      '<label class="fld-label">' + esc(t('repeatPin')) + '</label><input class="fld pin-in" id="p2" type="password" inputmode="numeric" maxlength="8" autocomplete="off">' +
      '<div class="fld-err" id="perr"></div><p class="muted small">' + esc(t('pinHint')) + '</p>',
    actions: [{ label: t('cancel'), value: null }, { label: t('save'), value: 'ok', cls: 'primary' }],
    onMount: (el) => setTimeout(() => el.querySelector('#p1').focus(), 250),
    onAction: (v, el) => {
      if (v !== 'ok') return null;
      const a = el.querySelector('#p1').value, b = el.querySelector('#p2').value;
      if (!/^\d{4,8}$/.test(a)) { el.querySelector('#perr').textContent = t('pinFormat'); return false; }
      if (a !== b) { el.querySelector('#perr').textContent = t('pinMismatch'); return false; }
      return a;
    },
  });
  if (!r) return false;
  const salt = uid('s');
  Object.assign(L(), { enabled: true, salt, pinHash: await hashPin(r, salt), pinLen: r.length });
  await saveSettings();
  return true;
}

let overlay = null, pausedAt = 0, unlocking = null;
export const isLocked = () => !!overlay;

// Prikaz zaključanog zaslona; Promise se razrješava nakon otključavanja
export function showLock() {
  if (!lockEnabled()) return Promise.resolve();
  if (unlocking) return unlocking;
  unlocking = new Promise((resolve) => {
    let pin = '', fails = 0, blockedUntil = 0;
    overlay = document.createElement('div');
    overlay.className = 'lock-screen';
    const keys = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'bio', '0', 'del'];
    overlay.innerHTML = '<div class="lock-box"><div class="logo-big">' + icon('lock') + '</div><h2>' + APP_NAME + '</h2><p class="lock-msg">' + esc(t('enterPin')) + '</p>' +
      '<div class="pin-dots"></div><div class="keypad">' + keys.map((k) => k === 'bio' ? '<button data-k="bio" class="kp-bio" hidden>' + icon('finger') + '</button>' :
        k === 'del' ? '<button data-k="del">' + icon('backspace') + '</button>' : '<button data-k="' + k + '">' + k + '</button>').join('') + '</div></div>';
    document.body.appendChild(overlay);
    const len = L().pinLen || 4;
    const dots = overlay.querySelector('.pin-dots'), msg = overlay.querySelector('.lock-msg');
    const draw = () => { dots.innerHTML = Array.from({ length: Math.max(len, pin.length) }, (_, i) => '<i class="' + (i < pin.length ? 'on' : '') + '"></i>').join(''); };
    draw();
    const done = () => { overlay.classList.add('out'); const o = overlay; setTimeout(() => o.remove(), 200); overlay = null; unlocking = null; resolve(); };
    const check = async () => {
      if (await hashPin(pin, L().salt) === L().pinHash) return done();
      fails++; pin = ''; draw();
      overlay.querySelector('.lock-box').classList.add('shake'); setTimeout(() => overlay && overlay.querySelector('.lock-box').classList.remove('shake'), 400);
      if (fails >= 5) { blockedUntil = Date.now() + 30000; msg.textContent = t('pinBlocked'); }
      else msg.textContent = t('pinWrong');
    };
    const bio = async () => { if (await biometricAuth(t('unlockTitle'), t('unlockSub'), t('usePin'))) done(); };
    overlay.addEventListener('click', (e) => {
      const b = e.target.closest('[data-k]'); if (!b) return;
      if (Date.now() < blockedUntil) return;
      const k = b.dataset.k;
      if (k === 'bio') return bio();
      if (k === 'del') { pin = pin.slice(0, -1); draw(); return; }
      if (pin.length >= 8) return;
      pin += k; draw();
      if (pin.length === len) check();
    });
    if (L().biometric) biometricAvailable().then((ok) => {
      if (!ok || !overlay) return;
      overlay.querySelector('.kp-bio').hidden = false;
      setTimeout(bio, 350);
    });
  });
  return unlocking;
}

// Zaključavanje nakon povratka u aplikaciju (odmah / nakon 1 ili 5 min)
export function onPause() { pausedAt = Date.now(); }
export function shouldLockOnResume() {
  if (!lockEnabled() || overlay) return false;
  return Date.now() - pausedAt >= (L().after || 0) * 1000;
}
export async function disableLock() { Object.assign(L(), { enabled: false, pinHash: '', salt: '', biometric: false }); await saveSettings(); toast(t('lockOff')); }
