// Izračuni kredita (anuitetna otplata)
export function annuity(P, r, n) {
  if (n <= 0) return 0;
  if (r === 0) return P / n;
  return P * r / (1 - Math.pow(1 + r, -n));
}
export function presentValue(A, r, n) {
  if (n <= 0) return 0;
  if (r === 0) return A * n;
  return A * (1 - Math.pow(1 + r, -n)) / r;
}
// broj mjeseci potreban da se otplati P uz ratu A (Infinity ako rata ne pokriva kamatu)
export function nper(P, r, A) {
  if (A <= 0) return Infinity;
  if (r === 0) return Math.ceil(P / A - 1e-9);
  if (A <= P * r) return Infinity;
  return Math.ceil(-Math.log(1 - P * r / A) / Math.log(1 + r) - 1e-9);
}

// Otplatni plan: niz {k, pay, interest, principal, balance}
export function schedule(P, r, A, nMax) {
  const rows = [];
  let bal = P;
  for (let k = 1; k <= nMax && bal > 0.005; k++) {
    const interest = bal * r;
    let pay = A, principal = pay - interest;
    if (principal >= bal || k === nMax) { principal = bal; pay = bal + interest; }
    bal -= principal;
    rows.push({ k, pay, interest, principal, balance: Math.max(0, bal) });
  }
  return rows;
}

// Glavni izračun: mode = 'payment' (po rati) | 'amount' (po iznosu) | 'term' (po trajanju)
export function computeLoan(L) {
  const r = (+L.rate || 0) / 100 / 12;
  let P = +L.amount || 0, n = Math.max(0, Math.round((+L.years || 0) * 12 + (+L.months || 0))), A = +L.payment || 0;
  let error = '';
  if (L.mode === 'amount') A = annuity(P, r, n);
  else if (L.mode === 'payment') P = presentValue(A, r, n);
  else if (L.mode === 'term') {
    n = nper(P, r, A);
    if (!isFinite(n)) { error = 'paymentTooLow'; n = 0; }
  }
  const rows = error || !P || !n ? [] : schedule(P, r, A, n);
  const total = rows.reduce((s, x) => s + x.pay, 0);
  const interest = total - (rows.length ? P : 0);
  const first = rows[0] || { interest: 0, principal: 0 };
  const lastPay = rows.length ? rows[rows.length - 1].pay : 0;

  // napredno: inflacija i naknada
  const inf = (+L.inflation || 0) / 100;
  const im = Math.pow(1 + inf, 1 / 12) - 1;
  const realCost = rows.reduce((s, x) => s + x.pay / Math.pow(1 + im, x.k), 0);
  const feeAmt = P * (+L.fee || 0) / 100;
  const eks = effectiveRate(P - feeAmt, rows);
  // godišnji pregled
  const years = [];
  rows.forEach((x) => {
    const y = Math.ceil(x.k / 12);
    if (!years[y - 1]) years[y - 1] = { y, pay: 0, interest: 0, principal: 0, balance: 0 };
    const Y = years[y - 1]; Y.pay += x.pay; Y.interest += x.interest; Y.principal += x.principal; Y.balance = x.balance;
  });
  return {
    amount: P, months: rows.length || n, payment: A, total, interest, firstInterest: first.interest, firstPrincipal: first.principal,
    lastPay, realCost, realInterest: realCost - P, feeAmt, totalWithFee: total + feeAmt, eks, years, error,
  };
}

// Efektivna godišnja stopa (EKS, približno): stopa uz koju je sadašnja vrijednost rata = isplaćeni iznos
function effectiveRate(net, rows) {
  if (!rows.length || net <= 0) return NaN;
  const f = (y) => { const m = Math.pow(1 + y, 1 / 12) - 1; return rows.reduce((s, x) => s + x.pay / Math.pow(1 + m, x.k), 0) - net; };
  let lo = -0.99, hi = 5;
  if (f(lo) < 0 || f(hi) > 0) return NaN;
  for (let i = 0; i < 100; i++) { const mid = (lo + hi) / 2; if (f(mid) > 0) lo = mid; else hi = mid; }
  return (lo + hi) / 2 * 100;
}
