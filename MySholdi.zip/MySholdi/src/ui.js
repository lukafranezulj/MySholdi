// Zajednički elementi sučelja: donji listovi (dijalozi), potvrde, obavijesti
import { esc } from './util.js';
import { icon } from './icons.js';
import { t } from './i18n.js';

const stack = [];

// Dijalog u obliku donjeg lista. Vraća Promise s odabranom vrijednošću (ili null).
export function sheet({ title, body = '', actions = [], onMount, onAction, wide = false, cls = '' }) {
  return new Promise((resolve) => {
    const wrap = document.createElement('div');
    wrap.className = 'sheet-wrap';
    wrap.innerHTML =
      '<div class="sheet-bg"></div><div class="sheet ' + (wide ? 'wide ' : '') + cls + '" role="dialog" aria-modal="true">' +
      '<div class="sheet-grab"></div>' +
      (title ? '<div class="sheet-head"><h3>' + esc(title) + '</h3><button class="icon-btn" data-close aria-label="' + esc(t('close')) + '">' + icon('x') + '</button></div>' : '') +
      '<div class="sheet-body">' + body + '</div>' +
      (actions.length ? '<div class="sheet-actions">' + actions.map((a, i) =>
        '<button class="btn ' + (a.cls || '') + '" data-act="' + i + '">' + esc(a.label) + '</button>').join('') + '</div>' : '') +
      '</div>';
    document.body.appendChild(wrap);
    requestAnimationFrame(() => wrap.classList.add('open'));
    const entry = { close: (v) => done(v) };
    stack.push(entry);
    function done(v) {
      const i = stack.indexOf(entry); if (i >= 0) stack.splice(i, 1);
      wrap.classList.remove('open');
      setTimeout(() => wrap.remove(), 200);
      resolve(v === undefined ? null : v);
    }
    const el = wrap.querySelector('.sheet');
    wrap.querySelector('.sheet-bg').onclick = () => done(null);
    wrap.addEventListener('click', async (e) => {
      if (e.target.closest('[data-close]')) return done(null);
      const b = e.target.closest('[data-act]');
      if (!b || !el.contains(b)) return;
      const a = actions[+b.dataset.act];
      const v = a.value !== undefined ? a.value : a.label;
      if (onAction) {
        const r = await onAction(v, el);
        if (r === false) return;
        return done(r === undefined || r === true ? v : r);
      }
      done(v);
    });
    el.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && e.target.tagName === 'INPUT' && e.target.type !== 'range') {
        const primary = el.querySelector('.sheet-actions .primary');
        if (primary) { e.preventDefault(); primary.click(); }
      }
    });
    if (onMount) onMount(el, done);
  });
}
export function closeTopSheet() { const s = stack[stack.length - 1]; if (s) { s.close(null); return true; } return false; }
export function sheetOpen() { return stack.length > 0; }

export async function confirmDlg(text, { ok, danger = false, title } = {}) {
  const r = await sheet({
    title: title || t('confirm'), body: '<p class="dlg-text">' + esc(text) + '</p>',
    actions: [{ label: t('cancel'), value: false }, { label: ok || t('ok'), value: true, cls: danger ? 'danger' : 'primary' }],
  });
  return r === true;
}

export async function promptDlg(title, value = '', { label = '', validate, placeholder = '' } = {}) {
  return sheet({
    title,
    body: (label ? '<label class="fld-label">' + esc(label) + '</label>' : '') +
      '<input class="fld" id="pr-in" value="' + esc(value) + '" placeholder="' + esc(placeholder) + '"><div class="fld-err" id="pr-err"></div>',
    actions: [{ label: t('cancel'), value: null }, { label: t('save'), value: 'ok', cls: 'primary' }],
    onMount: (el) => { const i = el.querySelector('#pr-in'); setTimeout(() => { i.focus(); i.select(); }, 250); },
    onAction: (v, el) => {
      if (v !== 'ok') return null;
      const s = el.querySelector('#pr-in').value.trim();
      const err = validate ? validate(s) : (!s ? t('errEmpty') : '');
      if (err) { el.querySelector('#pr-err').textContent = err; return false; }
      return s;
    },
  });
}

let toastTimer;
export function toast(text, { action, onAction, ms = 3500, kind = '' } = {}) {
  let el = document.getElementById('toast');
  if (!el) { el = document.createElement('div'); el.id = 'toast'; document.body.appendChild(el); }
  el.className = 'show ' + kind;
  el.innerHTML = '<span>' + esc(text) + '</span>' + (action ? '<button>' + esc(action) + '</button>' : '');
  if (action) el.querySelector('button').onclick = () => { el.className = ''; onAction && onAction(); };
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.className = ''; }, action ? Math.max(ms, 5000) : ms);
}

// Mali skočni prozor s objašnjenjem (ikona "i")
export function infoSheet(title, html) {
  return sheet({ title, body: '<div class="info-body">' + html + '</div>', cls: 'info-sheet', actions: [{ label: t('close'), value: null, cls: 'primary' }] });
}
export const infoBtn = (action, extra = '') => '<button class="icon-btn info-btn" data-a="' + action + '" ' + extra + ' aria-label="info">' + icon('info') + '</button>';
