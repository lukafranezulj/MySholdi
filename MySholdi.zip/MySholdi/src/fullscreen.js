// Prikaz grafa preko cijelog zaslona: graf, legenda i tablica s podacima.
// Izlaz: tipka Natrag (Android), Esc (računalo) ili X u gornjem desnom kutu.
import { t } from './i18n.js';
import { esc } from './util.js';
import { sheet } from './ui.js';
import { mountBarChart, mountPie } from './charts.js';

// Tablica: cols = [{name, color}], rows = [{label, values[]}], total = values[] (ili null)
export function fsTable(cols, rows, total, fmt) {
  return '<div class="fs-table-wrap"><table class="fs-table"><thead><tr><th></th>' +
    cols.map((c) => '<th>' + (c.color ? '<i style="background:' + c.color + '"></i>' : '') + esc(c.name) + '</th>').join('') + '</tr></thead><tbody>' +
    rows.map((r) => '<tr><td>' + esc(r.label) + '</td>' + r.values.map((v) => '<td>' + (v === null || v === undefined ? '—' : fmt(v)) + '</td>').join('') + '</tr>').join('') +
    (total ? '<tr class="tot"><td>' + esc(t('total')) + '</td>' + total.map((v) => '<td>' + (v === null ? '—' : fmt(v)) + '</td>').join('') + '</tr>' : '') +
    '</tbody></table></div>';
}

// o = { title, bars (podaci za mountBarChart) ili pie (dijelovi), pieMode, fmt, legendHtml, tableHtml }
export async function showFullscreen(o) {
  let onResize = null;
  await sheet({
    title: o.title, cls: 'fs-sheet',
    body: '<div class="fs-chart">' + (o.pie ? '<div class="donut-row pie-row"><canvas></canvas><div class="legend-list"></div></div>' : '<canvas></canvas>') + '</div>' +
      (o.legendHtml ? '<div class="gc-legend fs-legend">' + o.legendHtml + '</div>' : '') + (o.tableHtml || ''),
    onMount: (el) => {
      const x = el.querySelector('.sheet-head [data-close]'); if (x) x.title = t('exitFullscreen');
      const draw = () => {
        if (o.pie) {
          const sz = Math.max(160, Math.min(el.clientWidth - 40, window.innerHeight * 0.55, 420));
          mountPie(el.querySelector('.fs-chart canvas'), el.querySelector('.fs-chart .legend-list'), o.pie, o.fmt, sz, o.pieMode || 'both', true);
        } else {
          const h = Math.max(220, Math.min(window.innerHeight * 0.58, 620));
          mountBarChart(el.querySelector('.fs-chart canvas'), o.bars, { height: h });
        }
      };
      setTimeout(draw, 30);
      let rt; onResize = () => { clearTimeout(rt); rt = setTimeout(draw, 120); };
      window.addEventListener('resize', onResize);
    },
  });
  if (onResize) window.removeEventListener('resize', onResize);
}
