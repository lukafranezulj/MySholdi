// Crtanje grafikona na <canvas> – koristi se u aplikaciji i za slike widgeta
import { moneyShort, fmtNum } from './util.js';

export const DEFAULT_PALETTE = ['#2563eb', '#16a34a', '#dc2626', '#d97706', '#7c3aed', '#0891b2', '#db2777', '#65a30d', '#ea580c', '#4f46e5', '#0d9488', '#9ca3af'];
// Paleta je "živa": korisnik je može promijeniti u postavkama (Boje grafova)
export const PALETTE = [...DEFAULT_PALETTE];
export function applyPalette(custom) { PALETTE.splice(0, PALETTE.length, ...(Array.isArray(custom) && custom.length === 12 ? custom : DEFAULT_PALETTE)); }

export function cssVar(name, fallback) {
  const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return v || fallback;
}
function themeColors(o) {
  return {
    text: o.text || cssVar('--mut', '#6b7280'),
    grid: o.grid || cssVar('--line', '#e5e7eb'),
    zero: o.zero || cssVar('--mut', '#9ca3af'),
    font: o.font || 'system-ui, -apple-system, Roboto, sans-serif',
  };
}

// Priprema platna za oštar prikaz (devicePixelRatio)
export function setupCanvas(canvas, cssW, cssH, scale) {
  const r = scale || window.devicePixelRatio || 1;
  canvas.width = Math.round(cssW * r); canvas.height = Math.round(cssH * r);
  canvas.style.width = cssW + 'px'; canvas.style.height = cssH + 'px';
  const ctx = canvas.getContext('2d');
  ctx.setTransform(r, 0, 0, r, 0, 0);
  return ctx;
}

function niceStep(span, target = 4) {
  const raw = span / target;
  const p = Math.pow(10, Math.floor(Math.log10(raw || 1)));
  const n = raw / p;
  return (n > 5 ? 10 : n > 2 ? 5 : n > 1 ? 2 : 1) * p;
}

// Stupčasti graf (više serija) s opcionalnom linijom
// data: {labels, series:[{values, color, name}], line:{values,color}}
export function drawBars(ctx, x, y, w, h, data, o = {}) {
  const c = themeColors(o);
  const fs = o.fontSize || 11;
  const lines = data.lines || (data.line ? [data.line] : []);
  const all = data.series.flatMap((s) => s.values).concat(lines.flatMap((l) => l.values.filter((v) => v !== null)));
  let max = Math.max(0, ...all), min = Math.min(0, ...all);
  if (max === min) max = min + 1;
  const step = niceStep(max - min);
  max = Math.ceil(max / step) * step; min = Math.floor(min / step) * step;
  const L = o.noAxis ? 0 : fs * 3.6, B = fs * 1.9, T = 4;
  const ph = h - B - T, pw = w - L;
  const Y = (v) => y + T + (max - v) / (max - min) * ph;
  ctx.font = fs + 'px ' + c.font;
  ctx.textBaseline = 'middle';
  if (!o.noAxis) {
    for (let v = min; v <= max + 1e-9; v += step) {
      ctx.strokeStyle = Math.abs(v) < 1e-9 ? c.zero : c.grid; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(x + L, Math.round(Y(v)) + 0.5); ctx.lineTo(x + w, Math.round(Y(v)) + 0.5); ctx.stroke();
      ctx.fillStyle = c.text; ctx.textAlign = 'right'; ctx.fillText(moneyShort(v), x + L - 5, Y(v));
    }
  } else {
    ctx.strokeStyle = c.zero; ctx.beginPath(); ctx.moveTo(x, Math.round(Y(0)) + 0.5); ctx.lineTo(x + w, Math.round(Y(0)) + 0.5); ctx.stroke();
  }
  const n = data.labels.length, cw = pw / n, ns = Math.max(1, data.series.length);
  const gap = Math.max(1, cw * 0.12), bw = Math.max(2, (cw - gap * 2) / ns - (ns > 1 ? 1 : 0));
  data.series.forEach((s, si) => {
    ctx.fillStyle = s.color;
    s.values.forEach((v, i) => {
      if (!v) return;
      const bx = x + L + i * cw + gap + si * (bw + 1);
      const y0 = Y(0), y1 = Y(v);
      roundRect(ctx, bx, Math.min(y0, y1), bw, Math.max(1, Math.abs(y1 - y0)), Math.min(3, bw / 2), v >= 0);
      ctx.fill();
    });
  });
  lines.forEach((line) => {
    const pts = line.values.map((v, i) => (v === null || v === undefined ? null : [x + L + i * cw + cw / 2, Y(v)]));
    ctx.strokeStyle = line.color; ctx.lineWidth = line.width || 2; ctx.beginPath();
    let started = false;
    pts.forEach((p) => { if (!p) return; if (!started) { ctx.moveTo(p[0], p[1]); started = true; } else ctx.lineTo(p[0], p[1]); });
    ctx.stroke();
    ctx.fillStyle = line.color;
    pts.forEach((p) => { if (p) { ctx.beginPath(); ctx.arc(p[0], p[1], line.dot || 3, 0, Math.PI * 2); ctx.fill(); } });
  });
  ctx.fillStyle = c.text; ctx.textAlign = 'center';
  data.labels.forEach((l, i) => {
    if (n > 12 && i % 2) return;
    if (o.maxLabelW) { const lw = ctx.measureText(l).width; if (lw > cw * 0.98 && i % 2) return; }
    ctx.fillText(l, x + L + i * cw + cw / 2, y + h - B / 2 + 1);
  });
  // vrati geometriju za interakciju (dodir na stupac)
  return { x: x + L, cw, n };
}

function roundRect(ctx, x, y, w, h, r, top = true) {
  ctx.beginPath();
  if (top) {
    ctx.moveTo(x, y + h); ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r); ctx.lineTo(x + w, y + h);
  } else {
    ctx.moveTo(x, y); ctx.lineTo(x + w, y); ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  }
  ctx.closePath();
}
export function fillRound(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y); ctx.closePath();
}

// Prstenasti graf (udjeli kategorija)
export function drawDonut(ctx, cx, cy, r, values, colors, o = {}) {
  const tot = values.reduce((a, b) => a + b, 0);
  const th = o.thickness || r * 0.38;
  if (!tot) {
    ctx.strokeStyle = o.empty || '#e5e7eb'; ctx.lineWidth = th;
    ctx.beginPath(); ctx.arc(cx, cy, r - th / 2, 0, Math.PI * 2); ctx.stroke(); return;
  }
  let a = -Math.PI / 2;
  values.forEach((v, i) => {
    if (!v) return;
    const da = v / tot * Math.PI * 2;
    ctx.strokeStyle = colors[i % colors.length]; ctx.lineWidth = th;
    ctx.beginPath(); ctx.arc(cx, cy, r - th / 2, a, a + da - (values.length > 1 ? 0.02 : 0)); ctx.stroke();
    a += da;
  });
}

// Graf za ekran: stvara <canvas> i crta u njega (poziva se nakon umetanja u DOM)
export function mountBarChart(canvas, data, o = {}) {
  const w = canvas.parentElement.clientWidth || 320;
  const h = o.height || 220;
  const ctx = setupCanvas(canvas, w, h);
  ctx.clearRect(0, 0, w, h);
  return drawBars(ctx, 0, 0, w, h, data, o);
}
export function mountDonut(canvas, values, colors, size = 160) {
  const ctx = setupCanvas(canvas, size, size);
  drawDonut(ctx, size / 2, size / 2, size / 2 - 2, values, colors, { empty: cssVar('--line', '#e5e7eb') });
}
export { fmtNum };

// Vodoravni stupci s nazivima (npr. rashodi po podnaslovima)
export function drawHBars(ctx, x, y, w, h, items, o = {}) {
  const fs = o.fontSize || 11, F = o.font || 'system-ui, Roboto, sans-serif';
  const n = items.length; if (!n) return;
  const rowH = h / n, max = Math.max(...items.map((i) => i.v)) || 1;
  const labW = w * 0.38, valW = o.valW || 56, barW = w - labW - valW - 8;
  items.forEach((it, i) => {
    const cy = y + i * rowH + rowH / 2;
    ctx.font = '500 ' + fs + 'px ' + F; ctx.fillStyle = o.text || '#111'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    let s = it.n; while (s.length > 2 && ctx.measureText(s).width > labW - 6) s = s.slice(0, -2) + '…';
    ctx.fillText(s, x, cy);
    ctx.fillStyle = o.track || 'rgba(0,0,0,.06)'; fillRound(ctx, x + labW, cy - 4, barW, 8, 4); ctx.fill();
    ctx.fillStyle = it.color || o.bar || '#2563eb'; fillRound(ctx, x + labW, cy - 4, Math.max(6, barW * it.v / max), 8, 4); ctx.fill();
    ctx.fillStyle = o.mut || '#666'; ctx.textAlign = 'right'; ctx.font = '600 ' + fs + 'px ' + F;
    ctx.fillText(o.fmt ? o.fmt(it.v) : String(Math.round(it.v)), x + w, cy);
  });
}

// Pita (pie) s legendom: parts = [{n, v, color}]
export function mountPie(canvas, legendEl, parts, fmt, size = 170) {
  const ctx = setupCanvas(canvas, size, size);
  ctx.clearRect(0, 0, size, size);
  const vals = parts.map((p) => Math.max(0, p.v));
  drawDonut(ctx, size / 2, size / 2, size / 2 - 2, vals, parts.map((p) => p.color), { thickness: size / 2 - 2, empty: cssVar('--line', '#e5e7eb') });
  if (legendEl) {
    const tot = vals.reduce((a, b) => a + b, 0) || 1;
    legendEl.innerHTML = parts.map((p, i) => '<div class="lg"><i style="background:' + p.color + '"></i><span>' + escH(p.n) + '</span><b>' + fmt(p.v) + '</b><small>' + fmtNum(vals[i] / tot * 100, 1) + ' %</small></div>').join('');
  }
}
const escH = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
