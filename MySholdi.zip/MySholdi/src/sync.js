// Spremanje: odmah lokalno, a u oblak (povezanu datoteku) ručno ili automatski 5 s nakon zadnje izmjene.
// Zajedničke tablice šalju se odmah nakon svake izmjene.
// Bez interneta ništa se ne šalje: tablica je "spremljena lokalno" i šalje se čim se veza vrati.
// Pri slanju i dohvaćanju verzije se SPAJAJU (unija), pa se tuđi i vlastiti unosi nikad ne prepisuju.
import { LocalNotifications } from '@capacitor/local-notifications';
import { Network } from '@capacitor/network';
import { App } from '@capacitor/app';
import { state } from './state.js';
import { writeBudget, readBudget, saveMeta } from './storage.js';
import { writeDocument, readDocument, isNative } from './native.js';
import { debounce, uid, clone } from './util.js';
import { touch, normalizeBudget, mergeBudgets, sameContent } from './model.js';
import { t } from './i18n.js';

const listeners = new Set();
export const onSyncChange = (fn) => listeners.add(fn);
const emit = () => listeners.forEach((fn) => { try { fn(); } catch (e) { console.error(e); } });

export const AUTOSAVE_MS = 5000;
export const SHARED_PUSH_MS = 600;   // zajedničke tablice: gotovo odmah
let cloudTimer = null;
const pushing = new Set();

// ---------- Internetska veza ----------
state.online = typeof navigator !== 'undefined' ? navigator.onLine !== false : true;
export async function refreshOnline() {
  try { state.online = (await Network.getStatus()).connected; } catch (e) { state.online = navigator.onLine !== false; }
  if (window.__forceOffline) state.online = false;
  return state.online;
}

export function metaOf(id) {
  if (!state.meta[id]) state.meta[id] = { link: null, pending: false, dirty: false, lastCloudAt: 0, lastError: '' };
  return state.meta[id];
}
// Datoteka na samom uređaju (mapa na mobitelu ili datoteka na računalu): za zapis ne treba internet.
// (Datoteku u mapi Google Drivea na računalu dalje šalje aplikacija Google Drive za računalo.)
export const isLocalFile = (m) => !!(m && m.link && (/^fsa:/.test(m.link.uri) || /com\.android\.externalstorage/.test(m.link.uri)));

// synced (zeleno) · unsaved (narančasto) · offline (narančasto, spremljeno lokalno) · failed (crveno) · saving · local
export function syncStatus(id) {
  const m = metaOf(id);
  if (pushing.has(id)) return 'saving';
  if (!m.link) return 'local';
  if (m.pending && m.offline) return 'offline';
  if (m.pending) return 'failed';
  if (m.dirty) return state.online || isLocalFile(m) ? 'unsaved' : 'offline';
  return 'synced';
}

// Lokalni zapis s malom odgodom (da ne pišemo na disk pri svakom znaku)
const writeLocal = debounce(async (b) => {
  try { await writeBudget(b); } catch (e) { console.error('local save', e); }
}, 350);

function scheduleCloud(b, ms) {
  clearTimeout(cloudTimer);
  cloudTimer = setTimeout(() => { cloudTimer = null; pushCloud(b.id); }, ms);
}

// Pozvati nakon svake izmjene otvorene tablice
export function persist(b = state.budget) {
  if (!b) return;
  touch(b);
  writeLocal(b);
  const m = metaOf(b.id);
  m.dirty = true;
  saveMeta();
  clearTimeout(cloudTimer);
  if (m.link && b.shared) scheduleCloud(b, SHARED_PUSH_MS);
  else if (m.link && state.settings.autosave) scheduleCloud(b, AUTOSAVE_MS);
  emit();
}

// Tipka "Spremi"
export async function saveNow(b = state.budget) {
  if (!b) return { ok: false };
  clearTimeout(cloudTimer);
  writeLocal.flush(b);
  const m = metaOf(b.id);
  if (!m.link) { m.dirty = false; await saveMeta(); emit(); return { ok: true, local: true }; }
  return pushCloud(b.id);
}

const changeListeners = new Set();
// poziva se kad se otvorena tablica promijeni zbog izmjena iz oblaka (drugi korisnik/uređaj)
export const onRemoteChange = (fn) => changeListeners.add(fn);
function setOpenBudget(b) {
  if (state.budget && state.budget.id === b.id) {
    state.budget = b;
    changeListeners.forEach((fn) => { try { fn(b); } catch (e) { console.error(e); } });
  }
}
async function readRemote(uri) {
  const txt = await readDocument(uri);
  if (!txt || !txt.trim()) return null;           // nova, prazna datoteka
  return normalizeBudget(JSON.parse(txt));
}
const isNetErr = (e) => /offline|network|Unable to resolve|timeout|ENOTFOUND|connect/i.test(String(e && (e.message || e)));

// Slanje u oblak: pročitaj verziju u oblaku, spoji s lokalnom, zapiši rezultat
export async function pushCloud(id) {
  const m = metaOf(id);
  if (!m.link || pushing.has(id)) return { ok: false };
  if (!isLocalFile(m) && !(await refreshOnline())) {
    // nema interneta: ne pokušavamo (Drive bi zapis "progutao" u predmemoriju i javio uspjeh)
    m.pending = true; m.offline = true; await saveMeta(); emit();
    return { ok: false, offline: true };
  }
  pushing.add(id); emit();
  try {
    const raw = state.budget && state.budget.id === id ? state.budget : await readBudget(id);
    if (!raw) throw new Error('no local');
    const b = normalizeBudget(clone(raw));          // snimka stanja u trenutku slanja
    let remote = null;
    try { remote = await readRemote(m.link.uri); } catch (e) { if (isNetErr(e)) throw e; }
    let out = remote && remote.id === b.id ? mergeBudgets(b, remote) : b;
    const merged = !sameContent(out, b);
    out = { ...out, rev: uid('r') };
    await writeDocument(m.link.uri, JSON.stringify(out, null, 1));
    let editedMeanwhile = false;
    if (state.budget && state.budget.id === id) {
      // korisnik je možda mijenjao tablicu dok je slanje trajalo – te izmjene se zadržavaju
      const cur = normalizeBudget(clone(state.budget));
      editedMeanwhile = !sameContent(cur, b);
      if (merged || editedMeanwhile) {
        const fin = editedMeanwhile ? { ...mergeBudgets(cur, out), rev: out.rev } : out;
        await writeBudget(fin); setOpenBudget(fin);
      } else { state.budget.rev = out.rev; await writeBudget(state.budget); }
    } else await writeBudget(out);
    m.pending = false; m.offline = false; m.dirty = editedMeanwhile; m.lastCloudAt = Date.now(); m.lastError = ''; m.failNotified = false;
    if (editedMeanwhile && state.budget && state.budget.id === id) scheduleCloud(state.budget, state.budget.shared ? SHARED_PUSH_MS : AUTOSAVE_MS);
    return { ok: true, merged };
  } catch (e) {
    m.pending = true; m.offline = !isLocalFile(m) && !(await refreshOnline()); m.lastError = String(e && (e.message || e));
    if (!m.offline) notifyFailure(id);
    return { ok: false, error: m.lastError, offline: m.offline };
  } finally {
    pushing.delete(id);
    await saveMeta();
    emit();
  }
}

// Dohvat izmjena iz oblaka (drugi korisnik ili drugi mobitel). Vraća {changed}
export async function pullRemote(b) {
  const m = metaOf(b.id);
  if (!m.link || pushing.has(b.id)) return { changed: false };
  if (!isLocalFile(m) && !(await refreshOnline())) return { changed: false, offline: true };
  let remote;
  try { remote = await readRemote(m.link.uri); } catch (e) { return { changed: false, error: String(e.message || e) }; }
  if (!remote || remote.id !== b.id) return { changed: false };
  const local = normalizeBudget(clone(state.budget && state.budget.id === b.id ? state.budget : b));
  if (remote.rev && remote.rev === local.rev) return { changed: false };
  const merged = mergeBudgets(local, remote);
  const changed = !sameContent(merged, local);
  const needsPush = !sameContent(merged, remote);   // npr. netko je starom kopijom prepisao naše unose
  const fin = { ...merged, rev: needsPush ? local.rev : remote.rev };
  await writeBudget(fin);
  if (changed) setOpenBudget(fin); else if (state.budget && state.budget.id === b.id) state.budget.rev = fin.rev;
  if (needsPush) { m.dirty = true; await saveMeta(); pushCloud(b.id); }
  emit();
  return { changed };
}

async function notifyFailure(id) {
  const m = metaOf(id);
  if (!state.settings.notifyFailures || m.failNotified) return;
  m.failNotified = true;
  if (!isNative) return;
  try {
    let p = await LocalNotifications.checkPermissions();
    if (p.display !== 'granted') p = await LocalNotifications.requestPermissions();
    if (p.display !== 'granted') return;
    const name = (state.index.find((x) => x.id === id) || {}).name || '';
    await LocalNotifications.schedule({ notifications: [{ id: 1001, title: t('syncFailTitle'), body: t('syncFailBody', { name }) }] });
  } catch (e) { /* obavijesti nisu dostupne */ }
}

// Ponovni pokušaj za sve tablice koje čekaju slanje u oblak
export async function retryPending() {
  const online = await refreshOnline();
  for (const id of Object.keys(state.meta)) {
    const m = state.meta[id];
    if (!online && !isLocalFile(m)) continue;
    if (m.link && (m.pending || (m.dirty && state.settings.autosave && !(state.budget && state.budget.id === id && cloudTimer)))) {
      if (!state.index.find((x) => x.id === id)) continue;
      const r = await pushCloud(id);
      if (r.ok && isNative) { try { await LocalNotifications.cancel({ notifications: [{ id: 1001 }] }); } catch (e) { } }
    }
  }
}

export function startSyncWatchers() {
  refreshOnline().then(emit);
  try {
    Network.addListener('networkStatusChange', (s) => { state.online = s.connected; emit(); if (s.connected) retryPending(); });
  } catch (e) { }
  window.addEventListener('online', () => { state.online = true; emit(); retryPending(); });
  window.addEventListener('offline', () => { state.online = false; emit(); });
  try { App.addListener('resume', () => retryPending()); } catch (e) { }
  try {
    App.addListener('pause', () => {
      if (!state.budget) return;
      writeLocal.flush(state.budget);
      // ako je autospremanje čekalo, pošalji odmah prije nego sustav uspava aplikaciju
      if (cloudTimer) { clearTimeout(cloudTimer); cloudTimer = null; pushCloud(state.budget.id); }
    });
  } catch (e) { }
  setInterval(() => { if (Object.values(state.meta).some((m) => m.pending)) retryPending(); }, 30000);
}
export function flushLocal() { if (state.budget) writeLocal.flush(state.budget); }
export function cancelCloudTimer() { clearTimeout(cloudTimer); cloudTimer = null; }
