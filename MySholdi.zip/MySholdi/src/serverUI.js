// Sučelje za vlastiti server (WebDAV): popis servera, obrazac, preglednik mapa,
// spremanje tablice na server i učitavanje sa servera.
import { state } from './state.js';
import { saveSettings } from './storage.js';
import { sheet, toast, confirmDlg, promptDlg } from './ui.js';
import { t } from './i18n.js';
import { esc, uid, fmtDateTime } from './util.js';
import { icon } from './icons.js';
import { isNative } from './native.js';
import { normUrl, srvTest, srvList, srvMkdirs, srvExists, srvRead, srvUri } from './server.js';

const servers = () => { if (!Array.isArray(state.settings.servers)) state.settings.servers = []; return state.settings.servers; };
const DEFAULT_DIR = 'MojiSholdi';

// Poruka za grešku veze (zajednička za obrazac, preglednik i dijagnostiku)
export function srvErrorText(kind, status) {
  if (kind === 'auth') return t('srvErrAuth');
  if (kind === 'notfound') return t('srvErrNotFound');
  if (kind === 'net') return t(isNative ? 'srvErrNet' : 'srvErrNetWeb');
  if (kind === 'noserver') return t('srvErrNoServer');
  return t('srvErrHttp', { s: status || '?' });
}

// ---- obrazac servera ----
export async function editServer(srv) {
  const d = srv ? { ...srv } : { id: uid('srv'), name: '', url: '', user: '', pass: '' };
  const res = await sheet({
    title: srv ? t('srvEdit') : t('srvAdd'), wide: true,
    body: '<p class="muted small">' + esc(t('srvFormHint')) + '</p>' +
      '<label class="fld-label">' + esc(t('srvName')) + '</label><input class="fld" id="sv-name" value="' + esc(d.name) + '" placeholder="' + esc(t('srvNamePh')) + '">' +
      '<label class="fld-label">' + esc(t('srvUrl')) + '</label><input class="fld" id="sv-url" inputmode="url" autocapitalize="off" spellcheck="false" value="' + esc(d.url) + '" placeholder="http://192.168.1.20:8090/">' +
      '<details class="srv-ex"><summary>' + esc(t('srvExamples')) + '</summary><div class="info-body">' + t('srvExamplesHtml') + '</div></details>' +
      '<div class="row2"><div><label class="fld-label">' + esc(t('srvUser')) + '</label><input class="fld" id="sv-user" autocapitalize="off" autocomplete="username" value="' + esc(d.user) + '"></div>' +
      '<div><label class="fld-label">' + esc(t('srvPass')) + '</label><input class="fld" id="sv-pass" type="password" autocomplete="current-password" value="' + esc(d.pass) + '"></div></div>' +
      '<button class="btn block" id="sv-test">' + icon('cloud') + esc(t('srvTest')) + '</button><p class="small" id="sv-res"></p>' +
      '<p class="muted small">' + esc(t('srvPassNote')) + '</p>',
    actions: [{ label: t('cancel'), value: null }, { label: t('save'), value: 'ok', cls: 'primary' }],
    onMount: (el) => {
      const read = () => ({ ...d, name: el.querySelector('#sv-name').value.trim(), url: normUrl(el.querySelector('#sv-url').value), user: el.querySelector('#sv-user').value.trim(), pass: el.querySelector('#sv-pass').value });
      el.querySelector('#sv-test').onclick = async () => {
        const out = el.querySelector('#sv-res'); const x = read();
        if (!el.querySelector('#sv-url').value.trim()) { out.textContent = t('srvNeedUrl'); out.className = 'small bad'; return; }
        out.textContent = t('srvTesting'); out.className = 'small muted';
        const r = await srvTest(x);
        out.textContent = r.ok ? '✓ ' + t('srvTestOk') : '✕ ' + srvErrorText(r.kind, r.status);
        out.className = 'small ' + (r.ok ? 'ok' : 'bad');
      };
    },
    onAction: (v, el) => {
      if (v !== 'ok') return null;
      const url = el.querySelector('#sv-url').value.trim();
      if (!url) { toast(t('srvNeedUrl')); return false; }
      return { ...d, name: el.querySelector('#sv-name').value.trim() || normUrl(url).replace(/^https?:\/\//, '').replace(/\/$/, ''), url: normUrl(url), user: el.querySelector('#sv-user').value.trim(), pass: el.querySelector('#sv-pass').value };
    },
  });
  if (!res) return null;
  const list = servers(); const i = list.findIndex((x) => x.id === res.id);
  if (i >= 0) list[i] = res; else list.push(res);
  await saveSettings();
  return res;
}

// ---- odabir servera ----
export async function pickServer() {
  const list = servers();
  if (!list.length) return editServer(null);
  const v = await sheet({
    title: t('ownServer'), cls: 'menu-sheet', body: '<p class="dlg-text">' + esc(t('srvPickText')) + '</p>',
    actions: list.map((s) => ({ label: s.name + ' · ' + s.url.replace(/^https?:\/\//, '').replace(/\/$/, ''), value: s.id })).concat([{ label: '+ ' + t('srvAdd'), value: 'add', cls: 'primary' }, { label: t('cancel'), value: null }]),
  });
  if (!v) return null;
  if (v === 'add') return editServer(null);
  return list.find((s) => s.id === v) || null;
}

// ---- preglednik mapa na serveru ----
// mode 'open': odabir .json datoteke → { path, name }; mode 'save': odabir mape → { dir }
export function browseServer(server, mode, startDir = '') {
  let dir = startDir;
  return sheet({
    title: server.name, wide: true, cls: 'srv-browser',
    body: '<div class="srv-path" id="sb-path"></div><div class="srv-list" id="sb-list"></div>',
    actions: mode === 'save'
      ? [{ label: t('srvNewFolder'), value: 'mk' }, { label: t('srvSaveHere'), value: 'here', cls: 'primary' }]
      : [{ label: t('cancel'), value: null }],
    onMount: (el, done) => {
      const load = async () => {
        el.querySelector('#sb-path').innerHTML = icon('folder') + '<span>/' + esc(dir) + '</span>';
        const box = el.querySelector('#sb-list');
        box.innerHTML = '<p class="muted small">' + esc(t('srvLoading')) + '</p>';
        let items;
        try { items = await srvList(server, dir); }
        catch (e) {
          if (e.kind === 'notfound' && mode === 'save') { items = []; }
          else { box.innerHTML = '<p class="small bad">' + esc(srvErrorText(e.kind, e.status)) + '</p>'; return; }
        }
        const rows = [];
        if (dir) rows.push('<button class="srv-item up" data-up>' + icon('folder') + '<span>..</span></button>');
        items.forEach((it) => {
          if (it.isDir) rows.push('<button class="srv-item" data-dir="' + esc(it.path) + '">' + icon('folder') + '<span>' + esc(it.name) + '</span></button>');
          else if (/\.json$/i.test(it.name)) rows.push('<button class="srv-item file' + (mode === 'save' ? ' dim' : '') + '" data-file="' + esc(it.path) + '" data-name="' + esc(it.name) + '">' + icon('table') + '<span>' + esc(it.name) + '<small>' + (it.modified ? esc(fmtDateTime(it.modified)) : '') + '</small></span></button>');
        });
        if (rows.length === (dir ? 1 : 0)) rows.push('<p class="muted small">' + esc(t(mode === 'save' ? 'srvEmptySave' : 'srvEmptyOpen')) + '</p>');
        box.innerHTML = rows.join('');
      };
      el.querySelector('#sb-list').onclick = (e) => {
        const b = e.target.closest('button'); if (!b) return;
        if (b.hasAttribute('data-up')) { dir = dir.split('/').slice(0, -1).join('/'); return load(); }
        if (b.dataset.dir !== undefined) { dir = b.dataset.dir; return load(); }
        if (b.dataset.file && mode === 'open') done({ path: b.dataset.file, name: b.dataset.name });
      };
      load();
      el._srvDir = () => dir;
      el._srvSetDir = (d) => { dir = d; load(); };
    },
    onAction: async (v, el) => {
      if (v === 'here') return { dir: el._srvDir() };
      if (v === 'mk') {
        const name = await promptDlg(t('srvNewFolder'), DEFAULT_DIR);
        if (!name) return false;
        const nd = (el._srvDir() ? el._srvDir() + '/' : '') + name.replace(/[\\/]/g, '_').trim();
        try { await srvMkdirs(server, nd); el._srvSetDir(nd); } catch (e) { toast(srvErrorText(e.kind, e.status), { kind: 'bad' }); }
        return false;
      }
      return null;
    },
  });
}

// ---- spremanje tablice na server: vraća { uri, name } ili null ----
export async function serverSaveFlow(fileName) {
  const server = await pickServer(); if (!server) return null;
  // zadano: mapa MojiSholdi (napravi se ako ne postoji)
  let start = DEFAULT_DIR;
  try { await srvMkdirs(server, DEFAULT_DIR); } catch (e) {
    if (e.kind === 'auth' || e.kind === 'net') { toast(srvErrorText(e.kind, e.status), { kind: 'bad' }); return null; }
    start = '';
  }
  const r = await browseServer(server, 'save', start);
  if (!r) return null;
  // ne prepisuj postojeću datoteku: doda se (2), (3)…
  const base = fileName.replace(/\.json$/i, '');
  let name = fileName, n = 2;
  try { while (await srvExists(server, (r.dir ? r.dir + '/' : '') + name)) name = base + ' (' + n++ + ').json'; } catch (e) { }
  return { uri: srvUri(server.id, (r.dir ? r.dir + '/' : '') + name), name };
}

// ---- učitavanje sa servera: vraća { uri, name, data } ili null ----
export async function serverOpenFlow() {
  const server = await pickServer(); if (!server) return null;
  let start = DEFAULT_DIR;
  try { if (!(await srvExists(server, DEFAULT_DIR))) start = ''; } catch (e) { start = ''; }
  const f = await browseServer(server, 'open', start);
  if (!f) return null;
  const uri = srvUri(server.id, f.path);
  try { return { uri, name: f.name, data: await srvRead(uri) }; }
  catch (e) { toast(srvErrorText(e.kind, e.status), { kind: 'bad' }); return null; }
}

// ---- postavke: popis servera ----
export function serversSettingsHtml() {
  const list = servers();
  return (list.length ? list.map((s) => '<div class="set-row"><div class="grow"><b>' + esc(s.name) + '</b><small>' + esc(s.url) + (s.user ? ' · ' + esc(s.user) : '') + '</small></div>' +
    '<button class="icon-btn sm" data-a="srvEdit" data-id="' + s.id + '">' + icon('pencil') + '</button><button class="icon-btn sm" data-a="srvDel" data-id="' + s.id + '">' + icon('trash') + '</button></div>').join('')
    : '<div class="set-row"><small class="muted">' + esc(t('srvNone')) + '</small></div>') +
    '<div class="set-row"><button class="btn small" data-a="srvAddS">' + icon('plus') + esc(t('srvAdd')) + '</button><button class="btn small ghost" data-a="srvInfo">' + esc(t('srvHow')) + '</button></div>';
}
export async function serversSettingsAction(a, d) {
  if (a === 'srvAddS') { await editServer(null); return true; }
  if (a === 'srvEdit') { const s = servers().find((x) => x.id === d.id); if (s) await editServer(s); return true; }
  if (a === 'srvDel') {
    const s = servers().find((x) => x.id === d.id); if (!s) return true;
    const used = Object.values(state.meta).some((m) => m && m.link && String(m.link.uri).startsWith('srv:' + s.id + ':'));
    if (!(await confirmDlg(t(used ? 'srvDelUsedQ' : 'srvDelQ', { n: s.name }), { ok: t('delete'), danger: true }))) return true;
    state.settings.servers = servers().filter((x) => x.id !== s.id); await saveSettings(); return true;
  }
  if (a === 'srvInfo') { await sheet({ title: t('ownServer'), cls: 'info-sheet', body: '<div class="info-body">' + t('srvInfoHtml') + '</div>', actions: [{ label: t('close'), value: null, cls: 'primary' }] }); return true; }
  return false;
}
