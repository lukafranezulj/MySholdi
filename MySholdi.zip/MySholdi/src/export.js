// Ispis / izvoz tablice: PDF (A4) ili Excel (.xlsx), jednostavno (samo tablice) ili s bojama i grafikonima
import { state } from './state.js';
import { t } from './i18n.js';
import { esc, fmtNum, monthName, fmtDateTime, fmtDate, chartColor, avgNZ, stdevNZ, counted } from './util.js';
import { calcSide, calcNet, itemLabel } from './model.js';
import { drawBars, drawHBars, PALETTE } from './charts.js';
import { sheet, toast } from './ui.js';
import { saveBinary, openSavedFile } from './native.js';
import { buildXlsx } from './xlsx.js';
import robotoRegular from './fonts/Roboto-Regular.ttf';
import robotoBold from './fonts/Roboto-Bold.ttf';

const MONTHS = () => Array.from({ length: 12 }, (_, i) => monthName(i, true));
const n2 = (x) => (x === null || x === undefined || isNaN(x) ? '' : fmtNum(x));
const n2z = (x) => (x ? fmtNum(x) : '');
const cur = () => state.settings.currency || 'EUR';

// ---------- Dijalog ----------
export async function exportDialog(b) {
  const r = await sheet({
    title: t('printTitle'),
    body: '<p class="dlg-text">' + esc(t('printText')) + '</p>' +
      '<label class="fld-label">' + esc(t('fileFormat')) + '</label><div class="seg" id="ex-fmt"><button data-v="pdf" class="on">PDF (A4)</button><button data-v="xlsx">Excel (.xlsx)</button></div>' +
      '<label class="fld-label">' + esc(t('printStyle')) + '</label><div class="seg" id="ex-style"><button data-v="plain" class="on">' + esc(t('stylePlain')) + '</button><button data-v="color">' + esc(t('styleColor')) + '</button></div>' +
      '<p class="muted small" id="ex-hint">' + esc(t('stylePlainHint')) + '</p>' +
      '<label class="set-row toggle"><div><b>' + esc(t('includeNet')) + '</b></div><input type="checkbox" id="ex-net"' + (state.settings.showNet ? ' checked' : '') + '><span class="sw"></span></label>' +
      '<label class="set-row toggle"><div><b>' + esc(t('includeEntries')) + '</b><small>' + esc(t('includeEntriesHint', { n: b.entries.length })) + '</small></div><input type="checkbox" id="ex-entries"><span class="sw"></span></label>',
    actions: [{ label: t('cancel'), value: null }, { label: t('saveFile'), value: 'ok', cls: 'primary' }],
    onMount: (el) => {
      const seg = (id, cb) => el.querySelector(id).onclick = (e) => { const bt = e.target.closest('button'); if (!bt) return; el.querySelectorAll(id + ' button').forEach((x) => x.classList.toggle('on', x === bt)); cb && cb(bt.dataset.v); };
      const hint = () => {
        const f = el.querySelector('#ex-fmt .on').dataset.v, s = el.querySelector('#ex-style .on').dataset.v;
        el.querySelector('#ex-hint').textContent = t(s === 'plain' ? 'stylePlainHint' : (f === 'pdf' ? 'styleColorHintPdf' : 'styleColorHintXlsx'));
      };
      seg('#ex-fmt', hint); seg('#ex-style', hint);
    },
    onAction: (v, el) => v === 'ok' ? {
      fmt: el.querySelector('#ex-fmt .on').dataset.v, color: el.querySelector('#ex-style .on').dataset.v === 'color',
      net: el.querySelector('#ex-net').checked, entries: el.querySelector('#ex-entries').checked,
    } : null,
  });
  if (!r) return;
  toast(t('preparingFile'));
  try {
    const base = ('MySholdi - ' + b.name).replace(/[\\/:*?"<>|]/g, '_');
    let data, name, mime;
    if (r.fmt === 'pdf') { data = await buildPdf(b, r); name = base + '.pdf'; mime = 'application/pdf'; }
    else { data = buildXlsx(sheetsFor(b, r), r.color); name = base + '.xlsx'; mime = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'; }
    const saved = await saveBinary(name, mime, data);
    if (saved) toast(t('fileSaved', { n: saved.name || name }), saved.uri ? { action: t('openFile'), onAction: () => openSavedFile(saved.uri, mime) } : {});
  } catch (e) {
    if (!/cancel/i.test(String(e && e.message))) { console.error(e); toast(t('errFile') + ': ' + (e.message || e), { kind: 'bad' }); }
  }
}

// ---------- Zajednički podaci (iste tablice za PDF i Excel) ----------
function sideRows(b, type) {
  const C = calcSide(b, type);
  const rows = [];
  b[type].forEach((g, gi) => {
    const cg = C.groups[gi];
    rows.push({ kind: 'group', cells: [g.name, ...cg.m.map(n0), cg.total, cg.avg] });
    g.items.forEach((it, ii) => {
      const r = cg.rows[ii];
      rows.push({ kind: 'item', cells: ['   ' + (it.name || '—'), ...it.vals.map((v) => (v === null || v === undefined ? null : v)), r.total || null, r.avg || null] });
    });
  });
  rows.push({ kind: 'total', cells: [t('monthlyTotal'), ...C.monthly, C.total, C.avgMonthly] });
  rows.push({ kind: 'total2', cells: [t('avgDaily'), ...C.daily, null, C.avgDaily] });
  return { head: [t(type === 'income' ? 'income' : 'expenses'), ...MONTHS(), t('total'), t('avgShort')], rows, C };
}
const n0 = (x) => (x ? x : null);

function summaryData(b) {
  const P = calcSide(b, 'income'), R = calcSide(b, 'expense');
  const diff = P.monthly.map((x, i) => x - R.monthly[i]);
  const mx = (a, pr) => { const f = counted(a, pr); return f.length ? Math.max(...f) : 0; };
  const mn = (a, pr) => { const f = counted(a, pr); return f.length ? Math.min(...f) : 0; };
  const sp = avgNZ(P.monthly, P.present), sr = avgNZ(R.monthly, R.present), dp = stdevNZ(P.monthly, P.present), dr = stdevNZ(R.monthly, R.present);
  return {
    P, R, diff,
    months: { head: ['', ...MONTHS(), t('total')], rows: [
      { kind: 'item', cells: [t('income'), ...P.monthly, P.total] },
      { kind: 'item', cells: [t('expenses'), ...R.monthly, R.total] },
      { kind: 'total', cells: [t('difference'), ...diff, P.total - R.total] },
    ] },
    stats: { head: [t('monthly'), t('income'), t('expenses'), t('difference')], rows: [
      { kind: 'item', cells: [t('avgMonthly'), sp, sr, sp - sr] },
      { kind: 'item', cells: [t('avgDaily'), P.avgDaily, R.avgDaily, P.avgDaily - R.avgDaily] },
      { kind: 'item', cells: [t('statMean'), sp, sr, null] },
      { kind: 'item', cells: [t('statSd'), dp, dr, null] },
      { kind: 'item', cells: [t('statCv'), sp ? dp / sp : null, sr ? dr / sr : null, null] },
      { kind: 'item', cells: ['MAX', mx(P.monthly, P.present), mx(R.monthly, R.present), null] },
      { kind: 'item', cells: ['MIN', mn(P.monthly, P.present), mn(R.monthly, R.present), null] },
      { kind: 'total', pct: true, cells: [t('savingsRateLbl'), null, null, P.total ? (P.total - R.total) / P.total * 100 : null] },
    ] },
    share: { pctCols: [2], head: [t('expenseShare'), t('total'), '%'], rows: b.expense.map((g, i) => ({ kind: 'item', cells: [g.name, R.groups[i].total, R.total ? R.groups[i].total / R.total * 100 : 0] }))
      .filter((r) => r.cells[1] > 0).sort((a, c) => c.cells[1] - a.cells[1]) },
  };
}

function netData(b) {
  const N = calcNet(b), net = b.net;
  const rows = [{ kind: 'sec', cells: [t('assets'), ...net.periods.map(() => null)] }];
  net.assets.forEach((r) => rows.push({ kind: 'item', cells: ['   ' + r.name, ...r.vals] }));
  rows.push({ kind: 'total2', cells: [t('total'), ...N.assets] });
  rows.push({ kind: 'sec', cells: [t('liabilities'), ...net.periods.map(() => null)] });
  net.liabilities.forEach((r) => rows.push({ kind: 'item', cells: ['   ' + r.name, ...r.vals] }));
  rows.push({ kind: 'total2', cells: [t('total'), ...N.liab] });
  rows.push({ kind: 'total', cells: [t('netWorth'), ...N.net.map((x) => (isNaN(x) ? null : x))] });
  rows.push({ kind: 'item', cells: [t('wealthMonths'), ...N.months.map((x) => (isNaN(x) ? null : x))] });
  rows.push({ kind: 'item', cells: [t('wealthYears'), ...N.years.map((x) => (isNaN(x) ? null : x))] });
  return { head: [t('stateOnLastDay'), ...net.periods], rows };
}

function entriesData(b) {
  return { textCols: [0, 1, 2, 3, 5, 6], head: [t('dateTime'), t('kind'), t('category'), t('month'), t('amount'), t('author'), t('note')],
    rows: b.entries.map((e) => ({ kind: 'item', cells: [fmtDateTime(e.ts), t(e.type === 'income' ? 'incomeOne' : 'expense'), itemLabel(b, e.type, e.gid, e.iid) || e.label || '', monthName(e.month), e.type === 'income' ? e.amount : -e.amount, e.by || '', e.note || ''] })) };
}

// Za Excel: popis listova
function sheetsFor(b, o) {
  const info = [[b.name + ' (' + b.year + ')'], [t('currency') + ': ' + cur() + ' · ' + t('generatedOn') + ' ' + fmtDate(Date.now())]];
  const S = summaryData(b);
  const list = [
    { name: t('income'), title: info, tone: 'income', tables: [sideRows(b, 'income')], widths: [34] },
    { name: t('expenses'), title: info, tone: 'expense', tables: [sideRows(b, 'expense')], widths: [34] },
    { name: t('tabSummary'), title: info, tone: 'summary', tables: [S.months, S.stats, S.share], widths: [30] },
  ];
  if (o.net) list.push({ name: t('tabNet'), title: info, tone: 'net', tables: [netData(b)], widths: [34] });
  if (o.entries) list.push({ name: t('entriesSheet'), title: info, tone: 'plain', tables: [entriesData(b)], widths: [18, 10, 40, 12, 12, 14, 30] });
  return list;
}

// ---------- PDF ----------
const TONES = { income: [22, 163, 74], expense: [220, 38, 38], summary: [202, 138, 4], net: [37, 99, 235], plain: [55, 65, 81] };
const LIGHT = { income: [220, 252, 231], expense: [254, 226, 226], summary: [254, 249, 195], net: [219, 234, 254], plain: [243, 244, 246] };

async function buildPdf(b, o) {
  const { jsPDF } = await import('jspdf');
  const { autoTable } = await import('jspdf-autotable');
  const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4', compress: true });
  doc.addFileToVFS('Roboto-Regular.ttf', robotoRegular); doc.addFont('Roboto-Regular.ttf', 'Roboto', 'normal');
  doc.addFileToVFS('Roboto-Bold.ttf', robotoBold); doc.addFont('Roboto-Bold.ttf', 'Roboto', 'bold');
  doc.setFont('Roboto', 'normal');
  const W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight(), M = 12;
  const title = 'MySholdi – ' + b.name;
  const sub = t('year') + ' ' + b.year + ' · ' + t('currency') + ': ' + cur() + ' · ' + fmtDate(Date.now());
  let y = M;
  doc.setFont('Roboto', 'bold'); doc.setFontSize(16); doc.text(title, M, y + 5);
  doc.setFont('Roboto', 'normal'); doc.setFontSize(9); doc.setTextColor(90); doc.text(sub, M, y + 11); doc.setTextColor(0);
  y += 16;

  const section = (label, tone) => {
    if (y > H - 40) { doc.addPage(); y = M; }
    doc.setFont('Roboto', 'bold'); doc.setFontSize(12);
    if (o.color) doc.setTextColor(...TONES[tone]);
    doc.text(label, M, y + 4); doc.setTextColor(0);
    y += 7;
  };
  const table = (data, tone, opts = {}) => {
    const fmtCell = (v, ci, row) => {
      if (typeof v === 'string') return v;
      if (v === null || v === undefined) return '';
      if (opts.pct && opts.pct.includes(ci)) return fmtNum(v, 1) + ' %';
      if (row.kind === 'item' && v === 0 && !opts.showZero) return '';
      return fmtNum(v);
    };
    const body = data.rows.map((r) => r.cells.map((v, ci) => fmtCell(v, ci, r)));
    // "fit": smanji font i razmak da cijela tablica stane na ostatak stranice (najmanje 5,5 pt)
    let fontSize = opts.fontSize || 7, pad = 1.1;
    if (opts.fit) {
      const avail = H - y - 16, n = data.rows.length + 1;
      pad = 0.55;
      fontSize = Math.max(5.5, Math.min(7.5, (avail / n - 2 * pad) / 0.41));
    }
    autoTable(doc, {
      startY: y, head: [data.head], body, theme: 'grid', margin: { left: M, right: M, top: M + 6, bottom: 12 },
      styles: { font: 'Roboto', fontSize, cellPadding: pad, halign: 'right', lineColor: [200, 200, 200], lineWidth: 0.15, textColor: 20, overflow: 'linebreak' },
      headStyles: o.color ? { fillColor: TONES[tone], textColor: 255, fontStyle: 'bold', halign: 'right' } : { fillColor: [235, 235, 235], textColor: 20, fontStyle: 'bold', halign: 'right' },
      columnStyles: Object.assign({ 0: { halign: 'left', cellWidth: opts.firstW || 46 } }, opts.columnStyles || {}),
      didParseCell: (h) => {
        if (h.section === 'head' && h.column.index === 0) h.cell.styles.halign = 'left';
        if (h.section !== 'body') return;
        const kind = data.rows[h.row.index].kind;
        if (kind === 'group' || kind === 'total' || kind === 'sec') h.cell.styles.fontStyle = 'bold';
        if (kind === 'group') h.cell.styles.fillColor = o.color ? LIGHT[tone] : [245, 245, 245];
        if (kind === 'total') h.cell.styles.fillColor = o.color ? LIGHT[tone] : [235, 235, 235];
        if (kind === 'total2') h.cell.styles.fillColor = o.color ? [250, 250, 250] : [248, 248, 248];
        if (kind === 'sec') h.cell.styles.fillColor = o.color ? LIGHT.net : [240, 240, 240];
        if (o.color && kind !== 'group' && typeof data.rows[h.row.index].cells[h.column.index] === 'number' && data.rows[h.row.index].cells[h.column.index] < 0) h.cell.styles.textColor = [200, 30, 30];
      },
    });
    y = doc.lastAutoTable.finalY + 6;
  };
  const image = (canvas, w, h) => {
    if (y + h > H - 12) { doc.addPage(); y = M; }
    doc.addImage(canvas.toDataURL('image/png'), 'PNG', M, y, w, h);
    y += h + 4;
  };

  section(t('income'), 'income'); table(sideRows(b, 'income'), 'income', { fit: true });
  doc.addPage(); y = M;
  section(t('expenses'), 'expense'); table(sideRows(b, 'expense'), 'expense', { fit: true });
  doc.addPage(); y = M;
  const S = summaryData(b);
  section(t('tabSummary'), 'summary');
  table(S.months, 'summary', { firstW: 30 });
  if (o.color) {
    image(summaryChart(S), W - M * 2, 62);
    // legenda grafikona
    let lx = M + 2;
    [[t('income'), chartColor('income')], [t('expenses'), chartColor('expense')], [t('difference'), chartColor('diff')]].forEach(([l, c]) => {
      doc.setFillColor(c); doc.rect(lx, y - 3, 3, 3, 'F'); doc.setFontSize(8); doc.setTextColor(60); doc.text(l, lx + 4.5, y - 0.6); lx += doc.getTextWidth(l) + 12;
    });
    doc.setTextColor(0); y += 4;
  }
  const half = (W - M * 3) / 2;
  const yStart = y;
  autoTableHalf(doc, autoTable, S.stats, M, yStart, half, o, 'summary');
  const y1 = doc.lastAutoTable.finalY;
  autoTableHalf(doc, autoTable, { head: S.share.head, rows: S.share.rows }, M * 2 + half, yStart, half, o, 'expense', [2]);
  const y2 = doc.lastAutoTable.finalY;
  y = Math.max(y1, y2) + 6;
  doc.setFontSize(7.5); doc.setTextColor(110); doc.text(t(state.settings.avgIncludeZeros ? 'statsHintZeros' : 'statsHint'), M, y); doc.setTextColor(0); y += 6;
  if (o.color && S.share.rows.length) image(shareChart(S), W - M * 2, Math.min(80, 8 + S.share.rows.length * 7));
  if (o.net) { if (y > H - 30 - (b.net.assets.length + b.net.liabilities.length + 8) * 5.2) { doc.addPage(); y = M; } section(t('netWorth'), 'net'); table(netData(b), 'net', { fontSize: 8.5, firstW: 70 }); }
  if (o.entries && b.entries.length) {
    doc.addPage(); y = M;
    section(t('entriesSheet'), 'plain');
    table(entriesData(b), 'plain', { fontSize: 7.5, firstW: 30, showZero: true, columnStyles: { 1: { halign: 'left', cellWidth: 18 }, 2: { halign: 'left' }, 3: { halign: 'left', cellWidth: 22 }, 5: { halign: 'left', cellWidth: 26 }, 6: { halign: 'left' } } });
  }
  // podnožje: naziv i broj stranice
  const pages = doc.getNumberOfPages();
  for (let i = 1; i <= pages; i++) {
    doc.setPage(i); doc.setFont('Roboto', 'normal'); doc.setFontSize(7.5); doc.setTextColor(120);
    doc.text(title + ' (' + b.year + ')', M, H - 6);
    doc.text(i + ' / ' + pages, W - M, H - 6, { align: 'right' });
  }
  return bufToBase64(doc.output('arraybuffer'));
}
function autoTableHalf(doc, autoTable, data, x, y, w, o, tone, pctCols = []) {
  autoTable(doc, {
    startY: y, head: [data.head], margin: { left: x }, tableWidth: w, theme: 'grid',
    body: data.rows.map((r) => r.cells.map((v, ci) => (typeof v === 'string' ? v : v === null || v === undefined ? '' : (pctCols.includes(ci) || (r.kind === 'total' && ci === 3) ? fmtNum(v, 1) + ' %' : fmtNum(v))))),
    styles: { font: 'Roboto', fontSize: 8, cellPadding: 1.3, halign: 'right', lineColor: [200, 200, 200], lineWidth: 0.15, textColor: 20 },
    headStyles: o.color ? { fillColor: TONES[tone], textColor: 255, fontStyle: 'bold' } : { fillColor: [235, 235, 235], textColor: 20, fontStyle: 'bold' },
    columnStyles: { 0: { halign: 'left', cellWidth: w * 0.42 } },
    didParseCell: (h) => { if (h.section === 'head' && h.column.index === 0) h.cell.styles.halign = 'left'; if (h.section === 'body' && data.rows[h.row.index].kind === 'total') { h.cell.styles.fontStyle = 'bold'; } },
  });
}
// Grafikoni za PDF (bijela pozadina, oštra slika)
function summaryChart(S) {
  const w = 1600, h = 380, cv = document.createElement('canvas'); cv.width = w; cv.height = h;
  const ctx = cv.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h); ctx.scale(2, 2);
  drawBars(ctx, 4, 6, w / 2 - 8, h / 2 - 10, {
    labels: MONTHS().map((m) => m.slice(0, 3)),
    series: [{ values: S.P.monthly, color: chartColor('income') }, { values: S.R.monthly, color: chartColor('expense') }],
    line: { values: S.diff.map((x, i) => (S.P.monthly[i] || S.R.monthly[i] ? x : null)), color: chartColor('diff') },
  }, { text: '#555', grid: '#e5e5e5', zero: '#999', fontSize: 10, font: 'Roboto, Arial, sans-serif' });
  return cv;
}
function shareChart(S) {
  const rows = S.share.rows.slice(0, 10);
  const w = 1600, h = Math.round((8 + rows.length * 7) / 62 * 380 * 1.0) * 1 + 40, cv = document.createElement('canvas'); cv.width = w; cv.height = h;
  const ctx = cv.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h); ctx.scale(2, 2);
  drawHBars(ctx, 6, 6, w / 2 - 12, h / 2 - 12, rows.map((r, i) => ({ n: r.cells[0], v: r.cells[1], color: PALETTE[i % PALETTE.length] })), { text: '#222', mut: '#555', track: '#f0f0f0', fontSize: 11, fmt: (v) => fmtNum(v, 0) + ' ' + cur(), valW: 90 });
  return cv;
}
function bufToBase64(buf) {
  const bytes = new Uint8Array(buf); let s = '';
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}
export { bufToBase64 };
