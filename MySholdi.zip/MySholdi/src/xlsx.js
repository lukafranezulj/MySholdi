// Minimalni zapis Excel datoteke (.xlsx = ZIP s XML-om), bez vanjskih ovisnosti osim fflate
import { zipSync, strToU8 } from 'fflate';

const X = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '');
const colName = (i) => { let s = ''; i++; while (i > 0) { const m = (i - 1) % 26; s = String.fromCharCode(65 + m) + s; i = Math.floor((i - 1) / 26); } return s; };
const TONE = { income: '16A34A', expense: 'DC2626', summary: 'CA8A04', net: '2563EB', plain: '374151' };
const LIGHT = { income: 'DCFCE7', expense: 'FEE2E2', summary: 'FEF9C3', net: 'DBEAFE', plain: 'F3F4F6' };

// Registar stilova: svaka kombinacija (podebljano, ispuna, format broja, veličina, boja) dobiva indeks
function styleRegistry() {
  const fonts = ['<font><sz val="10"/><name val="Calibri"/></font>'], fills = ['<fill><patternFill patternType="none"/></fill>', '<fill><patternFill patternType="gray125"/></fill>'];
  const xfs = ['<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'];
  const fMap = new Map(), fiMap = new Map(), xMap = new Map();
  const font = (b, sz, color) => { const k = [b, sz, color].join('|'); if (!fMap.has(k)) { fMap.set(k, fonts.length); fonts.push('<font>' + (b ? '<b/>' : '') + '<sz val="' + sz + '"/>' + (color ? '<color rgb="FF' + color + '"/>' : '') + '<name val="Calibri"/></font>'); } return fMap.get(k); };
  const fill = (hex) => { if (!hex) return 0; if (!fiMap.has(hex)) { fiMap.set(hex, fills.length); fills.push('<fill><patternFill patternType="solid"><fgColor rgb="FF' + hex + '"/><bgColor indexed="64"/></patternFill></fill>'); } return fiMap.get(hex); };
  const get = ({ b = false, sz = 10, color = null, bg = null, num = 0, border = true, wrap = false }) => {
    const k = [b, sz, color, bg, num, border, wrap].join('|');
    if (!xMap.has(k)) {
      xMap.set(k, xfs.length);
      xfs.push('<xf numFmtId="' + num + '" fontId="' + font(b, sz, color) + '" fillId="' + fill(bg) + '" borderId="' + (border ? 1 : 0) + '" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1" applyBorder="1"' + (wrap ? ' applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf>' : '/>'));
    }
    return xMap.get(k);
  };
  const xml = () => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
    '<numFmts count="1"><numFmt numFmtId="164" formatCode="0.0&quot; %&quot;"/></numFmts>' +
    '<fonts count="' + fonts.length + '">' + fonts.join('') + '</fonts><fills count="' + fills.length + '">' + fills.join('') + '</fills>' +
    '<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFD0D0D0"/></left><right style="thin"><color rgb="FFD0D0D0"/></right><top style="thin"><color rgb="FFD0D0D0"/></top><bottom style="thin"><color rgb="FFD0D0D0"/></bottom><diagonal/></border></borders>' +
    '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="' + xfs.length + '">' + xfs.join('') + '</cellXfs>' +
    '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
  return { get, xml };
}

export function buildXlsx(sheets, color) {
  const st = styleRegistry();
  const files = {};
  const usedNames = new Set();
  sheets.forEach((sh, si) => {
    const rows = [];
    let r = 0, maxCols = 1;
    const put = (cells) => { rows.push({ r: ++r, cells }); maxCols = Math.max(maxCols, cells.length); };
    sh.title.forEach((line, i) => put(line.map((v) => ({ v, s: st.get({ b: i === 0, sz: i === 0 ? 14 : 10, border: false, color: i === 0 && color ? TONE[sh.tone] : null }) }))));
    put([]);
    sh.tables.forEach((tb) => {
      const textCols = tb.textCols || [];
      put(tb.head.map((v, ci) => ({ v, s: st.get({ b: true, bg: color ? TONE[sh.tone] : 'E7E7E7', color: color ? 'FFFFFF' : null }) })));
      tb.rows.forEach((row) => {
        const bold = row.kind === 'group' || row.kind === 'total' || row.kind === 'sec';
        const bg = row.kind === 'group' || row.kind === 'total' ? (color ? LIGHT[sh.tone] : (row.kind === 'total' ? 'EBEBEB' : 'F5F5F5'))
          : row.kind === 'sec' ? (color ? LIGHT.net : 'F0F0F0') : row.kind === 'total2' ? (color ? 'FAFAFA' : 'F8F8F8') : null;
        put(row.cells.map((v, ci) => {
          const isNum = typeof v === 'number' && !textCols.includes(ci);
          const pct = (tb.pctCols && tb.pctCols.includes(ci)) || (row.pct && ci === row.cells.length - 1);
          const neg = color && isNum && v < 0;
          return { v, s: st.get({ b: bold, bg, num: isNum ? (pct ? 164 : 4) : 0, color: neg ? 'C81E1E' : null, wrap: ci === 6 && textCols.length > 0 }) };
        }));
      });
      put([]);
    });
    const widths = sh.widths || [];
    const cols = '<cols>' + Array.from({ length: maxCols }, (_, i) => '<col min="' + (i + 1) + '" max="' + (i + 1) + '" width="' + (widths[i] || (i === 0 ? 30 : 11)) + '" customWidth="1"/>').join('') + '</cols>';
    const body = rows.map((row) => '<row r="' + row.r + '">' + row.cells.map((c, ci) => {
      const ref = colName(ci) + row.r;
      if (c.v === null || c.v === undefined || c.v === '') return '<c r="' + ref + '" s="' + c.s + '"/>';
      if (typeof c.v === 'number' && isFinite(c.v)) return '<c r="' + ref + '" s="' + c.s + '"><v>' + Math.round(c.v * 10000) / 10000 + '</v></c>';
      return '<c r="' + ref + '" s="' + c.s + '" t="inlineStr"><is><t xml:space="preserve">' + X(c.v) + '</t></is></c>';
    }).join('') + '</row>').join('');
    files['xl/worksheets/sheet' + (si + 1) + '.xml'] = strToU8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' +
      '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr><sheetViews><sheetView workbookViewId="0"><pane xSplit="1" topLeftCell="B1" activePane="topRight" state="frozen"/></sheetView></sheetViews>' +
      cols + '<sheetData>' + body + '</sheetData><pageMargins left="0.4" right="0.4" top="0.5" bottom="0.5" header="0.3" footer="0.3"/>' +
      '<pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/></worksheet>');
    let nm = String(sh.name).replace(/[\[\]:*?\/\\]/g, ' ').slice(0, 31) || 'List';
    let k = 2; while (usedNames.has(nm)) nm = nm.slice(0, 28) + ' ' + k++;
    usedNames.add(nm); sh._name = nm;
  });
  files['xl/styles.xml'] = strToU8(st.xml());
  files['xl/workbook.xml'] = strToU8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' +
    sheets.map((sh, i) => '<sheet name="' + X(sh._name) + '" sheetId="' + (i + 1) + '" r:id="rId' + (i + 1) + '"/>').join('') + '</sheets></workbook>');
  files['xl/_rels/workbook.xml.rels'] = strToU8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
    sheets.map((_, i) => '<Relationship Id="rId' + (i + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet' + (i + 1) + '.xml"/>').join('') +
    '<Relationship Id="rId' + (sheets.length + 1) + '" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>');
  files['_rels/.rels'] = strToU8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');
  files['[Content_Types].xml'] = strToU8('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>' +
    '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' +
    sheets.map((_, i) => '<Override PartName="/xl/worksheets/sheet' + (i + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>').join('') + '</Types>');
  const zip = zipSync(files, { level: 6 });
  let s = '';
  for (let i = 0; i < zip.length; i += 0x8000) s += String.fromCharCode.apply(null, zip.subarray(i, i + 0x8000));
  return btoa(s);
}
