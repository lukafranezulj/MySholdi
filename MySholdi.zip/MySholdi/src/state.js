// Globalno stanje aplikacije (jedan izvor istine za sučelje)
export const state = {
  settings: null,   // postavke (jezik, valuta, autospremanje, widgeti, kredit…)
  index: [],        // popis proračunskih tablica: [{id, name, year, updatedAt}]
  budget: null,     // trenutno otvorena tablica
  meta: {},         // lokalni podaci po tablici (veza na cloud datoteku, status sinkronizacije)
  trash: [],        // koš za smeće
  ui: {
    route: 'budgets',      // budgets | budget | widgets | settings | loan | trash
    tab: 'home',           // home | income | expense | net | summary
    month: new Date().getMonth(),
    drawer: false,
    edit: { income: false, expense: false, net: false },
  },
};

export const DEFAULT_SETTINGS = {
  lang: 'hr',
  currency: 'EUR',
  autosave: true,
  notifyFailures: true,
  allMonths: { income: false, expense: false },
  activeBudgetId: null,
  userName: '',
  showNet: false,                // neto imovina je skrivena dok se ne uključi u postavkama
  sharedOfflineReadOnly: false,  // zajedničke tablice: bez interneta samo pregled
  entriesSort: 'month',          // zadnji unosi: month | time | amountDesc | amountAsc
  layout: 'auto',                // izgled sučelja: auto | phone | tablet | pc
  theme: 'system',               // tema: system (prema sustavu) | light | dark
  bgAnim: true,                  // animirana pozadina kartica tablice
  avgIncludeZeros: false,        // prosjek: brojati i ćelije s upisanom nulom
  colors: { income: '#16a34a', expense: '#dc2626', diff: '#2563eb', palette: null },
  lock: { enabled: false, pinHash: '', salt: '', pinLen: 4, biometric: false, after: 0 },
  customGraphs: [],
  widgetDesigns: [],
  loan: { mode: 'amount', amount: 20000, years: 10, months: 0, rate: 4.5, payment: 250, inflation: 2.5, fee: 0, advanced: false },
  widgets: {
    month: { budgetId: null, theme: 'light', accent: '#2563eb', opacity: 100, radius: 28, showDiff: true, showDaily: false, title: '' },
    chart: { budgetId: null, theme: 'light', accent: '#2563eb', opacity: 100, radius: 28, chart: 'months', title: '' },
    quick: { budgetId: null, theme: 'dark', accent: '#22c55e', opacity: 100, radius: 28, count: 3, title: '' },
  },
};
