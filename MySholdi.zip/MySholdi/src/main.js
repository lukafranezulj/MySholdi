// MySholdi – glavni modul: pokretanje, okvir aplikacije, izbornik, navigacija
import { SystemBars, SystemBarsStyle } from '@capacitor/core';
import { App } from '@capacitor/app';
import { state } from './state.js';
import { t, setLang } from './i18n.js';
import { esc } from './util.js';
import { icon } from './icons.js';
import { loadAll, readBudget, saveSettings, writeBudget, saveMeta } from './storage.js';
import { normalizeBudget } from './model.js';
import { startSyncWatchers, onSyncChange, syncStatus, saveNow, pullRemote, onRemoteChange, metaOf, retryPending, flushLocal, cancelCloudTimer, isLocalFile } from './sync.js';
import { purgeOld } from './trash.js';
import { sheet, closeTopSheet, sheetOpen, toast } from './ui.js';
import { app } from './app.js';
import { refreshWidgets, ensureDesigns } from './widgets.js';
import { applyPalette } from './charts.js';
import { consumeLaunchAction, onLaunchAction, openUrl, isNative, webRegrant } from './native.js';
import { linkCreate } from './cloud.js';
import { renderBudget, mountBudget, budgetAction, budgetActions, resetEntriesShown } from './views/budget.js';
import { renderBudgets, budgetsAction } from './views/budgets.js';
import { renderSettings, mountSettings, settingsAction } from './views/settings.js';
import { renderLoan, mountLoan } from './views/loan.js';
import { renderTrash, trashAction } from './views/trash.js';
import { renderWidgets, mountWidgets, widgetsAction } from './views/widgetsView.js';
import { renderShared, sharedAction } from './views/shared.js';
import { renderGraphs, mountGraphCards, graphAction } from './views/graphs.js';
import { showLock, onPause, shouldLockOnResume, lockEnabled, isLocked } from './lock.js';
import { DONATE_URL, DEV_EMAIL, WEB_URL, APP_NAME } from './config.js';
import { visibleIndex, isHidden, renderHidden } from './views/budgets.js';

const root = document.getElementById('app');
let lastWidth = window.innerWidth;
const history = [];

const MENU = [
  ['budgets', 'table', 'menuBudgets'],
  ['shared', 'users', 'menuShared'],
  ['graphs', 'graph', 'menuGraphs'],
  ['widgets', 'widgets', 'menuWidgets'],
  ['settings', 'settings', 'menuSettings'],
  ['loan', 'calc', 'menuLoan'],
  ['trash', 'trash', 'menuTrash'],
];

function titleFor(route) {
  if (route === 'budget') return state.budget ? state.budget.name : '';
  if (route === 'hidden') return t('hiddenTables');
  return t({ budgets: 'menuBudgets', shared: 'menuShared', graphs: 'menuGraphs', widgets: 'menuWidgets', settings: 'menuSettings', loan: 'menuLoan', trash: 'menuTrash' }[route]);
}

// Gumb za spremanje u traci – boja i ikona pokazuju status sinkronizacije
function saveButton() {
  if (state.ui.route !== 'budget' || !state.budget) return '';
  const st = syncStatus(state.budget.id);
  const ic = { synced: 'cloudOk', unsaved: 'save', failed: 'cloudOff', offline: 'cloudOff', saving: 'cloud', local: 'save' }[st];
  return '<button class="icon-btn save-btn st-' + st + '" data-a="save" title="' + esc(t('st_' + st)) + '">' + icon(ic) + '</button>';
}

// Tablice sa svim mjesecima, sažetak i imovina na računalu/tabletu koriste punu širinu zaslona
function wideView() {
  if (state.ui.route !== 'budget' || !state.budget) return false;
  const tab = state.ui.tab;
  return tab === 'summary' || tab === 'net' || ((tab === 'income' || tab === 'expense') && !!state.settings.allMonths[tab]);
}
function render() {
  const r = state.ui.route;
  const content = { budget: renderBudget, budgets: renderBudgets, hidden: renderHidden, shared: renderShared, graphs: renderGraphs, settings: renderSettings, loan: renderLoan, trash: renderTrash, widgets: renderWidgets }[r]();
  const activeName = state.budget ? state.budget.name : '';
  root.innerHTML =
    '<header class="appbar"><button class="icon-btn" data-a="drawer" aria-label="' + esc(t('menu')) + '">' + icon('menu') + '</button>' +
    '<h1 class="' + (r === 'budget' ? 'clickable' : '') + '" ' + (r === 'budget' ? 'data-a="switchBudget"' : '') + '>' + esc(titleFor(r)) + (r === 'budget' ? icon('down', 'tiny') : '') + '</h1>' +
    '<div class="appbar-actions">' + (r === 'budget' ? budgetActions() : '') + '<span id="save-slot">' + saveButton() + '</span></div></header>' +
    '<aside class="drawer ' + (state.ui.drawer ? 'open' : '') + '"><div class="drawer-head"><div class="logo">' + icon('wallet') + '</div><div><b>' + APP_NAME + '</b><small>' + esc(activeName) + '</small></div></div>' +
    (state.budget ? '<button class="drawer-item budget-link ' + (r === 'budget' ? 'on' : '') + '" data-a="goBudget">' + icon('home') + '<span>' + esc(t('homePage')) + '</span></button><div class="drawer-sep"></div>' : '') +
    MENU.filter(([k]) => k !== 'widgets' || isNative).map(([k, ic, l]) => (k === 'widgets' || (k === 'settings' && !isNative) ? '<div class="drawer-sep"></div>' : '') + '<button class="drawer-item ' + (r === k ? 'on' : '') + '" data-go="' + k + '">' + icon(ic) + '<span>' + esc(t(l)) + '</span>' +
      (k === 'trash' && state.trash.length ? '<em>' + state.trash.length + '</em>' : '') + '</button>').join('') +
    (!isNative ? '<div class="drawer-sep"></div><button class="drawer-item" data-a="webDownload">' + icon('download') + '<span>' + esc(t('webDownload')) + '<small>' + esc(t('webDownloadHint')) + '</small></span></button>' : '') +
    '<div class="drawer-sep"></div><button class="drawer-item coffee" data-a="coffee">' + icon('coffee') + '<span>' + esc(t('menuCoffee')) + '</span></button>' +
    '<button class="drawer-item import-own" data-a="importOwn">' + icon('importIc') + '<span>' + esc(t('menuImportOwn')) + '</span></button>' +
    '<button class="drawer-item mail-dev" data-a="mailDev">' + icon('mail') + '<span>' + esc(t('menuMail')) + '<small>' + esc(DEV_EMAIL) + '</small></span></button>' +
    '</aside><div class="drawer-bg ' + (state.ui.drawer ? 'open' : '') + '" data-a="drawer"></div>' +
    '<main class="view view-' + r + (r === 'budget' ? ' tab-' + state.ui.tab : '') + (wideView() ? ' wide' : '') + '">' + content + '</main>';
  const main = root.querySelector('main');
  // pozadina prema kartici (prihodi zelenkasto, rashodi crvenkasto, sažetak žućkasto)
  document.body.dataset.screen = r === 'budget' ? state.ui.tab : r;
  applyAmbient();
  if (r === 'budget') mountBudget(main);
  if (r === 'settings') mountSettings(main);
  if (r === 'loan') mountLoan(main, render);
  if (r === 'widgets') mountWidgets(main, render);
  if (r === 'graphs') mountGraphCards(main);
  lastWidth = window.innerWidth;
}

function go(route, { push = true } = {}) {
  if (push && state.ui.route !== route) history.push({ route: state.ui.route, tab: state.ui.tab });
  state.ui.route = route; state.ui.drawer = false;
  render(); window.scrollTo(0, 0);
}

async function openBudget(id, { tab = 'home' } = {}) {
  let b = state.budget && state.budget.id === id ? state.budget : await readBudget(id);
  if (!b) { toast(t('errOpen')); return; }
  b = normalizeBudget(b);
  if (state.budget && state.budget.id !== id) { flushLocal(); cancelCloudTimer(); }
  state.budget = b;
  state.settings.activeBudgetId = id; saveSettings();
  state.ui.tab = tab;
  state.ui.month = b.year === new Date().getFullYear() ? new Date().getMonth() : 0;
  resetEntriesShown();
  history.length = 0;
  go('budget', { push: false });
  refreshWidgets();
  remoteCheck(b);
}

// Dohvat izmjena iz oblaka (drugi uređaj ili drugi korisnik zajedničke tablice) – spajaju se automatski
async function remoteCheck(b) {
  const r = await pullRemote(b);
  if (!state.budget || state.budget.id !== b.id) return;
  if (r.changed) toast(t('loadedNewer'));
}

async function switchBudget() {
  const v = await sheet({
    title: t('switchBudget'), body: '', cls: 'menu-sheet',
    actions: visibleIndex().map((x) => ({ label: x.name + ' (' + x.year + ')', value: x.id, cls: state.budget && x.id === state.budget.id ? 'primary' : '' }))
      .concat([{ label: t('manageBudgets'), value: '__manage' }]),
  });
  if (!v) return;
  if (v === '__manage') return go('budgets');
  openBudget(v);
}

async function onSave() {
  const b = state.budget;
  const m = metaOf(b.id);
  if (!m.link) {
    const ch = await sheet({
      title: t('saveWhereTitle'), body: '<p class="dlg-text">' + esc(t('saveWhereText')) + '</p>',
      actions: [{ label: t('onlyLocal'), value: 'local' }].concat(isNative ? [{ label: 'iCloud', value: 'icloud' }] : [], [{ label: t(isNative ? 'cloudGdOther' : 'chooseLocation'), value: 'link', cls: 'primary' }]),
    });
    if (ch === 'icloud') { const { icloudAndroid } = await import('./cloud.js'); return icloudAndroid(b); }
    if (ch === 'link') { await linkCreate(b, { direct: isNative }); render(); return; }
    if (ch === 'local') { await saveNow(b); toast(t('savedLocal')); render(); }
    return;
  }
  const r = await saveNow(b);
  // zeleno samo ako je stvarno zapisano u oblak; bez interneta: spremljeno lokalno (narančasto)
  if (r.ok) toast(t(isLocalFile(m) ? 'savedToFile' : 'syncOk'));
  else if (r.offline) toast(t('savedLocalOffline'), { kind: 'warnt' });
  else toast(t('syncFailShort'), { kind: 'bad' });
  render();
}

// Globalni klikovi (delegacija)
root.addEventListener('click', async (e) => {
  const go_ = e.target.closest('[data-go]');
  if (go_) { history.length = 0; return go(go_.dataset.go); }
  const tab = e.target.closest('[data-tab]');
  if (tab) { state.ui.tab = tab.dataset.tab; render(); window.scrollTo(0, 0); return; }
  const el = e.target.closest('[data-a]');
  if (!el) return;
  const a = el.dataset.a, d = el.dataset;
  if (a === 'drawer') { state.ui.drawer = !state.ui.drawer; root.querySelector('.drawer').classList.toggle('open', state.ui.drawer); root.querySelector('.drawer-bg').classList.toggle('open', state.ui.drawer); return; }
  if (a === 'goBudget') { state.ui.drawer = false; return go('budget'); }
  if (a === 'save') return onSave();
  if (a === 'switchBudget') return switchBudget();
  if (a === 'coffee') { state.ui.drawer = false; render(); return openUrl(DONATE_URL); }
  if (a === 'webDownload') {
    state.ui.drawer = false; render();
    // na web stranici: preuzmi samostalnu HTML datoteku; u lokalnoj datoteci: objasni gdje je i daj adresu web stranice
    if (/^https?:/.test(location.protocol)) {
      // samostalna datoteka objavljena kao stranica (npr. index.html na GitHub Pages) preuzima samu sebe
      const l = document.createElement('a'); l.href = window.__OFFLINE_FILE__ ? location.href.split('#')[0] : 'MySholdi-offline.html'; l.download = APP_NAME + '.html'; document.body.appendChild(l); l.click(); l.remove();
      toast(t('webDownloadStarted')); return;
    }
    const path = decodeURIComponent(location.pathname.replace(/^\/([A-Za-z]:)/, '$1'));
    const v = await sheet({
      title: t('webDownload'), cls: 'info-sheet',
      body: '<div class="info-body">' + t('webLocalHtml', { p: esc(path), u: esc(WEB_URL) }) + '</div>',
      actions: [{ label: t('close'), value: null }, { label: t('openWebPage'), value: 'web', cls: 'primary' }],
    });
    if (v === 'web') openUrl(WEB_URL);
    return;
  }
  if (a === 'mailDev') { state.ui.drawer = false; render(); return openUrl('mailto:' + DEV_EMAIL + '?subject=' + encodeURIComponent(APP_NAME + ' – ' + t('menuMail'))); }
  if (a === 'importOwn') { state.ui.drawer = false; render(); const { importOwnDialog } = await import('./importOwn.js'); return importOwnDialog(); }
  try {
    const r = state.ui.route;
    if (r === 'budget') await budgetAction(a, d);
    else if (r === 'budgets' || r === 'hidden') await budgetsAction(a, d);
    else if (r === 'settings') await settingsAction(a, d);
    else if (r === 'trash') await trashAction(a, d);
    else if (r === 'widgets') await widgetsAction(a, d, render);
    else if (r === 'shared') await sharedAction(a, d);
    else if (r === 'graphs') await graphAction(a, d, render);
  } catch (err) { console.error(err); toast(t('errGeneric') + ': ' + (err.message || err)); }
});

// Android tipka "natrag"
function onBack() {
  if (closeTopSheet()) return;
  if (state.ui.drawer) { state.ui.drawer = false; render(); return; }
  if (state.ui.route === 'budget' && state.ui.tab !== 'home') { state.ui.tab = 'home'; render(); return; }
  const prev = history.pop();
  if (prev) { state.ui.route = prev.route; state.ui.tab = prev.tab; render(); return; }
  if (state.ui.route !== 'budget' && state.budget) { go('budget', { push: false }); return; }
  App.minimizeApp().catch(() => {});
}

async function handleLaunch(action) {
  if (!action || !String(action).startsWith('quickadd')) return;
  if (isLocked()) await showLock();
  const type = String(action).split(':')[1];
  if (!state.budget) {
    const id = state.settings.activeBudgetId || (state.index[0] || {}).id;
    if (!id) return;
    await openBudget(id);
  } else if (state.ui.route !== 'budget' || state.ui.tab !== 'home') { state.ui.tab = 'home'; go('budget', { push: false }); }
  if (!sheetOpen()) budgetAction('quickAdd', type ? { type } : {});
}

// Izgled sučelja: automatski prema širini zaslona ili ručno (mobitel / tablet / računalo).
// Ručno odabran uži izgled na širokom zaslonu prikazuje se u "okviru" (kao pregled mobitela/tableta).
function applyLayout() {
  const w = window.innerWidth, mode = state.settings.layout || 'auto';
  const auto = w < 700 ? 'phone' : w < 1100 ? 'tablet' : 'pc';
  const lay = mode === 'auto' ? auto : mode;
  const h = document.documentElement;
  h.classList.remove('lay-phone', 'lay-tablet', 'lay-pc', 'lay-wide', 'framed', 'framed-phone', 'framed-tablet');
  h.classList.add('lay-' + lay);
  if (lay === 'pc' && w >= 1200) h.classList.add('lay-wide');
  if (mode !== 'auto' && lay === 'phone' && w > 560) h.classList.add('framed', 'framed-phone');
  if (mode !== 'auto' && lay === 'tablet' && w > 1000) h.classList.add('framed', 'framed-tablet');
}

// Tema: prema sustavu, svijetla ili tamna (klasa html.dark); boja traka sustava na Androidu prati temu
const darkMQ = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
let lastDark = null;
function applyTheme() {
  const th = state.settings.theme || 'system';
  const dark = th === 'dark' || (th === 'system' && !!(darkMQ && darkMQ.matches));
  const h = document.documentElement;
  h.classList.toggle('dark', dark);
  h.classList.toggle('amb-still', state.settings.bgAnim === false);
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = dark ? '#0e1116' : '#ffffff';
  if (isNative) { try { SystemBars.setStyle({ style: dark ? SystemBarsStyle.Dark : SystemBarsStyle.Light }).catch(() => { }); } catch (e) { } }
  const changed = lastDark !== null && lastDark !== dark;
  lastDark = dark;
  return changed;
}
// Animirana pozadina kartica tablice (naslovna, prihodi, rashodi, sažetak, imovina) – sloj iza sadržaja
const AMB_TABS = ['home', 'income', 'expense', 'summary', 'net'];
function applyAmbient() {
  if (!document.querySelector('.ambient')) document.body.insertAdjacentHTML('afterbegin', '<div class="ambient" aria-hidden="true"></div>');
  const on = state.ui.route === 'budget' && !!state.budget && AMB_TABS.includes(state.ui.tab);
  document.documentElement.classList.toggle('amb', on);
}

async function boot() {
  await loadAll();
  setLang(state.settings.lang);
  applyPalette(state.settings.colors && state.settings.colors.palette);
  document.documentElement.lang = state.settings.lang;
  await purgeOld();
  app.rerender = () => { render(); };
  app.applyLayout = applyLayout;
  applyLayout();
  app.applyTheme = () => { applyTheme(); render(); };
  applyTheme();
  if (darkMQ) {
    const onSys = () => { if ((state.settings.theme || 'system') === 'system' && applyTheme()) render(); };
    if (darkMQ.addEventListener) darkMQ.addEventListener('change', onSys); else if (darkMQ.addListener) darkMQ.addListener(onSys);
  }
  app.go = go;
  app.openBudget = openBudget;
  app.refreshWidgets = () => refreshWidgets();
  ensureDesigns();
  onRemoteChange(() => {
    const ae = document.activeElement;
    if (state.ui.route === 'budget' && !sheetOpen() && !(ae && ae.tagName === 'INPUT')) render();
    refreshWidgets();
  });
  // zaključavanje: pri pokretanju i nakon povratka u aplikaciju
  try {
    App.addListener('pause', () => onPause());
    App.addListener('resume', () => { if (shouldLockOnResume()) showLock(); if (state.budget && state.budget.shared) remoteCheck(state.budget); });
  } catch (e) { }
  // zajedničke tablice: povremeno dohvati izmjene ostalih korisnika
  setInterval(() => {
    const b = state.budget;
    if (!b || !b.shared || document.hidden || isLocked()) return;
    if (!metaOf(b.id).link) return;
    remoteCheck(b);
  }, 30000);
  // rotacija / promjena veličine prozora: ponovno iscrtaj (samo kad se promijeni širina, ne zbog tipkovnice)
  let rt;
  window.addEventListener('resize', () => {
    clearTimeout(rt);
    rt = setTimeout(() => { applyLayout(); if (window.innerWidth !== lastWidth && !(document.activeElement && document.activeElement.tagName === 'INPUT')) render(); }, 250);
  });
  let lastBannerKey = '';
  onSyncChange(() => {
    const slot = document.getElementById('save-slot'); if (slot) slot.innerHTML = saveButton();
    // ponovni prikaz samo kad se promijeni nešto što mijenja natpise (greška, bez interneta, samo pregled)
    if (state.ui.route === 'budget' && state.budget) {
      const st = syncStatus(state.budget.id);
      const key = (st === 'failed' ? 'f' : '') + (st === 'offline' ? 'o' : '') + (state.budget.shared && state.settings.sharedOfflineReadOnly && !state.online ? 'r' : '');
      if (key !== lastBannerKey) { lastBannerKey = key; render(); }
    }
    refreshWidgets();
  });
  startSyncWatchers();
  const lockP = lockEnabled() ? showLock() : null;
  try { App.addListener('backButton', onBack); } catch (e) { }
  // preglednik na računalu: nakon ponovnog otvaranja stranice dopuštenje za datoteku (npr. u mapi Google Drivea)
  // traži se pri prvom kliku; zatim se učitaju izmjene s drugih uređaja i pošalje ono što čeka
  if (!isNative) {
    const regrant = async () => {
      const b = state.budget; const m = b && state.meta[b.id];
      if (!m || !m.link || !String(m.link.uri).startsWith('fsa:')) return;
      if (await webRegrant(m.link.uri)) { await remoteCheck(b); retryPending(); render(); }
    };
    document.addEventListener('pointerdown', regrant, true);
  }
  // preglednik na računalu: Esc zatvara otvoreni prozor (i izlazi iz prikaza grafa preko cijelog zaslona)
  if (!isNative) document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && sheetOpen()) { e.preventDefault(); closeTopSheet(); } });
  const id = state.settings.activeBudgetId;
  if (id && state.index.some((x) => x.id === id) && !isHidden(id)) await openBudget(id);
  else go('budgets', { push: false });
  // akcije iz widgeta (npr. brzi unos) – tek nakon što je tablica otvorena
  onLaunchAction(handleLaunch);
  if (lockP) await lockP;
  const la = await consumeLaunchAction();
  if (la) handleLaunch(la);
  retryPending();
  refreshWidgets();
  document.body.classList.add('ready');
}
boot().catch((e) => { console.error(e); root.innerHTML = '<p style="padding:20px">Error: ' + esc(e.message || e) + '</p>'; });
