// Widgeti za početni zaslon. Svaki "dizajn" ima svoju sliku (PNG); svaki widget na zaslonu
// povezan je sa svojim dizajnom, pa više widgeta može imati različit izgled.
import { APP_NAME } from './config.js';
import { state } from './state.js';
import { t } from './i18n.js';
import { money, monthName, fmtNum, debounce, uid } from './util.js';
import { calcSide, calcNet, itemLabel } from './model.js';
import { drawBars, drawDonut, drawHBars, fillRound, PALETTE } from './charts.js';
import { readBudget } from './storage.js';
import { updateWidget, setWidgetDesigns, refreshAllWidgets, isNative } from './native.js';
import { computeGraph, toChartData, toPieParts, loadBudgetsFor } from './graphs.js';

export const WIDGET_KINDS = ['month', 'pie', 'chart', 'quick', 'add1', 'add2'];
export const WIDGET_SIZE = { month: [340, 170], pie: [340, 210], chart: [340, 170], quick: [340, 200], add1: [150, 150], add2: [300, 130] };
export const PIE_VALUES = ['money', 'pct', 'both'];
export const THEMES = ['light', 'dark', 'glass', 'accent'];
export const ACCENTS = ['#2563eb', '#16a34a', '#dc2626', '#7c3aed', '#d97706', '#0891b2', '#db2777', '#111827'];
export const CHART_TYPES = ['months', 'categories', 'items', 'net', 'custom'];

const DEF = {
  month: { theme: 'light', accent: '#2563eb', showDiff: true, showDaily: false },
  pie: { theme: 'light', accent: '#2563eb', pieLevel: 'groups', pieValues: 'money' },
  chart: { theme: 'light', accent: '#2563eb', chart: 'months', graphId: null, pieValues: 'money' },
  quick: { theme: 'dark', accent: '#22c55e', count: 3 },
  add1: { theme: 'accent', accent: '#2563eb', entryType: 'expense' },
  add2: { theme: 'light', accent: '#dc2626', entryType: 'expense', showMonth: true },
};
export function newDesign(kind) {
  return { id: uid('w'), kind, name: '', budgetId: null, opacity: 100, radius: kind === 'add1' ? 34 : 28, title: '', ...DEF[kind] };
}
// Prijenos starih postavki (jedan izgled po vrsti) u popis dizajna
export function ensureDesigns() {
  const s = state.settings;
  if (Array.isArray(s.widgetDesigns) && s.widgetDesigns.length) {
    // novije vrste widgeta (npr. pie rashoda) dodaju se postojećem popisu
    WIDGET_KINDS.forEach((k) => { if (!s.widgetDesigns.some((d) => d.kind === k)) s.widgetDesigns.push({ ...newDesign(k), id: 'w_' + k }); });
    return;
  }
  const old = s.widgets || {};
  s.widgetDesigns = WIDGET_KINDS.map((k) => ({ ...newDesign(k), ...(old[k] || {}), id: 'w_' + k, kind: k }));
}
export const designName = (d, i) => d.name || (t('w_' + d.kind) + (i > 0 ? ' ' + (i + 1) : ''));

function hexA(hex, a) {
  const h = String(hex || '#2563eb').replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16);
  return 'rgba(' + ((n >> 16) & 255) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')';
}
function palette(cfg) {
  const op = (cfg.opacity ?? 100) / 100;
  const P = {
    light: { bg: hexA('#ffffff', op), text: '#111827', mut: '#6b7280', inc: '#15803d', exp: '#dc2626', line: '#e5e7eb', track: '#eef0f3' },
    dark: { bg: hexA('#111827', op), text: '#f9fafb', mut: '#9ca3af', inc: '#4ade80', exp: '#f87171', line: '#374151', track: '#1f2937' },
    glass: { bg: hexA('#0f172a', 0.38 * op), text: '#ffffff', mut: 'rgba(255,255,255,.75)', inc: '#86efac', exp: '#fca5a5', line: 'rgba(255,255,255,.25)', track: 'rgba(255,255,255,.18)' },
    accent: { bg: hexA(cfg.accent || '#2563eb', op), text: '#ffffff', mut: 'rgba(255,255,255,.78)', inc: '#ffffff', exp: '#ffffff', line: 'rgba(255,255,255,.3)', track: 'rgba(255,255,255,.25)' },
  }[cfg.theme] || {};
  P.acc = cfg.theme === 'accent' ? '#ffffff' : cfg.accent || '#2563eb';
  return P;
}

// Iscrtavanje jednog dizajna u canvas. data = { budget, budgets(Map) }
export function renderWidget(cfg, data, scale = 3) {
  const kind = cfg.kind;
  const budget = data.budget;
  const [W, H] = WIDGET_SIZE[kind];
  const cv = document.createElement('canvas');
  cv.width = W * scale; cv.height = H * scale;
  const ctx = cv.getContext('2d');
  ctx.scale(scale, scale);
  const c = palette(cfg);
  const F = 'system-ui, -apple-system, Roboto, sans-serif';
  const pad = kind === 'add1' ? 12 : 16;
  ctx.fillStyle = c.bg; fillRound(ctx, 0, 0, W, H, Math.min(cfg.radius ?? 28, H / 2)); ctx.fill();
  ctx.textBaseline = 'alphabetic';
  const text = (s, x, y, size, color, weight = 400, align = 'left', maxW) => {
    ctx.font = weight + ' ' + size + 'px ' + F; ctx.fillStyle = color; ctx.textAlign = align;
    let str = String(s);
    if (maxW) while (str.length > 2 && ctx.measureText(str).width > maxW) str = str.slice(0, -2) + '…';
    ctx.fillText(str, x, y);
  };
  const plus = (cx, cy, r, bg, fg) => {
    ctx.fillStyle = bg; ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = fg; ctx.lineWidth = Math.max(2.5, r / 5.5); ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(cx, cy - r * 0.42); ctx.lineTo(cx, cy + r * 0.42); ctx.moveTo(cx - r * 0.42, cy); ctx.lineTo(cx + r * 0.42, cy); ctx.stroke();
  };
  const isInc = cfg.entryType === 'income';
  const plusBg = cfg.theme === 'accent' ? 'rgba(255,255,255,.95)' : (cfg.accent || '#2563eb');
  const plusFg = cfg.theme === 'accent' ? (cfg.accent || '#2563eb') : '#ffffff';

  // 1×1: samo gumb za unos
  if (kind === 'add1') {
    plus(W / 2, H / 2 - 12, 34, plusBg, plusFg);
    text(cfg.title || t(isInc ? 'incomeOne' : 'expense'), W / 2, H - 20, 14, c.text, 650, 'center', W - 16);
    return cv;
  }
  if (!budget && kind !== 'chart') {
    text(APP_NAME, pad, pad + 16, 15, c.text, 700);
    text(t('widgetNoBudget'), pad, H / 2 + 8, 13, c.mut, 400, 'left', W - pad * 2);
    return cv;
  }
  const m = budget ? (budget.year === new Date().getFullYear() ? new Date().getMonth() : 11) : new Date().getMonth();

  if (kind === 'add2') {
    plus(pad + 34, H / 2, 34, plusBg, plusFg);
    const x = pad + 84;
    text(cfg.title || t(isInc ? 'addIncome' : 'addExpense'), x, H / 2 - (cfg.showMonth ? 6 : -6), 17, c.text, 700, 'left', W - x - pad);
    if (cfg.showMonth && budget) {
      const v = calcSide(budget, isInc ? 'income' : 'expense').monthly[m];
      text(monthName(m) + ': ' + money(v, { dec: 0 }), x, H / 2 + 18, 13, isInc ? c.inc : c.exp, 600, 'left', W - x - pad);
    }
    return cv;
  }
  if (kind === 'month') {
    const inc = calcSide(budget, 'income'), exp = calcSide(budget, 'expense');
    const I = inc.monthly[m], E = exp.monthly[m], D = I - E;
    text(cfg.title || monthName(m) + ' ' + budget.year, pad, pad + 13, 13, c.mut, 600, 'left', W - pad * 2 - 60);
    text(APP_NAME, W - pad, pad + 13, 10, c.mut, 500, 'right');
    const colW = (W - pad * 2) / (cfg.showDiff ? 3 : 2);
    const cell = (i, lbl, val, col) => { const x = pad + i * colW; text(lbl, x, pad + 46, 11, c.mut, 500); text(val, x, pad + 70, 18, col, 700, 'left', colW - 6); };
    cell(0, t('income'), money(I, { dec: 0 }), c.inc);
    cell(1, t('expenses'), money(E, { dec: 0 }), c.exp);
    if (cfg.showDiff) cell(2, t('difference'), money(D, { dec: 0, sign: true }), D < 0 ? c.exp : c.acc);
    const by = H - pad - 30, bw = W - pad * 2;
    ctx.fillStyle = c.track; fillRound(ctx, pad, by, bw, 8, 4); ctx.fill();
    const p = I ? Math.min(1, E / I) : (E ? 1 : 0);
    if (p > 0) { ctx.fillStyle = E > I ? c.exp : c.acc; fillRound(ctx, pad, by, Math.max(8, bw * p), 8, 4); ctx.fill(); }
    text(I ? t('spentOfIncome', { p: fmtNum(E / I * 100, 0) }) : '', pad, H - pad - 4, 11, c.mut);
    if (cfg.showDaily) text(t('dailyAvg') + ' ' + money(exp.daily[m], { dec: 0 }), W - pad, H - pad - 4, 11, c.mut, 400, 'right');
    return cv;
  }
  const pieCols = cfg.theme === 'accent' ? ['#ffffff', 'rgba(255,255,255,.78)', 'rgba(255,255,255,.58)', 'rgba(255,255,255,.42)', 'rgba(255,255,255,.3)', 'rgba(255,255,255,.2)'] : PALETTE;
  // Rashodi trenutnog mjeseca po naslovima (ili podnaslovima), legenda od većeg prema manjem
  if (kind === 'pie') {
    const S = calcSide(budget, 'expense');
    const parts = [];
    if (cfg.pieLevel === 'items') budget.expense.forEach((g, gi) => g.items.forEach((it, ii) => parts.push({ n: it.name, v: S.groups[gi].rows[ii].m[m] })));
    else budget.expense.forEach((g, gi) => parts.push({ n: g.name, v: S.groups[gi].m[m] }));
    text(cfg.title || t('expensesIn', { m: monthName(m) }), pad, pad + 13, 13, c.text, 600, 'left', W - pad * 2);
    pieBlock(ctx, c, text, { x: pad, y: pad + 24, w: W - pad * 2, h: H - pad * 2 - 24, parts, colors: pieCols, values: cfg.pieValues, thick: 0.34, center: money(S.monthly[m], { dec: 0 }) });
    return cv;
  }
  if (kind === 'chart') {
    const type = cfg.chart || 'months';
    const bars = { text: c.mut, grid: c.line, zero: c.line, fontSize: 9, font: F, noAxis: true };
    if (type === 'custom') {
      const g = (state.settings.customGraphs || []).find((x) => x.id === cfg.graphId);
      text(cfg.title || (g ? g.name : t('customGraph')), pad, pad + 13, 13, c.text, 600, 'left', W - pad * 2);
      if (!g || !g.series.length) { text(t('noData'), pad, H / 2 + 6, 12, c.mut); return cv; }
      const comp = computeGraph(g, data.budgets || new Map(), 1);
      const cols = cfg.theme === 'accent' ? ['#ffffff', 'rgba(255,255,255,.65)', 'rgba(255,255,255,.4)', 'rgba(255,255,255,.25)'] : null;
      if (cols) comp.series.forEach((s, i) => { s.color = cols[i % cols.length]; });
      if (g.chart === 'pie') {
        const parts = toPieParts(comp).map((p) => ({ n: String(p.n).split(' · ').pop(), v: p.v, color: p.color }));
        pieBlock(ctx, c, text, { x: pad, y: pad + 22, w: W - pad * 2, h: H - pad * 2 - 22, parts, colors: pieCols, values: cfg.pieValues || g.pieValues || 'money', thick: 1 });
        return cv;
      }
      drawBars(ctx, pad - 2, pad + 22, W - pad * 2 + 4, H - pad * 2 - 20, toChartData(comp, g.chart), bars);
      return cv;
    }
    if (!budget) { text(t('widgetNoBudget'), pad, H / 2, 12, c.mut); return cv; }
    const ttl = cfg.title || { months: t('incomeVsExpenses') + ' ' + budget.year, categories: t('expensesIn', { m: monthName(m) }), items: t('expenseItemsYear') + ' ' + budget.year, net: t('netWorth') }[type];
    text(ttl, pad, pad + 13, 13, c.text, 600, 'left', W - pad * 2 - (type === 'net' ? 90 : 0));
    if (type === 'months') {
      drawBars(ctx, pad - 2, pad + 22, W - pad * 2 + 4, H - pad * 2 - 20, {
        labels: Array.from({ length: 12 }, (_, i) => monthName(i, true).slice(0, 1)),
        series: [{ values: calcSide(budget, 'income').monthly, color: c.inc }, { values: calcSide(budget, 'expense').monthly, color: c.exp }],
      }, bars);
    } else if (type === 'categories') {
      const S = calcSide(budget, 'expense');
      const parts = budget.expense.map((g, i) => ({ n: g.name, v: S.groups[i].m[m] }));
      pieBlock(ctx, c, text, { x: pad, y: pad + 22, w: W - pad * 2, h: H - pad * 2 - 22, parts, colors: pieCols, values: cfg.pieValues, thick: 0.34, center: money(S.monthly[m], { dec: 0 }) });
    } else if (type === 'items') {
      const S = calcSide(budget, 'expense');
      const all = [];
      budget.expense.forEach((g, gi) => g.items.forEach((it, ii) => { const v = S.groups[gi].rows[ii].total; if (v > 0) all.push({ n: it.name, v, color: cfg.theme === 'accent' ? '#ffffff' : PALETTE[gi % PALETTE.length] }); }));
      all.sort((a, b) => b.v - a.v);
      const top = all.slice(0, 5);
      if (!top.length) text(t('noData'), pad, H / 2, 12, c.mut);
      else drawHBars(ctx, pad, pad + 24, W - pad * 2, H - pad * 2 - 24, top, { text: c.text, mut: c.mut, track: c.track, fontSize: 11, font: F, fmt: (v) => money(v, { dec: 0 }), valW: 64 });
    } else {
      const N = calcNet(budget);
      drawBars(ctx, pad - 2, pad + 22, W - pad * 2 + 4, H - pad * 2 - 20, {
        labels: budget.net.periods.map((p) => p.slice(0, 3)), series: [{ values: N.net.map((x) => (isNaN(x) ? 0 : x)), color: c.acc }],
      }, { ...bars, fontSize: 10 });
      const last = [...N.net].reverse().find((x) => !isNaN(x));
      if (last !== undefined) text(money(last, { dec: 0 }), W - pad, pad + 13, 13, c.acc, 700, 'right');
    }
    return cv;
  }
  // quick: zadnji unosi + gumb
  text(cfg.title || APP_NAME, pad, pad + 16, 15, c.text, 700, 'left', W - pad * 2 - 50);
  plus(W - pad - 17, pad + 13, 17, plusBg, plusFg);
  const list = budget.entries.slice(0, cfg.count || 3);
  let y = pad + 48;
  if (!list.length) text(t('widgetTapToAdd'), pad, y + 10, 12, c.mut);
  list.forEach((e) => {
    const lbl = itemLabel(budget, e.type, e.gid, e.iid) || e.label;
    const short = String(lbl).split(' › ').pop();
    const inc = e.type === 'income';
    ctx.strokeStyle = c.line; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(pad, y - 16); ctx.lineTo(W - pad, y - 16); ctx.stroke();
    text(short, pad, y, 12.5, c.text, 500, 'left', W - pad * 2 - 100);
    const d = new Date(e.ts);
    text(d.getDate() + '.' + (d.getMonth() + 1) + '. ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0') + (e.by && budget.shared ? ' · ' + e.by : ''), pad, y + 14, 10, c.mut);
    text(money(inc ? e.amount : -e.amount, { sign: true }), W - pad, y + 4, 13, inc ? c.inc : c.exp, 700, 'right');
    y += 38;
  });
  return cv;
}

// Krafna/pie s legendom: sve stavke od veće prema manjoj; legenda se prilagođava broju stavki
// (manji redovi, dva stupca), a tek ako ni tada ne stane, najmanje se spajaju u "Ostalo".
// values: 'money' (zadano) | 'pct' | 'both'
function pieBlock(ctx, c, text, o) {
  const { x, y, w, h, colors } = o;
  let parts = o.parts.filter((p) => p.v > 0).sort((a, b) => b.v - a.v).map((p, i) => ({ ...p, color: p.color || colors[i % colors.length] }));
  const total = parts.reduce((a, p) => a + p.v, 0);
  const r = Math.max(20, Math.min(h / 2, w * 0.23));
  const cx = x + r, cy = y + h / 2;
  const lx = cx + r + 14, lw = x + w - lx;
  // koliko redova stane
  let cols = 1;
  const minRow = 12.5;
  if (parts.length * minRow > h && lw > 200) cols = 2;
  const perCol = Math.max(1, Math.floor(h / minRow));
  const fit = perCol * cols;
  if (parts.length > fit) {
    const keep = parts.slice(0, fit - 1);
    const rest = parts.slice(fit - 1).reduce((a, p) => a + p.v, 0);
    parts = keep.concat([{ n: t('other'), v: rest, color: c.mut }]);
  }
  drawDonut(ctx, cx, cy, r, parts.map((p) => p.v), parts.map((p) => p.color), { empty: c.track, thickness: r * (o.thick || 0.34) });
  if (o.center) text(o.center, cx, cy + 5, Math.min(13, r * 0.36), c.text, 700, 'center', r * 1.35);
  if (!parts.length) { text(t('noData'), lx, cy + 4, 12, c.mut); return; }
  const rows = Math.ceil(parts.length / cols);
  const rowH = Math.max(minRow, Math.min(21, h / rows));
  const fs = Math.max(8.5, Math.min(11, rowH * 0.6));
  const colW = lw / cols;
  const pct = (v) => fmtNum(total ? v / total * 100 : 0, 0) + ' %';
  const val = (v) => o.values === 'pct' ? pct(v) : o.values === 'both' ? money(v, { dec: 0 }) + ' · ' + pct(v) : money(v, { dec: 0 });
  const top = y + (h - rows * rowH) / 2;
  parts.forEach((p, i) => {
    const col = Math.floor(i / rows), row = i % rows;
    const bx = lx + col * colW, by = top + row * rowH + rowH / 2;
    const sq = Math.min(10, fs);
    ctx.fillStyle = p.color; fillRound(ctx, bx, by - sq / 2, sq, sq, 3); ctx.fill();
    const vs = val(p.v);
    ctx.font = '500 ' + fs + 'px system-ui, -apple-system, Roboto, sans-serif';
    const vw = ctx.measureText(vs).width;
    const right = bx + colW - (cols > 1 && col === 0 ? 10 : 0);
    text(p.n, bx + sq + 6, by + fs * 0.36, fs, c.text, 500, 'left', right - (bx + sq + 6) - vw - 6);
    text(vs, right, by + fs * 0.36, fs, c.mut, 600, 'right');
  });
}

// Podaci potrebni za iscrtavanje dizajna
export async function dataFor(cfg) {
  let id = cfg.budgetId || state.settings.activeBudgetId;
  if (id && state.meta[id] && state.meta[id].hidden) id = null;
  let budget = null;
  if (id) budget = state.budget && state.budget.id === id ? state.budget : await readBudget(id);
  let budgets = new Map();
  if (cfg.kind === 'chart' && cfg.chart === 'custom') {
    const g = (state.settings.customGraphs || []).find((x) => x.id === cfg.graphId);
    if (g) budgets = await loadBudgetsFor([g]);
  }
  return { budget, budgets };
}

// Osvježavanje svih widgeta na početnom zaslonu
async function doRefresh() {
  if (!isNative) return;
  ensureDesigns();
  const list = state.settings.widgetDesigns;
  await setWidgetDesigns(list.map((d, i) => ({ id: d.id, kind: d.kind, name: designName(d, list.filter((x) => x.kind === d.kind).indexOf(d)), entryType: d.entryType || '' })));
  for (const d of list) {
    const cv = renderWidget(d, await dataFor(d), 3);
    await updateWidget(d.id, cv.toDataURL('image/png'));
  }
  await refreshAllWidgets();
}
export const refreshWidgets = debounce(doRefresh, 1200);
