// "Primjer tablice": prosječni Hrvat s prosječnim primanjima i navikama (ilustrativno).
// Polazište: prosječna neto plaća u RH, 1. polugodište 2026. ≈ 1.542 € (DZS);
// struktura potrošnje kućanstava (DZS, Anketa o potrošnji 2022.): hrana ~27 %, prijevoz ~15,5 %, stanovanje ~14,5 %, odjeća ~7 %.
import { newBudget, logEntry } from './model.js';
import { getLang } from './i18n.js';
import { round2, uid } from './util.js';

// [indeks naslova, indeks podnaslova, iznosi po mjesecima (12) ili jedan iznos za svaki mjesec]
const SEASON = (base, amp, peak) => Array.from({ length: 12 }, (_, m) => round2(base + amp * Math.cos((m - peak) / 12 * 2 * Math.PI)));
const ONLY = (m, v) => Array.from({ length: 12 }, (_, i) => (Array.isArray(m) ? (m.includes(i) ? v : null) : (i === m ? v : null)));
const NOISE = (arr, pct, seed) => arr.map((v, i) => (v == null ? null : round2(v * (1 + pct * Math.sin(seed * 7.3 + i * 2.1)))));

export function sampleBudget(name, year) {
  const b = newBudget(name, year);
  b.example = true;
  const set = (side, gi, ii, vals) => { const it = b[side][gi] && b[side][gi].items[ii]; if (it) it.vals = vals.map((v) => (v == null ? null : round2(v))); };
  // PRIHODI
  set('income', 0, 0, NOISE(Array(12).fill(1542), 0.02, 1));          // plaća
  set('income', 0, 1, ONLY([3, 9], 180));                                // honorari / dodatni rad
  set('income', 0, 2, (() => { const a = ONLY(5, 300); a[11] = 300; return a; })()); // regres + božićnica
  set('income', 1, 0, ONLY(8, 220));                                     // povrat poreza
  set('income', 1, 1, ONLY([0, 11], 100));                               // pokloni
  set('income', 1, 3, ONLY([2, 5, 8, 11], 8));                           // kamate
  // RASHODI – stanovanje (vlasnik stana, bez najma)
  set('expense', 0, 1, SEASON(120, 35, 0));                              // režije (zimi više)
  set('expense', 0, 2, Array(12).fill(32));                              // internet i TV
  set('expense', 0, 3, ONLY([3, 9], 85));                                // održavanje
  // hrana i piće (~27 %)
  set('expense', 1, 0, NOISE(Array(12).fill(285), 0.06, 2));            // namirnice
  set('expense', 1, 1, NOISE(SEASON(48, 12, 7), 0.1, 3));                // restorani
  set('expense', 1, 2, NOISE(Array(12).fill(32), 0.1, 4));               // kava
  set('expense', 1, 3, NOISE(Array(12).fill(38), 0.05, 5));              // hrana na poslu
  // prijevoz (~15 %)
  set('expense', 2, 0, NOISE(SEASON(135, 25, 7), 0.07, 6));              // gorivo
  set('expense', 2, 2, ONLY(4, 420));                                    // registracija i osiguranje
  set('expense', 2, 3, ONLY([2, 9], 160));                               // servis
  // financije
  set('expense', 3, 0, Array(12).fill(4.5));                             // bankovne naknade
  set('expense', 3, 2, Array(12).fill(100));                             // štednja i investicije
  set('expense', 3, 3, ONLY(0, 180));                                    // osiguranja
  // pretplate
  set('expense', 4, 0, Array(12).fill(19));
  set('expense', 4, 1, Array(12).fill(14));
  set('expense', 4, 2, ONLY(0, 60));
  // zdravlje i njega
  set('expense', 5, 0, NOISE(Array(12).fill(22), 0.3, 7));
  set('expense', 5, 1, NOISE(Array(12).fill(25), 0.15, 8));
  set('expense', 5, 2, Array.from({ length: 12 }, (_, i) => (i % 2 === 0 ? 18 : null)));
  set('expense', 5, 3, Array(12).fill(30));
  // odjeća i kućanstvo (~7 %)
  set('expense', 6, 0, NOISE(SEASON(85, 45, 10), 0.15, 9));
  set('expense', 6, 1, ONLY([6, 11], 140));
  set('expense', 6, 2, ONLY(3, 220));
  // slobodno vrijeme
  set('expense', 7, 0, NOISE(SEASON(55, 25, 7), 0.1, 10));
  set('expense', 7, 1, NOISE(Array(12).fill(20), 0.2, 11));
  set('expense', 7, 2, ONLY(7, 650));                                    // ljetovanje
  set('expense', 7, 3, ONLY([1, 4, 10], 25));
  // obrazovanje
  set('expense', 8, 1, ONLY([0, 8], 40));
  // pokloni i prigode
  set('expense', 9, 0, (() => { const a = ONLY([2, 4, 8], 40); a[11] = 230; return a; })());
  set('expense', 9, 1, ONLY(6, 150));
  set('expense', 9, 2, ONLY(11, 30));
  // ostalo
  set('expense', 10, 0, NOISE(Array(12).fill(25), 0.3, 12));
  // NETO IMOVINA (stanje na kraju kvartala)
  const net = { assets: [[0, 125000], [1, 7500, -250], [2, 6200, 380], [3, 600, 0], [4, 14800, 450], [5, 2400, 330]], liabilities: [[1, 4800, -420], [2, 350, 0]] };
  for (const side of ['assets', 'liabilities']) for (const [i, v, step = 0] of net[side]) b.net[side][i].vals = [0, 1, 2, 3].map((q) => round2(v + q * step));
  // nekoliko primjera unosa za naslovnu
  const m = year === new Date().getFullYear() ? new Date().getMonth() : 11;
  const add = (side, gi, ii, amount, hoursAgo, note = '') => {
    const g = b[side][gi], it = g.items[ii];
    const e = logEntry(b, { type: side, gid: g.id, iid: it.id, month: m, amount, note });
    e.ts = Date.now() - hoursAgo * 3600000; e.by = getLang() === 'en' ? 'Example' : 'Primjer'; e.id = uid('e');
  };
  add('expense', 2, 0, 55, 70); add('expense', 1, 0, 42.8, 30); add('expense', 1, 2, 3.5, 5); add('income', 0, 0, 1542, 200);
  b.entries.sort((a, c) => c.ts - a.ts);
  return b;
}
