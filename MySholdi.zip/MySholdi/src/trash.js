// Koš za smeće: obrisane stavke čuvaju se 30 dana, nakon toga se trajno brišu
import { state } from './state.js';
import { saveTrash, readBudget, writeBudget, saveMeta } from './storage.js';
import { uid, clone } from './util.js';
import { addToCell, findItem } from './model.js';
import { persist } from './sync.js';
import { t } from './i18n.js';

export const TRASH_DAYS = 30;

// kind: budget | group | item | entry | netrow
export async function toTrash(kind, label, data, ctx = {}) {
  const item = { id: uid('t'), kind, label, data: clone(data), ctx, deletedAt: Date.now() };
  state.trash.unshift(item);
  await saveTrash();
  return item;
}

export async function purgeOld() {
  const lim = Date.now() - TRASH_DAYS * 86400000;
  const before = state.trash.length;
  state.trash = state.trash.filter((x) => x.deletedAt >= lim);
  if (state.trash.length !== before) await saveTrash();
}
export function daysLeft(x) { return Math.max(0, TRASH_DAYS - Math.floor((Date.now() - x.deletedAt) / 86400000)); }

export async function deleteForever(id) {
  state.trash = state.trash.filter((x) => x.id !== id);
  await saveTrash();
}
export async function emptyTrash() { state.trash = []; await saveTrash(); }

// Dohvat tablice (otvorene ili s diska) za vraćanje stavke
async function getBudget(id) {
  if (state.budget && state.budget.id === id) return state.budget;
  return readBudget(id);
}
async function saveBudget(b) {
  if (state.budget && state.budget.id === b.id) persist(b);
  else { b.updatedAt = Date.now(); await writeBudget(b); const m = state.meta[b.id]; if (m) { m.dirty = true; await saveMeta(); } }
}

// Vraćanje iz koša. Vraća {ok, msg}
export async function restore(id) {
  const x = state.trash.find((i) => i.id === id);
  if (!x) return { ok: false };
  if (x.kind === 'budget') {
    const b = x.data;
    if (state.index.some((i) => i.id === b.id)) b.id = uid('b');
    let name = b.name, n = 2;
    while (state.index.some((i) => i.name.toLowerCase() === name.toLowerCase())) name = b.name + ' (' + n++ + ')';
    b.name = name;
    b.updatedAt = Date.now();
    await writeBudget(b);
    if (x.ctx.meta) { state.meta[b.id] = { ...x.ctx.meta, pending: false }; await saveMeta(); }
  } else {
    const b = await getBudget(x.ctx.budgetId);
    if (!b) return { ok: false, msg: t('trashNoBudget') };
    if (x.kind === 'group') {
      const list = b[x.ctx.type];
      x.data.aliveTs = Date.now();   // vraćeno: novije od oznake brisanja
      list.splice(Math.min(x.ctx.index ?? list.length, list.length), 0, x.data);
    } else if (x.kind === 'item') {
      const list = b[x.ctx.type];
      let g = list.find((gg) => gg.id === x.ctx.gid);
      if (!g) { if (!list.length) return { ok: false, msg: t('trashNoGroup') }; g = list[0]; }
      x.data.aliveTs = Date.now();
      g.items.splice(Math.min(x.ctx.index ?? g.items.length, g.items.length), 0, x.data);
    } else if (x.kind === 'entry') {
      const e = x.data;
      const { it } = findItem(b, e.type, e.gid, e.iid);
      if (!it) return { ok: false, msg: t('trashNoItem') };
      addToCell(b, e.type, e.gid, e.iid, e.month, e.amount);
      e.aliveTs = Date.now();
      b.entries.push(e);
      b.entries.sort((a, c) => c.ts - a.ts);
    } else if (x.kind === 'netrow') {
      const list = b.net[x.ctx.side];
      const row = x.data;
      row.vals = b.net.periods.map((_, i) => row.vals[i] ?? null);
      row.aliveTs = Date.now();
      list.splice(Math.min(x.ctx.index ?? list.length, list.length), 0, row);
    }
    await saveBudget(b);
  }
  state.trash = state.trash.filter((i) => i.id !== id);
  await saveTrash();
  return { ok: true };
}
