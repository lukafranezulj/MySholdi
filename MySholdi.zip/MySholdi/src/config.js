// Osnovne postavke aplikacije
export const APP_VERSION = '1.4.0';
// Ime aplikacije (prikazuje se korisniku; interni ID-jevi ostaju MySholdi radi postojećih podataka)
export const APP_NAME = 'MojiSholdi';
// Poveznica za "Počasti developera kavom" (PayPal.me)
export const DONATE_URL = 'https://paypal.me/lfzulj';
// E-mail za prijedloge i pitanja
export const DEV_EMAIL = 'lukafrane.zulj@gmail.com';
// Adresa web inačice (GitHub Pages)
export const WEB_URL = 'https://lukafranezulj.github.io/MySholdi/';
