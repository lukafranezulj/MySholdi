// Custom grafovi: proizvoljni naslovi/podnaslovi iz jedne ili više tablica (i različitih godina)
import { state } from './state.js';
import { t } from './i18n.js';
import { uid, monthName } from './util.js';
import { calcSide, findItem } from './model.js';
import { readBudget } from './storage.js';
import { PALETTE } from './charts.js';

export function newGraph(budgetId) {
  return { id: uid('cg'), name: t('customGraph'), chart: 'line', months: [...Array(12).keys()], series: budgetId ? [{ id: uid('s'), budgetId, side: 'expense', gid: null, iid: null, color: PALETTE[0] }] : [] };
}

// Mjeseci koji se prikazuju: odabrani ili samo aktivni (trenutni) mjesec
export const curMonth = () => new Date().getMonth();
export function graphMonths(g) {
  if (g.monthMode === 'current') return [curMonth()];
  return (g.months && g.months.length ? g.months : [...Array(12).keys()]).slice().sort((a, b) => a - b);
}
// Graf po godinama: koje tablice ulaze (null/prazno = sve vidljive, pa se nove tablice dodaju same)
export function yearBudgetIds(g) {
  const vis = state.index.filter((x) => !(state.meta[x.id] && state.meta[x.id].hidden));
  const ids = Array.isArray(g.yearBudgets) && g.yearBudgets.length ? g.yearBudgets : vis.map((x) => x.id);
  return ids.filter((id) => vis.some((x) => x.id === id));
}
// Graf po godinama s odabranim točkama: serija = { id, name, color, points: [{ id, budgetId, side, gid, iid }] }
// (stariji grafovi po godinama imaju serije zadane nazivom: { side, gname, iname })
export const isPointsGraph = (g) => g.xAxis === 'years' && g.series.some((s) => Array.isArray(s.points));
export const graphBudgetIds = (g) => (g.xAxis !== 'years' ? g.series.map((s) => s.budgetId)
  : isPointsGraph(g) ? g.series.flatMap((s) => (s.points || []).map((p) => p.budgetId)) : yearBudgetIds(g));
export const usesBudget = (g, id) => graphBudgetIds(g).includes(id);

// Učitavanje svih tablica potrebnih za graf
export async function loadBudgetsFor(graphs) {
  const ids = new Set(graphs.flatMap(graphBudgetIds));
  const map = new Map();
  for (const id of ids) {
    if (state.meta[id] && state.meta[id].hidden) continue;
    if (state.budget && state.budget.id === id) map.set(id, state.budget);
    else { const b = await readBudget(id); if (b) map.set(id, b); }
  }
  return map;
}

export function seriesLabel(s, map) {
  const b = map.get(s.budgetId);
  if (!b) return t('deletedBudget');
  const prefix = b.name + (String(b.name).includes(String(b.year)) ? '' : ' ' + b.year);
  if (s.side === 'diff') return prefix + ' · ' + t('difference');
  const side = t(s.side === 'income' ? 'income' : 'expenses');
  if (!s.gid) return prefix + ' · ' + side;
  const g = b[s.side].find((x) => x.id === s.gid);
  if (!g) return prefix + ' · ' + t('deleted');
  if (!s.iid) return prefix + ' · ' + g.name;
  const { it } = findItem(b, s.side, s.gid, s.iid);
  return prefix + ' · ' + g.name + ' › ' + (it ? it.name : t('deleted'));
}

function monthlyValues(s, b) {
  if (!b) return Array(12).fill(0);
  if (s.side === 'diff') { const P = calcSide(b, 'income').monthly, R = calcSide(b, 'expense').monthly; return P.map((x, i) => x - R[i]); }
  if (!s.gid) return calcSide(b, s.side).monthly;
  const g = b[s.side].find((x) => x.id === s.gid); if (!g) return Array(12).fill(0);
  if (!s.iid) return Array.from({ length: 12 }, (_, m) => g.items.reduce((a, it) => a + (it.vals[m] || 0), 0));
  const it = g.items.find((x) => x.id === s.iid);
  return it ? it.vals.map((v) => v || 0) : Array(12).fill(0);
}

// Graf po godinama: serija je zadana nazivom naslova/podnaslova pa se pronalazi u tablici svake godine
const norm = (x) => String(x || '').trim().toLowerCase();
function monthlyByName(s, b) {
  const zero = Array(12).fill(0);
  if (!b) return zero;
  if (s.side === 'diff') { const P = calcSide(b, 'income').monthly, R = calcSide(b, 'expense').monthly; return P.map((x, i) => x - R[i]); }
  if (!s.gname) return calcSide(b, s.side).monthly;
  const g = b[s.side].find((x) => norm(x.name) === norm(s.gname)); if (!g) return zero;
  if (!s.iname) return Array.from({ length: 12 }, (_, m) => g.items.reduce((a, it) => a + (it.vals[m] || 0), 0));
  const it = g.items.find((x) => norm(x.name) === norm(s.iname));
  return it ? it.vals.map((v) => v || 0) : zero;
}
// Naziv kategorije bez naziva tablice (za točke grafa po godinama)
export function catLabel(s, b) {
  if (!b) return t('deletedBudget');
  if (s.side === 'diff') return t('difference');
  if (!s.gid) return t(s.side === 'income' ? 'income' : 'expenses');
  const g = b[s.side].find((x) => x.id === s.gid);
  if (!g) return t('deleted');
  if (!s.iid) return g.name;
  const it = g.items.find((x) => x.id === s.iid);
  return it ? it.name : t('deleted');
}
export function pointSeriesLabel(s, map) {
  if (s.name) return s.name;
  const p = (s.points || [])[0];
  return p ? catLabel(p, map.get(p.budgetId)) : t('customGraph');
}
export function yearSeriesLabel(s) {
  if (s.side === 'diff') return t('difference');
  if (!s.gname) return t(s.side === 'income' ? 'income' : 'expenses');
  return s.iname ? s.gname + ' › ' + s.iname : s.gname;
}

export function computeGraph(graph, map, short = 3) {
  const months = graphMonths(graph);
  const sum = (a) => a.reduce((x, y) => x + y, 0);
  if (graph.xAxis === 'years' && isPointsGraph(graph)) {
    // X os = godine; svaka točka je zbroj odabranih mjeseci naslova/podnaslova iz odabrane tablice.
    // Točke iste linije se spajaju; godina bez točke ostaje prazna (linija je preskače).
    const yearOf = (p) => (map.get(p.budgetId) ? map.get(p.budgetId).year : null);
    const years = [...new Set(graph.series.flatMap((s) => (s.points || []).map(yearOf)).filter((y) => y !== null))].sort((a, b) => a - b);
    const labels = years.map(String);
    const series = graph.series.map((s, i) => {
      const values = years.map((y) => {
        const pts = (s.points || []).filter((p) => yearOf(p) === y);
        if (!pts.length) return null;
        return pts.reduce((a, p) => { const all = monthlyValues(p, map.get(p.budgetId)); return a + months.reduce((x, m) => x + all[m], 0); }, 0);
      });
      return { name: pointSeriesLabel(s, map), color: s.color || PALETTE[i % PALETTE.length], values, total: sum(values.map((v) => v || 0)) };
    });
    return { labels, rowLabels: labels, series, months, years, byYear: true };
  }
  if (graph.xAxis === 'years') {
    // stariji način: X os = godine; serija zadana nazivom (više tablica iste godine se zbraja)
    const ids = yearBudgetIds(graph).filter((id) => map.has(id));
    const years = [...new Set(ids.map((id) => map.get(id).year))].sort((a, b) => a - b);
    const labels = years.map(String);
    const series = graph.series.map((s, i) => {
      const values = years.map((y) => ids.filter((id) => map.get(id).year === y).reduce((a, id) => {
        const all = monthlyByName(s, map.get(id));
        return a + months.reduce((x, m) => x + all[m], 0);
      }, 0));
      return { name: yearSeriesLabel(s), color: s.color || PALETTE[i % PALETTE.length], values, total: sum(values) };
    });
    return { labels, rowLabels: labels, series, months, years, byYear: true };
  }
  const labels = months.map((m) => monthName(m, true).slice(0, short));
  const series = graph.series.map((s, i) => {
    const all = monthlyValues(s, map.get(s.budgetId));
    return { name: seriesLabel(s, map), color: s.color || PALETTE[i % PALETTE.length], values: months.map((m) => all[m]), total: months.reduce((a, m) => a + all[m], 0) };
  });
  return { labels, rowLabels: months.map((m) => monthName(m)), series, months };
}
// Pretvorba serija pri promjeni X osi (mjeseci ↔ godine).
// Mjeseci → godine: svaka serija postaje linija s točkom iz svoje tablice, a za ostale godine
// automatski se predlaže naslov istog naziva (korisnik može točku obrisati ili zamijeniti).
export function seriesToPoints(series, map) {
  const vis = state.index.filter((x) => !(state.meta[x.id] && state.meta[x.id].hidden)).map((x) => map.get(x.id)).filter(Boolean);
  return series.map((s) => {
    const b0 = map.get(s.budgetId);
    const pts = [{ id: uid('p'), budgetId: s.budgetId, side: s.side, gid: s.gid, iid: s.iid }];
    if (b0) {
      const g0 = s.gid && s.side !== 'diff' ? b0[s.side].find((x) => x.id === s.gid) : null;
      const i0 = g0 && s.iid ? g0.items.find((x) => x.id === s.iid) : null;
      const years = new Set([b0.year]);
      vis.forEach((b) => {
        if (years.has(b.year)) return;
        let gid = null, iid = null;
        if (g0) { const g = b[s.side].find((x) => norm(x.name) === norm(g0.name)); if (!g) return; gid = g.id; if (i0) { const it = g.items.find((x) => norm(x.name) === norm(i0.name)); if (!it) return; iid = it.id; } }
        years.add(b.year);
        pts.push({ id: uid('p'), budgetId: b.id, side: s.side, gid, iid });
      });
    }
    return { id: s.id, name: '', color: s.color, points: pts };
  });
}
// Stari graf po godinama (serije po nazivu) → točke iz tablica
export function namesToPoints(series, ids, map) {
  return series.map((s) => {
    const pts = [];
    const seen = new Set();
    ids.forEach((id) => {
      const b = map.get(id); if (!b || seen.has(b.year)) return;
      let gid = null, iid = null;
      if (s.gname && s.side !== 'diff') { const g = b[s.side].find((x) => norm(x.name) === norm(s.gname)); if (!g) return; gid = g.id; if (s.iname) { const it = g.items.find((x) => norm(x.name) === norm(s.iname)); if (!it) return; iid = it.id; } }
      seen.add(b.year);
      pts.push({ id: uid('p'), budgetId: id, side: s.side, gid, iid });
    });
    return { id: s.id, name: '', color: s.color, points: pts };
  });
}
// Godine → mjeseci: prva točka svake linije
export function pointsToSeries(series) {
  return series.filter((s) => (s.points || []).length).map((s) => ({ id: s.id, budgetId: s.points[0].budgetId, side: s.points[0].side, gid: s.points[0].gid, iid: s.points[0].iid, color: s.color }));
}
export function toPieParts(c) { return c.series.map((s) => ({ n: s.name, v: s.total, color: s.color })); }
export function toChartData(c, chart) {
  return chart === 'line'
    ? { labels: c.labels, series: [], lines: c.series.map((s) => ({ values: s.values, color: s.color })) }
    : { labels: c.labels, series: c.series.map((s) => ({ values: s.values, color: s.color })) };
}
