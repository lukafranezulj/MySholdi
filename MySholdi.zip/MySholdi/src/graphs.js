// Custom grafovi: proizvoljni naslovi/podnaslovi iz jedne ili više tablica (i različitih godina)
import { state } from './state.js';
import { t } from './i18n.js';
import { uid, monthName } from './util.js';
import { calcSide, findItem } from './model.js';
import { readBudget } from './storage.js';
import { PALETTE } from './charts.js';

export function newGraph(budgetId) {
  return { id: uid('cg'), name: t('customGraph'), chart: 'bar', months: [...Array(12).keys()], series: budgetId ? [{ id: uid('s'), budgetId, side: 'expense', gid: null, iid: null, color: PALETTE[0] }] : [] };
}

// Mjeseci koji se prikazuju: odabrani ili samo aktivni (trenutni) mjesec
export const curMonth = () => new Date().getMonth();
export function graphMonths(g) {
  if (g.monthMode === 'current') return [curMonth()];
  return (g.months && g.months.length ? g.months : [...Array(12).keys()]).slice().sort((a, b) => a - b);
}
// Graf po godinama: koje tablice ulaze (null/prazno = sve vidljive, pa se nove tablice dodaju same)
export function yearBudgetIds(g) {
  const vis = state.index.filter((x) => !(state.meta[x.id] && state.meta[x.id].hidden));
  const ids = Array.isArray(g.yearBudgets) && g.yearBudgets.length ? g.yearBudgets : vis.map((x) => x.id);
  return ids.filter((id) => vis.some((x) => x.id === id));
}
export const usesBudget = (g, id) => (g.xAxis === 'years' ? yearBudgetIds(g).includes(id) : g.series.some((s) => s.budgetId === id));

// Učitavanje svih tablica potrebnih za graf
export async function loadBudgetsFor(graphs) {
  const ids = new Set(graphs.flatMap((g) => (g.xAxis === 'years' ? yearBudgetIds(g) : g.series.map((s) => s.budgetId))));
  const map = new Map();
  for (const id of ids) {
    if (state.meta[id] && state.meta[id].hidden) continue;
    if (state.budget && state.budget.id === id) map.set(id, state.budget);
    else { const b = await readBudget(id); if (b) map.set(id, b); }
  }
  return map;
}

export function seriesLabel(s, map) {
  const b = map.get(s.budgetId);
  if (!b) return t('deletedBudget');
  const prefix = b.name + (String(b.name).includes(String(b.year)) ? '' : ' ' + b.year);
  if (s.side === 'diff') return prefix + ' · ' + t('difference');
  const side = t(s.side === 'income' ? 'income' : 'expenses');
  if (!s.gid) return prefix + ' · ' + side;
  const g = b[s.side].find((x) => x.id === s.gid);
  if (!g) return prefix + ' · ' + t('deleted');
  if (!s.iid) return prefix + ' · ' + g.name;
  const { it } = findItem(b, s.side, s.gid, s.iid);
  return prefix + ' · ' + g.name + ' › ' + (it ? it.name : t('deleted'));
}

function monthlyValues(s, b) {
  if (!b) return Array(12).fill(0);
  if (s.side === 'diff') { const P = calcSide(b, 'income').monthly, R = calcSide(b, 'expense').monthly; return P.map((x, i) => x - R[i]); }
  if (!s.gid) return calcSide(b, s.side).monthly;
  const g = b[s.side].find((x) => x.id === s.gid); if (!g) return Array(12).fill(0);
  if (!s.iid) return Array.from({ length: 12 }, (_, m) => g.items.reduce((a, it) => a + (it.vals[m] || 0), 0));
  const it = g.items.find((x) => x.id === s.iid);
  return it ? it.vals.map((v) => v || 0) : Array(12).fill(0);
}

// Graf po godinama: serija je zadana nazivom naslova/podnaslova pa se pronalazi u tablici svake godine
const norm = (x) => String(x || '').trim().toLowerCase();
function monthlyByName(s, b) {
  const zero = Array(12).fill(0);
  if (!b) return zero;
  if (s.side === 'diff') { const P = calcSide(b, 'income').monthly, R = calcSide(b, 'expense').monthly; return P.map((x, i) => x - R[i]); }
  if (!s.gname) return calcSide(b, s.side).monthly;
  const g = b[s.side].find((x) => norm(x.name) === norm(s.gname)); if (!g) return zero;
  if (!s.iname) return Array.from({ length: 12 }, (_, m) => g.items.reduce((a, it) => a + (it.vals[m] || 0), 0));
  const it = g.items.find((x) => norm(x.name) === norm(s.iname));
  return it ? it.vals.map((v) => v || 0) : zero;
}
export function yearSeriesLabel(s) {
  if (s.side === 'diff') return t('difference');
  if (!s.gname) return t(s.side === 'income' ? 'income' : 'expenses');
  return s.iname ? s.gname + ' › ' + s.iname : s.gname;
}

export function computeGraph(graph, map, short = 3) {
  const months = graphMonths(graph);
  const sum = (a) => a.reduce((x, y) => x + y, 0);
  if (graph.xAxis === 'years') {
    // X os = godine; Y = zbroj odabranih mjeseci te godine (više tablica iste godine se zbraja)
    const ids = yearBudgetIds(graph).filter((id) => map.has(id));
    const years = [...new Set(ids.map((id) => map.get(id).year))].sort((a, b) => a - b);
    const labels = years.map(String);
    const series = graph.series.map((s, i) => {
      const values = years.map((y) => ids.filter((id) => map.get(id).year === y).reduce((a, id) => {
        const all = monthlyByName(s, map.get(id));
        return a + months.reduce((x, m) => x + all[m], 0);
      }, 0));
      return { name: yearSeriesLabel(s), color: s.color || PALETTE[i % PALETTE.length], values, total: sum(values) };
    });
    return { labels, rowLabels: labels, series, months, years, byYear: true };
  }
  const labels = months.map((m) => monthName(m, true).slice(0, short));
  const series = graph.series.map((s, i) => {
    const all = monthlyValues(s, map.get(s.budgetId));
    return { name: seriesLabel(s, map), color: s.color || PALETTE[i % PALETTE.length], values: months.map((m) => all[m]), total: months.reduce((a, m) => a + all[m], 0) };
  });
  return { labels, rowLabels: months.map((m) => monthName(m)), series, months };
}
// Pretvorba serija pri promjeni X osi (mjeseci ↔ godine)
export function seriesToNames(series, map) {
  return series.map((s) => {
    const b = map.get(s.budgetId);
    const g = b && s.gid ? b[s.side === 'diff' ? 'expense' : s.side].find((x) => x.id === s.gid) : null;
    const it = g && s.iid ? g.items.find((x) => x.id === s.iid) : null;
    return { id: s.id, side: s.side, gname: g ? g.name : null, iname: it ? it.name : null, color: s.color };
  });
}
export function seriesToIds(series, b) {
  return series.map((s) => {
    const g = b && s.gname && s.side !== 'diff' ? b[s.side].find((x) => norm(x.name) === norm(s.gname)) : null;
    const it = g && s.iname ? g.items.find((x) => norm(x.name) === norm(s.iname)) : null;
    return { id: s.id, budgetId: b ? b.id : null, side: s.side, gid: g ? g.id : null, iid: it ? it.id : null, color: s.color };
  });
}
export function toPieParts(c) { return c.series.map((s) => ({ n: s.name, v: s.total, color: s.color })); }
export function toChartData(c, chart) {
  return chart === 'line'
    ? { labels: c.labels, series: [], lines: c.series.map((s) => ({ values: s.values, color: s.color })) }
    : { labels: c.labels, series: c.series.map((s) => ({ values: s.values, color: s.color })) };
}
