// Vlastiti server za spremanje i sinkronizaciju tablica (WebDAV).
// Radi s: Nextcloud / ownCloud, Synology i QNAP NAS (paket WebDAV Server), Apache/nginx WebDAV,
// rclone serve webdav, i s malim MojiSholdi serverom iz mape server/ ovog projekta.
// Veza na tablicu: uri = 'srv:<id servera>:<put do datoteke relativno na adresu servera>'
// Na Androidu zahtjevi idu preko nativnog HTTP-a (nema CORS ograničenja, rade i PROPFIND/MKCOL),
// u pregledniku preko fetch (server mora dopustiti CORS – MojiSholdi server to radi sam).
import { state } from './state.js';
import { isNative, nativeHttp } from './native.js';

export const SRV = 'srv:';
export const isSrv = (uri) => String(uri || '').startsWith(SRV);
export const serverById = (id) => (state.settings.servers || []).find((s) => s.id === id) || null;
export const srvUri = (serverId, path) => SRV + serverId + ':' + path.replace(/^\/+/, '');
export function parseSrvUri(uri) {
  const rest = String(uri).slice(SRV.length);
  const i = rest.indexOf(':');
  const id = rest.slice(0, i), path = rest.slice(i + 1);
  return { server: serverById(id), id, path };
}
// adresa servera uvijek završava s /
export const normUrl = (u) => { u = String(u || '').trim(); if (u && !/^https?:\/\//i.test(u)) u = 'http://' + u; return u.replace(/\/*$/, '/'); };
const encPath = (p) => String(p || '').split('/').filter(Boolean).map(encodeURIComponent).join('/');
export const joinUrl = (server, path, dir = false) => normUrl(server.url) + encPath(path) + (dir && path ? '/' : '');
const b64 = (s) => btoa(unescape(encodeURIComponent(s)));

// Greška s razlogom koji razumije dijagnostika: net | auth | notfound | conflict | http
export class SrvError extends Error {
  constructor(kind, status, msg) { super(msg || kind); this.kind = kind; this.status = status; }
}

async function request(server, method, url, { body = null, headers = {}, timeout = 20000 } = {}) {
  const h = { ...headers };
  if (server.user) h.Authorization = 'Basic ' + b64(server.user + ':' + (server.pass || ''));
  try {
    if (isNative) {
      const r = await nativeHttp({ url, method, headers: h, body, timeout });
      return { status: r.status, text: r.body || '', headers: r.headers || {} };
    }
    const ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const tm = ctl ? setTimeout(() => ctl.abort(), timeout) : null;
    const r = await fetch(url, { method, headers: h, body, cache: 'no-store', signal: ctl ? ctl.signal : undefined });
    if (tm) clearTimeout(tm);
    const out = { status: r.status, text: await r.text(), headers: {} };
    r.headers.forEach((v, k) => { out.headers[k.toLowerCase()] = v; });
    return out;
  } catch (e) {
    throw new SrvError('net', 0, String((e && e.message) || e));
  }
}
function check(r, okCodes) {
  if (okCodes.includes(r.status)) return r;
  if (r.status === 401 || r.status === 403) throw new SrvError('auth', r.status);
  if (r.status === 404) throw new SrvError('notfound', r.status);
  if (r.status === 409) throw new SrvError('conflict', r.status);
  throw new SrvError('http', r.status, 'HTTP ' + r.status);
}

// ---- datoteke ----
export async function srvRead(uri) {
  const { server, path } = parseSrvUri(uri);
  if (!server) throw new SrvError('noserver', 0);
  const r = check(await request(server, 'GET', joinUrl(server, path), { headers: { Accept: 'application/json, */*' } }), [200]);
  return r.text;
}
export async function srvWrite(uri, data) {
  const { server, path } = parseSrvUri(uri);
  if (!server) throw new SrvError('noserver', 0);
  const put = () => request(server, 'PUT', joinUrl(server, path), { body: data, headers: { 'Content-Type': 'application/json; charset=utf-8' } });
  let r = await put();
  if (r.status === 409 || r.status === 404) {
    // mapa ne postoji – napravi je pa pokušaj ponovo
    await srvMkdirs(server, path.split('/').slice(0, -1).join('/'));
    r = await put();
  }
  check(r, [200, 201, 204]);
  return { ok: true };
}
export async function srvExists(server, path) {
  const r = await request(server, 'PROPFIND', joinUrl(server, path), { body: PROPFIND_BODY, headers: { Depth: '0', 'Content-Type': 'application/xml; charset=utf-8' } });
  if (r.status === 404) return false;
  check(r, [200, 207]);
  return true;
}
export async function srvMkdirs(server, dir) {
  const parts = String(dir || '').split('/').filter(Boolean);
  let cur = '';
  for (const p of parts) {
    cur = cur ? cur + '/' + p : p;
    const r = await request(server, 'MKCOL', joinUrl(server, cur, true));
    // 201 napravljena, 405 već postoji
    if (![200, 201, 204, 301, 405].includes(r.status)) check(r, []);
  }
}

// ---- popis mape (PROPFIND, Depth 1) ----
const PROPFIND_BODY = '<?xml version="1.0" encoding="utf-8"?><d:propfind xmlns:d="DAV:"><d:prop><d:resourcetype/><d:getcontentlength/><d:getlastmodified/></d:prop></d:propfind>';
export async function srvList(server, dir) {
  const r = check(await request(server, 'PROPFIND', joinUrl(server, dir, true), { body: PROPFIND_BODY, headers: { Depth: '1', 'Content-Type': 'application/xml; charset=utf-8' } }), [200, 207]);
  const doc = new DOMParser().parseFromString(r.text, 'application/xml');
  const base = new URL(joinUrl(server, dir, true)).pathname.replace(/\/*$/, '/');
  const out = [];
  const byTag = (el, tag) => el.getElementsByTagNameNS('DAV:', tag);
  for (const resp of Array.from(byTag(doc, 'response'))) {
    const hrefEl = byTag(resp, 'href')[0]; if (!hrefEl) continue;
    let href = hrefEl.textContent.trim();
    try { href = new URL(href, joinUrl(server, '')).pathname; } catch (e) { }
    const isDir = byTag(resp, 'collection').length > 0 || href.endsWith('/');
    const clean = href.replace(/\/*$/, isDir ? '/' : '');
    if (decodeURIComponent(clean.replace(/\/$/, '')) === decodeURIComponent(base.replace(/\/$/, ''))) continue; // sama mapa
    const name = decodeURIComponent(clean.replace(/\/$/, '').split('/').pop());
    if (!name || name.startsWith('.')) continue;
    const size = byTag(resp, 'getcontentlength')[0];
    const mod = byTag(resp, 'getlastmodified')[0];
    out.push({ name, isDir, path: (dir ? dir.replace(/\/$/, '') + '/' : '') + name, size: size ? +size.textContent : 0, modified: mod ? Date.parse(mod.textContent) || 0 : 0 });
  }
  return out.sort((a, b) => (a.isDir !== b.isDir ? (a.isDir ? -1 : 1) : a.name.localeCompare(b.name)));
}

// ---- provjera veze (za obrazac servera i dijagnostiku) ----
export async function srvTest(server) {
  try {
    await srvList(server, '');
    return { ok: true };
  } catch (e) {
    return { ok: false, kind: e.kind || 'net', status: e.status || 0, msg: e.message };
  }
}
// Dijagnostika veze tablice: dostupnost servera, prijava, datoteka
export async function srvCheck(uri) {
  const { server, path } = parseSrvUri(uri);
  const res = { server: !!server, reachable: false, auth: false, exists: false, readable: false, error: '' };
  if (!server) return res;
  const dir = path.split('/').slice(0, -1).join('/');
  try { await srvList(server, dir); res.reachable = true; res.auth = true; }
  catch (e) {
    res.error = e.kind + (e.status ? ' ' + e.status : '');
    if (e.kind === 'auth') res.reachable = true;
    else if (e.kind === 'notfound') { res.reachable = true; res.auth = true; res.dirMissing = true; }
    return res;
  }
  try { await srvRead(uri); res.exists = true; res.readable = true; }
  catch (e) { res.error = e.kind + (e.status ? ' ' + e.status : ''); if (e.kind !== 'notfound') res.exists = true; }
  return res;
}
