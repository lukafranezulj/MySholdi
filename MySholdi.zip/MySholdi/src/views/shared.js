// Zajedničke proračunske tablice: više ljudi upisuje u istu tablicu spremljenu na Google Driveu / Dropboxu
import { state } from '../state.js';
import { t } from '../i18n.js';
import { esc, fmtDateTime } from '../util.js';
import { icon } from '../icons.js';
import { newBudget } from '../model.js';
import { writeBudget, saveSettings } from '../storage.js';
import { metaOf, pullRemote } from '../sync.js';
import { sheet, promptDlg, toast, infoSheet, infoBtn } from '../ui.js';
import { linkCreate, importFromFile } from '../cloud.js';
import { nameError, statusBadge } from './budgets.js';
import { shareText, openApp, isNative } from '../native.js';
import { app } from '../app.js';

export function renderShared() {
  const list = state.index.filter((x) => x.shared && !(state.meta[x.id] && state.meta[x.id].hidden)).sort((a, b) => b.updatedAt - a.updatedAt);
  return '<div class="intro-card card pad"><div class="intro-row">' + icon('users', 'accent') + '<div class="grow"><b>' + esc(t('sharedTitle')) + '</b><small>' + esc(t('sharedIntro')) + '</small></div>' + infoBtn('sharedInfo') + '</div></div>' +
    '<div class="list-actions"><button class="btn primary" data-a="sharedNew">' + icon('plus') + esc(t('sharedNew')) + '</button>' +
    '<button class="btn" data-a="sharedJoin">' + icon('download') + esc(t('sharedJoin')) + '</button></div>' +
    (state.settings.userName ? '<p class="muted small">' + esc(t('youAre', { n: state.settings.userName })) + ' <button class="link" data-a="sharedName">' + esc(t('change')) + '</button></p>' : '') +
    (list.length ? list.map((x) => {
      const m = metaOf(x.id);
      return '<div class="card budget-card ' + (state.settings.activeBudgetId === x.id ? 'active' : '') + '">' +
        '<div class="bc-main" data-a="openBudget" data-id="' + x.id + '"><div class="bc-ic shared">' + icon('users') + '</div><div><b>' + esc(x.name) + '</b>' +
        '<small>' + esc(t('year')) + ' ' + x.year + ' · ' + esc(t('updated')) + ' ' + esc(fmtDateTime(x.updatedAt)) + '</small>' + statusBadge(x.id) + '</div></div>' +
        '<div class="bc-side"><button class="icon-btn" data-a="sharedInvite" data-id="' + x.id + '" title="' + esc(t('invite')) + '">' + icon('userPlus') + '</button>' +
        (m.link ? '' : '<button class="icon-btn warn-ic" data-a="sharedLink" data-id="' + x.id + '">' + icon('cloudOff') + '</button>') +
        '<button class="icon-btn" data-a="sharedMenu" data-id="' + x.id + '">' + icon('more') + '</button></div></div>';
    }).join('') : '<div class="empty">' + icon('users', 'big') + '<p>' + esc(t('sharedEmpty')) + '</p></div>');
}

// Upute korak po korak (ikona "i")
export function sharedInfoHtml() {
  const steps = (k) => '<ol class="steps">' + t(k).split('|').map((s) => '<li>' + esc(s) + '</li>').join('') + '</ol>';
  return '<p>' + esc(t('sharedHow')) + '</p>' +
    '<h4>' + esc(t('sharedOwnerTitle')) + '</h4>' + steps('sharedOwnerSteps') +
    '<h4>' + esc(t('sharedMemberTitle')) + '</h4>' + steps('sharedMemberSteps') +
    '<h4>' + esc(t('sharedDropboxTitle')) + '</h4><p>' + esc(t('sharedDropbox')) + '</p>' +
    '<p class="muted small">' + esc(t('sharedNote')) + '</p>' +
    '<div class="w-btns"><button class="btn" data-open-app="drive">' + icon('cloud') + 'Google Drive</button><button class="btn" data-open-app="dropbox">' + icon('cloud') + 'Dropbox</button></div>';
}
export async function showSharedInfo() {
  const p = infoSheet(t('sharedInfoTitle'), sharedInfoHtml());
  setTimeout(() => document.querySelectorAll('[data-open-app]').forEach((b) => b.onclick = () => openCloudApp(b.dataset.openApp)), 50);
  return p;
}
async function openCloudApp(which) {
  const pkg = which === 'dropbox' ? 'com.dropbox.android' : 'com.google.android.apps.docs';
  const ok = await openApp(pkg, which === 'dropbox' ? 'https://www.dropbox.com/home' : 'https://drive.google.com/drive/my-drive');
  if (!ok) toast(t('appNotInstalled'));
}

export async function ensureUserName() {
  if (state.settings.userName) return true;
  const n = await promptDlg(t('yourName'), '', { label: t('yourNameHint') });
  if (n === null) return false;
  state.settings.userName = n; await saveSettings();
  return true;
}

async function createShared() {
  if (!(await ensureUserName())) return;
  const name = await promptDlg(t('sharedNew'), t('sharedDefaultName') + ' ' + new Date().getFullYear(), { label: t('budgetName'), validate: (s) => nameError(s) });
  if (name === null) return;
  const b = newBudget(name, new Date().getFullYear());
  b.shared = true;
  await writeBudget(b);
  await sheet({ title: t('sharedChooseLoc'), body: '<p class="dlg-text">' + esc(t('sharedChooseLocText')) + '</p>', actions: [{ label: t('ok'), value: true, cls: 'primary' }] });
  const linked = await linkCreate(b, { direct: isNative });
  await app.openBudget(b.id);
  if (linked) invite(b.id);
  else toast(t('sharedNotLinked'));
}

async function join() {
  if (!(await ensureUserName())) return;
  await sheet({ title: t('sharedJoin'), body: '<p class="dlg-text">' + esc(t('sharedJoinText')) + '</p>', actions: [{ label: t('ok'), value: true, cls: 'primary' }] });
  const b = await importFromFile({ shared: true });
  if (b) await app.openBudget(b.id);
}

// Poziv suradnicima: poruka s uputama (e-mail, WhatsApp…) + otvaranje Drivea za dodavanje e-mailova
export async function invite(id) {
  const x = state.index.find((i) => i.id === id); if (!x) return;
  const m = metaOf(id);
  const v = await sheet({
    title: t('invite'),
    body: '<p class="dlg-text">' + esc(t('inviteText', { f: m.link ? m.link.name : '—', p: m.link ? m.link.provider : 'Google Drive' })) + '</p>' +
      '<ol class="steps"><li>' + esc(t('inviteStep1', { p: m.link ? m.link.provider : 'Google Drive' })) + '</li><li>' + esc(t('inviteStep2')) + '</li><li>' + esc(t('inviteStep3')) + '</li></ol>',
    actions: [{ label: t('openDrive', { p: (m.link && m.link.provider === 'Dropbox') ? 'Dropbox' : 'Google Drive' }), value: 'drive' }, { label: t('sendInvite'), value: 'send', cls: 'primary' }],
  });
  if (v === 'drive') openCloudApp(m.link && m.link.provider === 'Dropbox' ? 'dropbox' : 'drive');
  if (v === 'send') {
    const msg = t('inviteMessage', { n: x.name, f: m.link ? m.link.name : '', p: m.link ? m.link.provider : 'Google Drive', u: state.settings.userName || '' });
    const ok = await shareText(t('inviteSubject', { n: x.name }), msg);
    if (!ok) toast(t('copied'));
  }
}

// Izbornik zajedničke tablice (⋯)
async function sharedMenu(id) {
  const x = state.index.find((i) => i.id === id); if (!x) return;
  const { readBudget, writeBudget, deleteBudgetFile, saveMeta } = await import('../storage.js');
  const b = state.budget && state.budget.id === id ? state.budget : await readBudget(id);
  const m = metaOf(id);
  const v = await sheet({
    title: x.name, body: '', cls: 'menu-sheet',
    actions: [
      { label: t('open'), value: 'open' }, { label: t('invite'), value: 'invite' },
      { label: t('exportCopy'), value: 'export' }, { label: t('copyToPersonal'), value: 'copy', cls: 'primary' },
      { label: m.link ? t('changeLocation') : t('linkCloud'), value: 'link' },
      { label: t('delete'), value: 'delete', cls: 'danger' },
    ],
  });
  if (v === 'open') return app.openBudget(id);
  if (v === 'invite') return invite(id);
  if (v === 'export') { const { exportBudget } = await import('../cloud.js'); return exportBudget(b); }
  if (v === 'link') { await linkCreate(b); return app.rerender(); }
  if (v === 'copy') {
    // kopija koja se NE dijeli: novi ID, bez veze na oblak
    const { uid, clone } = await import('../util.js');
    const c = clone(b); c.id = uid('b'); c.shared = false; c.rev = ''; c.updatedAt = Date.now();
    let name = b.name + ' (' + t('copyWord') + ')', n = 2;
    while (nameError(name)) name = b.name + ' (' + t('copyWord') + ' ' + n++ + ')';
    c.name = name;
    await writeBudget(c);
    toast(t('copiedToPersonal', { n: name }));
    return app.openBudget(c.id);
  }
  if (v === 'delete') {
    const { confirmDlg } = await import('../ui.js');
    const { toTrash } = await import('../trash.js');
    if (!(await confirmDlg(t('delSharedQ', { n: b.name }), { ok: t('delete'), danger: true }))) return;
    await toTrash('budget', b.name, b, { meta: m.link ? { link: m.link } : null });
    await deleteBudgetFile(id); delete state.meta[id]; await saveMeta();
    if (state.budget && state.budget.id === id) state.budget = null;
    if (state.settings.activeBudgetId === id) { state.settings.activeBudgetId = null; await saveSettings(); }
    toast(t('movedToTrash')); return app.rerender();
  }
}

export async function sharedAction(a, d) {
  if (a === 'sharedMenu') return sharedMenu(d.id);
  if (a === 'sharedNew') return createShared();
  if (a === 'sharedJoin') return join();
  if (a === 'sharedInfo') return showSharedInfo();
  if (a === 'sharedInvite') return invite(d.id);
  if (a === 'sharedName') { const n = await promptDlg(t('yourName'), state.settings.userName, { label: t('yourNameHint') }); if (n !== null) { state.settings.userName = n; await saveSettings(); app.rerender(); } return; }
  if (a === 'sharedLink') { const { readBudget } = await import('../storage.js'); const b = await readBudget(d.id); if (b) await linkCreate(b); return app.rerender(); }
  if (a === 'openBudget') return app.openBudget(d.id);
  void pullRemote; void isNative;
}
