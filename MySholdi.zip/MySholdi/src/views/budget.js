// Ekran proračunske tablice: Naslovna, Prihodi, Rashodi, Neto imovina, Sažetak
import { state } from '../state.js';
import { t, getLang } from '../i18n.js';
import { esc, money, fmtNum, monthName, fmtDateTime, parseAmount, sum, avgNZ, stdevNZ, counted, daysIn, round2, uid } from '../util.js';
import { icon } from '../icons.js';
import { calcSide, calcNet, addToCell, logEntry, findItem, itemLabel, markDeleted, nowTs } from '../model.js';
import { persist, syncStatus, metaOf } from '../sync.js';
import { sheet, confirmDlg, promptDlg, toast, infoSheet, infoBtn } from '../ui.js';
import { graphCard, mountGraphCards, graphAction, editGraph } from './graphs.js';
import { newGraph, usesBudget } from '../graphs.js';
import { showFullscreen, fsTable } from '../fullscreen.js';
import { pullRemote } from '../sync.js';
import { toTrash } from '../trash.js';
import { mountBarChart, mountDonut, mountPie, PALETTE, cssVar } from '../charts.js';
import { chartColor } from '../util.js';
import { saveSettings, saveMeta } from '../storage.js';
import { app } from '../app.js';

// Imovina je zadnja i prikazuje se samo ako je uključena u postavkama
const ALL_TABS = [['home', 'home', 'tabHome'], ['income', 'up', 'tabIncome'], ['expense', 'downArrow', 'tabExpense'], ['summary', 'chart', 'tabSummary'], ['net', 'coins', 'tabNet']];
export const visibleTabs = () => ALL_TABS.filter((x) => x[0] !== 'net' || state.settings.showNet);
let entriesShown = 30;

const B = () => state.budget;
const nowMonth = () => (B().year === new Date().getFullYear() ? new Date().getMonth() : state.ui.month);

// ---------- Okvir ekrana ----------
export function budgetActions() {
  const tab = state.ui.tab;
  let h = '';
  if (tab === 'income' || tab === 'expense') {
    const all = state.settings.allMonths[tab];
    h += '<button class="icon-btn" data-a="toggleMonths" title="' + esc(t(all ? 'showOneMonth' : 'showAllMonths')) + '">' + icon(all ? 'eye' : 'eyeOff') + '</button>';
  }
  if ((tab === 'income' || tab === 'expense' || tab === 'net') && !RO()) {
    const on = state.ui.edit[tab];
    h += '<button class="icon-btn ' + (on ? 'on' : '') + '" data-a="toggleEdit" title="' + esc(t('editTitles')) + '">' + icon(on ? 'check' : 'pencil') + '</button>';
  }
  if (tab === 'summary') h += '<button class="icon-btn" data-a="exportPrint" title="' + esc(t('printTitle')) + '">' + icon('printer') + '</button>';
  // lokot: zaključana tablica je samo za pregled (prikazuje se na naslovnoj, a kad je zaključano i na ostalim karticama)
  const locked = metaOf(B().id).readOnly;
  if (tab === 'home' || locked) h += '<button class="icon-btn lock-btn ' + (locked ? 'locked' : '') + '" data-a="toggleReadOnly" title="' + esc(t(locked ? 'tableLocked' : 'tableUnlocked')) + '">' + icon(locked ? 'lock' : 'unlock') + '</button>';
  return h;
}

// Može li se tablica mijenjati? (lokot ili zajednička tablica bez interneta)
export function readOnlyReason(b = B()) {
  if (metaOf(b.id).readOnly) return 'locked';
  if (b.shared && state.settings.sharedOfflineReadOnly && !state.online) return 'offline';
  return '';
}
const RO = () => !!readOnlyReason();

export function renderBudget() {
  if (state.ui.tab === 'net' && !state.settings.showNet) state.ui.tab = 'home';
  const tab = state.ui.tab;
  if (RO()) state.ui.edit = { income: false, expense: false, net: false };
  const body = { home: vHome, income: () => vSide('income'), expense: () => vSide('expense'), net: vNet, summary: vSummary }[tab]();
  return syncBanner() + '<div class="tab-body">' + body + '</div>' +
    (tab === 'home' && !RO() ? '<button class="fab" data-a="quickAdd" aria-label="' + esc(t('quickAdd')) + '">' + icon('plus') + '</button>' : '') +
    '<nav class="bottom-nav">' + visibleTabs().map(([k, ic, lbl]) =>
      '<button data-tab="' + k + '" class="' + (k === tab ? 'on' : '') + '">' + icon(ic) + '<span>' + esc(t(lbl)) + '</span></button>').join('') + '</nav>';
}

function syncBanner() {
  const st = syncStatus(B().id);
  const why = readOnlyReason();
  let h = '';
  if (why) h += '<div class="banner ro">' + icon('lock') + '<div><b>' + esc(t(why === 'locked' ? 'roTitle' : 'roOfflineTitle')) + '</b><small>' + esc(t(why === 'locked' ? 'roText' : 'roOfflineText')) + '</small></div></div>';
  if (st === 'offline') h += '<div class="banner offline">' + icon('cloudOff') + '<div><b>' + esc(t('offlineTitle')) + '</b><small>' + esc(t('offlineText')) + '</small></div></div>';
  if (st === 'failed') h += '<div class="banner warn">' + icon('cloudOff') + '<div><b>' + esc(t('syncFailTitle')) + '</b><small>' + esc(t('syncFailBanner')) + '</small></div>' +
    '<div class="banner-btns"><div class="bb-row"><button class="btn small" data-a="retrySync">' + esc(t('retry')) + '</button>' +
    '<button class="icon-btn sm" data-a="syncMenu" aria-label="' + esc(t('more')) + '">' + icon('more') + '</button></div>' +
    '<button class="icon-btn sm info-btn" data-a="syncInfo" aria-label="info">' + icon('info') + '</button></div></div>';
  return h;
}

// ---------- NASLOVNA ----------
function vHome() {
  const b = B();
  const m = state.ui.month;
  const inc = calcSide(b, 'income').monthly[m], exp = calcSide(b, 'expense').monthly[m];
  const diff = inc - exp;
  const pct = inc ? Math.min(100, exp / inc * 100) : (exp ? 100 : 0);
  const list = sortedEntries(b).slice(0, entriesShown);
  const members = [...new Set(b.entries.map((e) => e.by).filter(Boolean))];
  const top = (b.example ? '<div class="banner info">' + icon('info') + '<div><b>' + esc(t('exampleTitle')) + '</b><small>' + esc(t('exampleText')) + '</small></div></div>' : '') +
    (b.shared ? '<div class="banner shared">' + icon('users') + '<div><b>' + esc(t('sharedBadge')) + '</b><small>' + esc(members.length ? t('membersList', { n: members.join(', ') }) : t('sharedNoMembers')) + '</small></div>' +
      '<button class="icon-btn sm" data-a="sharedRefresh" title="' + esc(t('refresh')) + '">' + icon('restore') + '</button><button class="icon-btn sm" data-a="sharedInvite" title="' + esc(t('invite')) + '">' + icon('userPlus') + '</button></div>' : '');
  return top + '<div class="home-grid"><div class="home-left"><section class="hero">' +
    '<div class="hero-top"><button class="icon-btn light" data-a="month" data-d="-1">' + icon('left') + '</button>' +
    '<div class="hero-month">' + esc(monthName(m)) + ' ' + b.year + '</div>' +
    '<button class="icon-btn light" data-a="month" data-d="1">' + icon('right') + '</button></div>' +
    '<div class="hero-diff ' + (diff < 0 ? 'neg' : '') + '">' + money(diff, { sign: true }) + '</div><div class="hero-sub">' + esc(t('balanceMonth')) + '</div>' +
    '<div class="hero-row"><div><span>' + icon('up') + esc(t('income')) + '</span><b>' + money(inc) + '</b></div>' +
    '<div><span>' + icon('downArrow') + esc(t('expenses')) + '</span><b>' + money(exp) + '</b></div></div>' +
    '<div class="hero-bar"><i style="width:' + pct + '%"></i></div><div class="hero-sub">' + esc(t('spentOfIncome', { p: fmtNum(inc ? exp / inc * 100 : 0, 0) })) + '</div>' +
    '</section></div><div class="home-right">' +
    '<div class="sec-row entries-head"><h4 class="sec-title">' + esc(t('recentEntries')) + '</h4>' +
    '<select class="fld sm sort-sel" data-sort>' + SORTS.map((k) => '<option value="' + k + '"' + (sortMode() === k ? ' selected' : '') + '>' + esc(t('sort_' + k)) + '</option>').join('') + '</select></div>' +
    (list.length ? '<div class="card list">' + entriesHtml(list) + '</div>' +
      (b.entries.length > entriesShown ? '<button class="btn ghost block" data-a="moreEntries">' + esc(t('showMore')) + '</button>' : '')
      : '<div class="empty">' + icon('plus', 'big') + '<p>' + esc(t('noEntries')) + '</p></div>') +
    '</div></div><div class="fab-space"></div>';
}
// Razvrstavanje zadnjih unosa: po mjesecima (zadano, s razdjelnicima), po vremenu unosa, po iznosu
const SORTS = ['month', 'time', 'amountDesc', 'amountAsc'];
const sortMode = () => (SORTS.includes(state.settings.entriesSort) ? state.settings.entriesSort : 'month');
function sortedEntries(b) {
  const l = [...b.entries];
  const mode = sortMode();
  if (mode === 'month') l.sort((a, c) => c.month - a.month || c.ts - a.ts);
  else if (mode === 'time') l.sort((a, c) => c.ts - a.ts);
  else if (mode === 'amountDesc') l.sort((a, c) => Math.abs(c.amount) - Math.abs(a.amount));
  else l.sort((a, c) => Math.abs(a.amount) - Math.abs(c.amount));
  return l;
}
function entriesHtml(list) {
  if (sortMode() !== 'month') return list.map(entryRow).join('');
  let cur = -1, h = '';
  const b = B();
  list.forEach((e) => {
    if (e.month !== cur) {
      cur = e.month;
      const sum = b.entries.filter((x) => x.month === cur).reduce((a, x) => a + (x.type === 'income' ? x.amount : -x.amount), 0);
      h += '<div class="month-sep"><span>' + esc(monthName(cur)) + ' ' + b.year + '</span><b class="' + (sum < 0 ? 'neg' : 'pos') + '">' + money(sum, { sign: true }) + '</b></div>';
    }
    h += entryRow(e);
  });
  return h;
}
function entryRow(e) {
  const b = B();
  const full = itemLabel(b, e.type, e.gid, e.iid);
  const parts = (full || e.label || '').split(' › ');
  const name = parts.length > 1 ? parts.slice(1).join(' › ') : parts[0];
  const group = parts.length > 1 ? parts[0] : '';
  const d = new Date(e.ts);
  const mn = monthName(e.month);
  const monthTag = t('forMonth', { m: getLang() === 'hr' ? mn.toLowerCase() : mn });   // mjesec za koji je iznos upisan
  const isInc = e.type === 'income';
  const meta = [b.shared && e.by ? '👤 ' + e.by : '', group + (full ? '' : ' (' + t('deleted') + ')'), fmtDateTime(e.ts), monthTag, e.src === 'table' ? t('fromTable') : '', e.editedAt ? t('edited') : '', e.note].filter(Boolean).join(' · ');
  return '<div class="entry">' +
    '<div class="entry-ic ' + (isInc ? 'inc' : 'exp') + '">' + icon(isInc ? 'up' : 'downArrow') + '</div>' +
    '<div class="entry-main"><div class="entry-top"><b>' + esc(name) + '</b><span class="entry-amt ' + (isInc ? 'inc' : 'exp') + '">' + money(isInc ? e.amount : -e.amount, { sign: true }) + '</span></div>' +
    '<small>' + esc(meta) + '</small></div>' +
    (RO() ? '' : '<button class="icon-btn sm" data-a="editEntry" data-id="' + e.id + '" aria-label="' + esc(t('editEntry')) + '">' + icon('pencil') + '</button>' +
    '<button class="icon-btn sm" data-a="delEntry" data-id="' + e.id + '" aria-label="' + esc(t('delete')) + '">' + icon('trash') + '</button>') + '</div>';
}
// Brzi unos (+) i uređivanje zapisa
export async function quickAdd(preset = {}) {
  const b = B();
  const last = state.settings.lastPick || {};
  let type = preset.type || last.type || 'expense';
  const form = (tp) => {
    const sel = preset.iid ? preset.gid + '|' + preset.iid : (last[tp] || '');
    return b[tp].map((g) => '<optgroup label="' + esc(g.name) + '">' + g.items.map((it) =>
      '<option value="' + g.id + '|' + it.id + '"' + (sel === g.id + '|' + it.id ? ' selected' : '') + '>' + esc(it.name || '—') + '</option>').join('') + '</optgroup>').join('');
  };
  const month = preset.month ?? nowMonth();
  const editing = !!preset.entryId;
  const res = await sheet({
    title: editing ? t('editEntry') : t('quickAdd'),
    body:
      '<div class="seg" id="qa-type"><button data-v="expense" class="' + (type === 'expense' ? 'on exp' : '') + '">' + esc(t('expense')) + '</button>' +
      '<button data-v="income" class="' + (type === 'income' ? 'on inc' : '') + '">' + esc(t('incomeOne')) + '</button></div>' +
      '<label class="fld-label">' + esc(t('amount')) + '</label>' +
      '<div class="amount-in"><input id="qa-amt" class="fld big" inputmode="decimal" placeholder="0,00" value="' + (preset.amount !== undefined ? esc(String(preset.amount)) : '') + '"><span>' + esc(state.settings.currency) + '</span></div>' +
      '<div class="fld-err" id="qa-err"></div>' +
      '<label class="fld-label">' + esc(t('category')) + '</label><select id="qa-cat" class="fld">' + form(type) + '</select>' +
      '<div class="row2"><div><label class="fld-label">' + esc(t('month')) + '</label><select id="qa-month" class="fld">' +
      Array.from({ length: 12 }, (_, i) => '<option value="' + i + '"' + (i === month ? ' selected' : '') + '>' + esc(monthName(i)) + '</option>').join('') + '</select></div>' +
      '<div><label class="fld-label">' + esc(t('note')) + '</label><input id="qa-note" class="fld" value="' + esc(preset.note || '') + '" placeholder="' + esc(t('optional')) + '"></div></div>',
    actions: [{ label: t('cancel'), value: null }, { label: editing ? t('save') : t('add'), value: 'ok', cls: 'primary' }],
    onMount: (el) => {
      el.querySelector('#qa-type').onclick = (e) => {
        const btn = e.target.closest('button'); if (!btn) return;
        type = btn.dataset.v;
        el.querySelectorAll('#qa-type button').forEach((x) => { x.className = x.dataset.v === type ? 'on ' + (type === 'income' ? 'inc' : 'exp') : ''; });
        el.querySelector('#qa-cat').innerHTML = form(type);
      };
      setTimeout(() => el.querySelector('#qa-amt').focus(), 250);
    },
    onAction: (v, el) => {
      if (v !== 'ok') return null;
      const amt = parseAmount(el.querySelector('#qa-amt').value);
      if (amt === null || isNaN(amt) || amt === 0) { el.querySelector('#qa-err').textContent = t('errAmount'); return false; }
      const [gid, iid] = el.querySelector('#qa-cat').value.split('|');
      if (!iid) { el.querySelector('#qa-err').textContent = t('errCategory'); return false; }
      return { type, amount: amt, gid, iid, month: +el.querySelector('#qa-month').value, note: el.querySelector('#qa-note').value.trim() };
    },
  });
  if (!res) return null;
  state.settings.lastPick = { ...(state.settings.lastPick || {}), type: res.type, [res.type]: res.gid + '|' + res.iid };
  saveSettings();
  return res;
}

export async function addNew(preset = {}) {
  const r = await quickAdd(preset);
  if (!r) return;
  const b = B();
  addToCell(b, r.type, r.gid, r.iid, r.month, r.amount);
  logEntry(b, { ...r, src: 'quick' });
  persist(b);
  toast(t('added', { a: money(r.amount), c: itemLabel(b, r.type, r.gid, r.iid) }));
  app.rerender();
}
async function editEntry(id) {
  const b = B();
  const e = b.entries.find((x) => x.id === id); if (!e) return;
  if (!findItem(b, e.type, e.gid, e.iid).it) { toast(t('entryItemGone')); return; }
  const r = await quickAdd({ entryId: id, type: e.type, gid: e.gid, iid: e.iid, month: e.month, amount: e.amount, note: e.note });
  if (!r) return;
  addToCell(b, e.type, e.gid, e.iid, e.month, -e.amount);   // poništi stari iznos
  addToCell(b, r.type, r.gid, r.iid, r.month, r.amount);    // dodaj novi
  Object.assign(e, { type: r.type, gid: r.gid, iid: r.iid, month: r.month, amount: round2(r.amount), note: r.note, editedAt: Date.now() });
  e.label = itemLabel(b, e.type, e.gid, e.iid) || e.label;
  persist(b); app.rerender();
}
async function delEntry(id) {
  const b = B();
  const e = b.entries.find((x) => x.id === id); if (!e) return;
  const label = itemLabel(b, e.type, e.gid, e.iid) || e.label;
  if (!(await confirmDlg(t('delEntryQ', { a: money(e.amount), c: label }), { ok: t('delete'), danger: true }))) return;
  addToCell(b, e.type, e.gid, e.iid, e.month, -e.amount);   // oduzmi od kategorije
  b.entries = b.entries.filter((x) => x.id !== id);
  markDeleted(b, id);
  const tr = await toTrash('entry', money(e.amount) + ' · ' + label, e, { budgetId: b.id });
  persist(b); app.rerender();
  toast(t('movedToTrash'), { action: t('undo'), onAction: async () => { const { restore } = await import('../trash.js'); await restore(tr.id); app.rerender(); } });
}

// ---------- PRIHODI / RASHODI ----------
function vSide(type) {
  const b = B();
  const C = calcSide(b, type);
  const all = state.settings.allMonths[type];
  const editing = state.ui.edit[type];
  const m = state.ui.month;
  const kpis = '<div class="kpis">' +
    '<div class="kpi ' + (type === 'income' ? 'inc' : 'exp') + '"><span>' + esc(t('yearTotal')) + '</span><b>' + money(C.total) + '</b></div>' +
    '<div class="kpi"><span>' + esc(t('avgMonthly')) + '</span><b>' + money(C.avgMonthly) + '</b></div>' +
    '<div class="kpi"><span>' + esc(t('avgDaily')) + '</span><b>' + money(C.avgDaily) + '</b></div></div>';
  const head = editing ? '<div class="edit-hint">' + icon('pencil') + esc(t('editModeHint')) + '</div>' : '';
  if (all) return kpis + head + gridAll(type, C, editing) + '<div class="fab-space"></div>';
  return '<div class="month-switch"><button class="icon-btn" data-a="month" data-d="-1">' + icon('left') + '</button><b>' + esc(monthName(m)) + ' ' + b.year + '</b>' +
    '<button class="icon-btn" data-a="month" data-d="1">' + icon('right') + '</button></div>' +
    '<div class="month-total ' + (type === 'income' ? 'inc' : 'exp') + '"><span>' + esc(t(type === 'income' ? 'incomeIn' : 'expensesIn', { m: monthName(m) })) + '</span><b>' + money(C.monthly[m]) + '</b>' +
    '<small>' + esc(t('dailyAvg')) + ' ' + money(C.daily[m]) + '</small>' +
    '<button class="icon-btn" data-a="chartSide" data-type="' + type + '">' + icon('chart') + '</button></div>' +
    head + '<div class="groups-grid">' + b[type].map((g, gi) => groupCard(type, g, C.groups[gi], m, editing)).join('') + '</div>' +
    (editing ? '<button class="btn dashed block" data-a="addGroup" data-type="' + type + '">' + icon('plus') + esc(t('addTitle')) + '</button>' : '') +
    kpis + '<div class="fab-space"></div>';
}
function groupCard(type, g, cg, m, editing) {
  return '<div class="card group">' +
    '<div class="group-head">' +
    (editing ? '<button class="icon-btn sm" data-a="renGroup" data-type="' + type + '" data-g="' + g.id + '">' + icon('pencil') + '</button>' : '') +
    '<b class="grow" data-a="chartGroup" data-type="' + type + '" data-g="' + g.id + '">' + esc(g.name) + '</b>' +
    '<span class="gval">' + money(cg.m[m]) + '</span>' +
    (editing ? '<button class="icon-btn sm" data-a="delGroup" data-type="' + type + '" data-g="' + g.id + '">' + icon('trash') + '</button>'
      : '<button class="icon-btn sm" data-a="chartGroup" data-type="' + type + '" data-g="' + g.id + '">' + icon('chart') + '</button>') +
    '</div>' +
    g.items.map((it) => '<div class="item">' +
      (editing ? '<button class="icon-btn sm" data-a="renItem" data-type="' + type + '" data-g="' + g.id + '" data-i="' + it.id + '">' + icon('pencil') + '</button>' : '') +
      '<span class="grow" data-a="chartItem" data-type="' + type + '" data-g="' + g.id + '" data-i="' + it.id + '">' + esc(it.name || '—') + '</span>' +
      (editing ? '<button class="icon-btn sm" data-a="delItem" data-type="' + type + '" data-g="' + g.id + '" data-i="' + it.id + '">' + icon('trash') + '</button>'
        : RO() ? '<span class="val-ro">' + (it.vals[m] ? money(it.vals[m]) : '') + '</span>'
        : '<button class="val-btn ' + (it.vals[m] ? '' : 'zero') + '" data-a="editCell" data-type="' + type + '" data-g="' + g.id + '" data-i="' + it.id + '" data-m="' + m + '">' + (it.vals[m] ? money(it.vals[m]) : '+') + '</button>') +
      '</div>').join('') +
    (editing ? '<button class="btn ghost small add-sub" data-a="addItem" data-type="' + type + '" data-g="' + g.id + '">' + icon('plus') + esc(t('addSubtitle')) + '</button>' : '') +
    '</div>';
}
// Prikaz svih mjeseci (tablica kao u Excelu)
function gridAll(type, C, editing) {
  const b = B();
  let h = '<div class="scroll card"><table class="grid"><thead><tr><th class="sticky">' + esc(t(type === 'income' ? 'income' : 'expenses')) + '</th>' +
    Array.from({ length: 12 }, (_, i) => '<th>' + esc(monthName(i, true)) + '</th>').join('') + '<th>' + esc(t('total')) + '</th><th>' + esc(t('avgShort')) + '</th></tr></thead><tbody>';
  b[type].forEach((g, gi) => {
    const cg = C.groups[gi];
    h += '<tr class="grp"><td class="sticky"><div class="cellname">' +
      (editing ? '<button class="icon-btn xs" data-a="renGroup" data-type="' + type + '" data-g="' + g.id + '">' + icon('pencil') + '</button>' : '') +
      '<span data-a="chartGroup" data-type="' + type + '" data-g="' + g.id + '">' + esc(g.name) + '</span>' +
      (editing ? '<button class="icon-btn xs" data-a="delGroup" data-type="' + type + '" data-g="' + g.id + '">' + icon('trash') + '</button>' : '') + '</div></td>' +
      cg.m.map((x) => '<td>' + (x ? fmtNum(x) : '') + '</td>').join('') + '<td>' + fmtNum(cg.total) + '</td><td>' + fmtNum(cg.avg) + '</td></tr>';
    g.items.forEach((it, ii) => {
      const r = cg.rows[ii];
      h += '<tr><td class="sticky"><div class="cellname">' +
        (editing ? '<button class="icon-btn xs" data-a="renItem" data-type="' + type + '" data-g="' + g.id + '" data-i="' + it.id + '">' + icon('pencil') + '</button>' : '') +
        '<span data-a="chartItem" data-type="' + type + '" data-g="' + g.id + '" data-i="' + it.id + '">' + esc(it.name || '—') + '</span>' +
        (editing ? '<button class="icon-btn xs" data-a="delItem" data-type="' + type + '" data-g="' + g.id + '" data-i="' + it.id + '">' + icon('trash') + '</button>' : '') + '</div></td>' +
        it.vals.map((v, mi) => '<td><input class="cell" inputmode="decimal"' + (RO() ? ' readonly' : '') + ' data-cell="' + type + '|' + g.id + '|' + it.id + '|' + mi + '" value="' + (v === null ? '' : esc(fmtNum(v))) + '"></td>').join('') +
        '<td class="calc">' + (r.total ? fmtNum(r.total) : '') + '</td><td class="calc">' + (r.avg ? fmtNum(r.avg) : '') + '</td></tr>';
    });
    if (editing) h += '<tr class="addrow"><td class="sticky"><button class="btn ghost small" data-a="addItem" data-type="' + type + '" data-g="' + g.id + '">' + icon('plus') + esc(t('addSubtitle')) + '</button></td><td colspan="14"></td></tr>';
  });
  if (editing) h += '<tr class="addrow"><td class="sticky"><button class="btn ghost small" data-a="addGroup" data-type="' + type + '">' + icon('plus') + esc(t('addTitle')) + '</button></td><td colspan="14"></td></tr>';
  h += '<tr class="tot"><td class="sticky">' + esc(t('monthlyTotal')) + '</td>' + C.monthly.map((x) => '<td>' + fmtNum(x) + '</td>').join('') + '<td>' + fmtNum(C.total) + '</td><td>' + fmtNum(C.avgMonthly) + '</td></tr>';
  h += '<tr class="tot2"><td class="sticky">' + esc(t('avgDaily')) + '</td>' + C.daily.map((x) => '<td>' + fmtNum(x) + '</td>').join('') + '<td></td><td>' + fmtNum(C.avgDaily) + '</td></tr>';
  return h + '</tbody></table></div>';
}

// Postavljanje vrijednosti ćelije – razlika se bilježi u zapisima
function setCell(type, gid, iid, m, newVal) {
  const b = B();
  const { it } = findItem(b, type, gid, iid); if (!it) return;
  const old = it.vals[m] || 0;
  const nv = newVal === null ? 0 : round2(newVal);
  const delta = round2(nv - old);
  it.vals[m] = newVal === null ? null : nv;
  if (delta !== 0) logEntry(b, { type, gid, iid, month: m, amount: delta, src: 'table' });
  persist(b);
}
async function editCell(type, gid, iid, m) {
  const b = B();
  const { g, it } = findItem(b, type, gid, iid); if (!it) return;
  let mode = 'add';
  const r = await sheet({
    title: it.name + ' · ' + monthName(m),
    body: '<p class="muted">' + esc(g.name) + ' · ' + esc(t('currentValue')) + ': <b>' + money(it.vals[m] || 0) + '</b></p>' +
      '<div class="seg" id="ce-mode"><button data-v="add" class="on">' + esc(t('addAmount')) + '</button><button data-v="set">' + esc(t('setAmount')) + '</button></div>' +
      '<div class="amount-in"><input id="ce-amt" class="fld big" inputmode="decimal" placeholder="0,00"><span>' + esc(state.settings.currency) + '</span></div>' +
      '<div class="fld-err" id="ce-err"></div><p class="muted small">' + esc(t('exprHint')) + '</p>',
    actions: [{ label: t('cancel'), value: null }, { label: t('save'), value: 'ok', cls: 'primary' }],
    onMount: (el) => {
      el.querySelector('#ce-mode').onclick = (e) => {
        const btn = e.target.closest('button'); if (!btn) return;
        mode = btn.dataset.v;
        el.querySelectorAll('#ce-mode button').forEach((x) => x.classList.toggle('on', x.dataset.v === mode));
        const inp = el.querySelector('#ce-amt');
        inp.value = mode === 'set' && it.vals[m] ? String(it.vals[m]) : '';
        inp.focus();
      };
      setTimeout(() => el.querySelector('#ce-amt').focus(), 250);
    },
    onAction: (v, el) => {
      if (v !== 'ok') return null;
      const raw = el.querySelector('#ce-amt').value;
      const a = parseAmount(raw);
      if (mode === 'set' && a === null) return { set: null };
      if (a === null || isNaN(a)) { el.querySelector('#ce-err').textContent = t('errAmount'); return false; }
      return mode === 'set' ? { set: a } : { add: a };
    },
  });
  if (!r) return;
  if ('add' in r) {
    addToCell(b, type, gid, iid, m, r.add);
    logEntry(b, { type, gid, iid, month: m, amount: r.add, src: 'table' });
    persist(b);
  } else setCell(type, gid, iid, m, r.set);
  app.rerender();
}

// ----- Uređivanje naslova i podnaslova -----
async function renGroup(type, gid) {
  const g = B()[type].find((x) => x.id === gid);
  const n = await promptDlg(t('renameTitle'), g.name, { label: t('titleName') });
  if (n === null) return;
  g.name = n; g.nameTs = nowTs(); persist(); app.rerender();
}
async function renItem(type, gid, iid) {
  const { it } = findItem(B(), type, gid, iid);
  const n = await promptDlg(t('renameSubtitle'), it.name, { label: t('subtitleName') });
  if (n === null) return;
  it.name = n; it.nameTs = nowTs(); persist(); app.rerender();
}
async function addGroup(type) {
  const n = await promptDlg(t('addTitle'), '', { label: t('titleName') });
  if (n === null) return;
  const s = await promptDlg(t('addSubtitle'), '', { label: t('firstSubtitle') });
  B()[type].push({ id: uid('g'), name: n, items: s ? [{ id: uid('i'), name: s, vals: Array(12).fill(null) }] : [] });
  persist(); app.rerender();
}
async function addItem(type, gid) {
  const g = B()[type].find((x) => x.id === gid);
  const n = await promptDlg(t('addSubtitle'), '', { label: t('subtitleName') + ' (' + g.name + ')' });
  if (n === null) return;
  g.items.push({ id: uid('i'), name: n, vals: Array(12).fill(null) });
  persist(); app.rerender();
}
async function delGroup(type, gid) {
  const b = B();
  const idx = b[type].findIndex((x) => x.id === gid); const g = b[type][idx];
  if (!(await confirmDlg(t('delTitleQ', { n: g.name }), { ok: t('delete'), danger: true }))) return;
  b[type].splice(idx, 1);
  markDeleted(b, g.id);
  const tr = await toTrash('group', g.name, g, { budgetId: b.id, type, index: idx });
  persist(); app.rerender();
  toast(t('movedToTrash'), { action: t('undo'), onAction: async () => { const { restore } = await import('../trash.js'); await restore(tr.id); app.rerender(); } });
}
async function delItem(type, gid, iid) {
  const b = B();
  const g = b[type].find((x) => x.id === gid);
  const idx = g.items.findIndex((x) => x.id === iid); const it = g.items[idx];
  if (!(await confirmDlg(t('delSubtitleQ', { n: it.name }), { ok: t('delete'), danger: true }))) return;
  g.items.splice(idx, 1);
  markDeleted(b, it.id);
  const tr = await toTrash('item', g.name + ' › ' + it.name, it, { budgetId: b.id, type, gid, index: idx });
  persist(); app.rerender();
  toast(t('movedToTrash'), { action: t('undo'), onAction: async () => { const { restore } = await import('../trash.js'); await restore(tr.id); app.rerender(); } });
}

// Graf sažetka (prihodi, rashodi, razlika po mjesecima) preko cijelog zaslona, s tablicom podataka
async function summaryFullscreen() {
  const b = B();
  const P = calcSide(b, 'income').monthly, R = calcSide(b, 'expense').monthly, D = P.map((x, i) => x - R[i]);
  const fmt = (v) => money(v, { dec: 0 });
  const cols = [{ name: t('income'), color: chartColor('income') }, { name: t('expenses'), color: chartColor('expense') }, { name: t('difference'), color: chartColor('diff') }];
  await showFullscreen({
    title: t('tabSummary') + ' ' + b.year, fmt,
    bars: { labels: Array.from({ length: 12 }, (_, i) => monthName(i, true).slice(0, 3)), series: [{ values: P, color: chartColor('income') }, { values: R, color: chartColor('expense') }], line: { values: P.map((x, i) => (x || R[i] ? D[i] : null)), color: chartColor('diff') } },
    legendHtml: cols.map((c, i) => '<span><i style="background:' + c.color + '"></i>' + esc(c.name) + ' <b>' + fmt(sum([P, R, D][i])) + '</b></span>').join(''),
    tableHtml: fsTable(cols, Array.from({ length: 12 }, (_, i) => ({ label: monthName(i), values: [P[i], R[i], D[i]] })), [sum(P), sum(R), sum(D)], fmt),
  });
}

// ---------- Grafikoni naslova / podnaslova ----------
let sheetKind = 'bar';
export async function chartSheet(type, gid, iid) {
  const b = B();
  const C = calcSide(b, type);
  const col = chartColor(type === 'income' ? 'income' : 'expense');
  let title, values, parts = null;
  if (!gid) { title = t(type === 'income' ? 'income' : 'expenses'); values = C.monthly; parts = b[type].map((g, i) => ({ n: g.name, v: C.groups[i].total, gid: g.id })); }
  else if (!iid) {
    const gi = b[type].findIndex((g) => g.id === gid); const g = b[type][gi];
    title = g.name; values = C.groups[gi].m; parts = g.items.map((it, i) => ({ n: it.name, v: C.groups[gi].rows[i].total, gid, iid: it.id }));
  } else { const { g, it } = findItem(b, type, gid, iid); title = g.name + ' › ' + it.name; values = it.vals.map((v) => v || 0); }
  const nz = values.filter((x) => x);
  const maxI = values.indexOf(Math.max(...values)), stats = [
    [t('yearTotal'), money(sum(values))], [t('avgMonthly'), money(avgNZ(values))],
    [t('maxMonth'), nz.length ? money(values[maxI]) + ' · ' + monthName(maxI, true) : '—'],
    [t('minMonth'), nz.length ? money(Math.min(...nz)) + ' · ' + monthName(values.indexOf(Math.min(...nz)), true) : '—'],
  ];
  const share = gid ? C.total : 0;
  parts = parts && parts.filter((p) => p.v > 0).sort((a, c) => c.v - a.v);
  // za pie: raspodjela po kategorijama ili (za podnaslov) po mjesecima
  const pieParts = (parts && parts.length ? parts : values.map((v, i) => ({ n: monthName(i), v })).filter((p) => p.v > 0)).map((p, i) => ({ ...p, color: PALETTE[i % PALETTE.length] }));
  await sheet({
    title, wide: true,
    body: '<div class="chart-head"><div class="seg sm three grow" id="cs-kind">' + [['bar', 'barChart'], ['line', 'lineChart'], ['pie', 'pieChart']].map(([k, l]) => '<button data-v="' + k + '" class="' + (sheetKind === k ? 'on' : '') + '">' + esc(t(l)) + '</button>').join('') + '</div>' +
      '<button class="icon-btn sm" id="cs-fs" title="' + esc(t('fullscreen')) + '">' + icon('expand') + '</button></div>' +
      '<div class="chart-wrap" id="cs-main"><canvas id="cs-bars"></canvas><div class="donut-row pie-row" id="cs-pie"><canvas id="cs-pie-c"></canvas><div class="legend-list" id="cs-pie-l"></div></div></div>' +
      '<div class="stat-grid">' + stats.map(([k, v]) => '<div><span>' + esc(k) + '</span><b>' + v + '</b></div>').join('') +
      (gid && share ? '<div><span>' + esc(t('shareOfTotal')) + '</span><b>' + fmtNum(sum(values) / share * 100, 1) + ' %</b></div>' : '') + '</div>' +
      (parts && parts.length ? '<h4 class="sec-title">' + esc(t('breakdown')) + '</h4><div class="donut-row"><canvas id="cs-donut"></canvas><div class="legend-list">' +
        parts.map((p, i) => '<div class="lg" data-g="' + p.gid + '"' + (p.iid ? ' data-i="' + p.iid + '"' : '') + '><i style="background:' + PALETTE[i % PALETTE.length] + '"></i><span>' + esc(p.n) + '</span><b>' + money(p.v) + '</b><small>' + fmtNum(p.v / sum(parts.map((x) => x.v)) * 100, 1) + ' %</small></div>').join('') +
        '</div></div>' : ''),
    onMount: (el, done) => {
      const draw = () => {
        const bars = el.querySelector('#cs-bars'), pie = el.querySelector('#cs-pie');
        bars.style.display = sheetKind === 'pie' ? 'none' : ''; pie.style.display = sheetKind === 'pie' ? '' : 'none';
        const labels = Array.from({ length: 12 }, (_, i) => monthName(i, true).slice(0, 3));
        if (sheetKind === 'pie') mountPie(el.querySelector('#cs-pie-c'), el.querySelector('#cs-pie-l'), pieParts, (v) => money(v), 170);
        else mountBarChart(bars, sheetKind === 'line' ? { labels, series: [], lines: [{ values, color: col }] } : { labels, series: [{ values, color: col }] }, { height: 200 });
      };
      setTimeout(() => {
        draw();
        const d = el.querySelector('#cs-donut');
        if (d) mountDonut(d, parts.map((p) => p.v), PALETTE, 150);
      }, 30);
      el.querySelector('#cs-fs').onclick = () => {
        const fmt = (v) => money(v);
        const labels = Array.from({ length: 12 }, (_, i) => monthName(i, true).slice(0, 3));
        showFullscreen({
          title, fmt,
          bars: sheetKind === 'pie' ? null : (sheetKind === 'line' ? { labels, series: [], lines: [{ values, color: col }] } : { labels, series: [{ values, color: col }] }),
          pie: sheetKind === 'pie' ? pieParts : null, pieMode: 'both',
          tableHtml: fsTable([{ name: title, color: col }], values.map((v, i) => ({ label: monthName(i), values: [v] })), [sum(values)], fmt),
        });
      };
      el.querySelector('#cs-kind').onclick = (e) => { const bt = e.target.closest('button'); if (!bt) return; sheetKind = bt.dataset.v; el.querySelectorAll('#cs-kind button').forEach((x) => x.classList.toggle('on', x === bt)); draw(); };
      el.querySelectorAll('.lg[data-g]').forEach((x) => x.onclick = () => { done(null); setTimeout(() => chartSheet(type, x.dataset.g, x.dataset.i), 220); });
    },
  });
}

// ---------- NETO IMOVINA ----------
function vNet() {
  const b = B(), N = calcNet(b), net = b.net, P = net.periods.length;
  const editing = state.ui.edit.net;
  const card = '<div class="net-cards">' + net.periods.map((p, i) =>
    '<div class="kpi"><span>' + esc(p) + '</span><b class="' + (N.net[i] < 0 ? 'neg' : '') + '">' + (isNaN(N.net[i]) ? '—' : money(N.net[i])) + '</b><small>' +
    (isNaN(N.months[i]) ? '&nbsp;' : esc(t('wealthShort', { m: fmtNum(N.months[i], 1), y: fmtNum(N.years[i], 1) }))) + '</small></div>').join('') + '</div>';
  const rows = (side) => net[side].map((r) =>
    '<tr><td class="sticky"><div class="cellname">' +
    (editing ? '<button class="icon-btn xs" data-a="renNet" data-side="' + side + '" data-r="' + r.id + '">' + icon('pencil') + '</button>' : '') +
    '<span>' + esc(r.name || '—') + '</span>' +
    (editing ? '<button class="icon-btn xs" data-a="delNet" data-side="' + side + '" data-r="' + r.id + '">' + icon('trash') + '</button>' : '') + '</div></td>' +
    r.vals.map((v, i) => '<td><input class="cell wide" inputmode="decimal"' + (RO() ? ' readonly' : '') + ' data-net="' + side + '|' + r.id + '|' + i + '" value="' + (v === null ? '' : esc(fmtNum(v))) + '"></td>').join('') + '</tr>').join('');
  const tot = (lbl, a, cls) => '<tr class="' + cls + '"><td class="sticky">' + esc(lbl) + '</td>' + a.map((x) => '<td>' + (isNaN(x) ? '#N/A' : fmtNum(x)) + '</td>').join('') + '</tr>';
  const addRow = (side) => editing ? '<tr class="addrow"><td class="sticky"><button class="btn ghost small" data-a="addNet" data-side="' + side + '">' + icon('plus') + esc(t(side === 'assets' ? 'addAsset' : 'addLiability')) + '</button></td><td colspan="' + P + '"></td></tr>' : '';
  return '<div class="page-h-row"><h3 class="page-h">' + esc(t('netWorth')) + '</h3>' + infoBtn('netInfo') + '</div>' + card +
    '<div class="card chart-card"><canvas id="net-chart"></canvas></div>' +
    (editing ? '<div class="edit-hint">' + icon('pencil') + esc(t('editModeHint')) + '</div>' : '') +
    '<div class="scroll card"><table class="grid net"><thead><tr><th class="sticky">' + esc(t('stateOnLastDay')) + '</th>' +
    net.periods.map((p, i) => '<th>' + (editing ? '<button class="link" data-a="renPeriod" data-p="' + i + '">' + esc(p) + ' ' + icon('pencil', 'tiny') + '</button>' : esc(p)) + '</th>').join('') + '</tr></thead><tbody>' +
    '<tr class="sec"><td class="sticky" colspan="' + (P + 1) + '">' + esc(t('assets')) + '</td></tr>' + rows('assets') + addRow('assets') + tot(t('total'), N.assets, 'tot2') +
    '<tr class="sec"><td class="sticky" colspan="' + (P + 1) + '">' + esc(t('liabilities')) + '</td></tr>' + rows('liabilities') + addRow('liabilities') + tot(t('total'), N.liab, 'tot2') +
    tot(t('netWorth'), N.net, 'tot') + tot(t('wealthMonths'), N.months, 'tot2') + tot(t('wealthYears'), N.years, 'tot2') +
    '</tbody></table></div><p class="muted small">' + esc(t('wealthHint', { a: money(N.avgExp) })) + '</p><div class="fab-space"></div>';
}
async function renNet(side, rid) {
  const r = B().net[side].find((x) => x.id === rid);
  const n = await promptDlg(t('rename'), r.name); if (n === null) return;
  r.name = n; r.nameTs = nowTs(); persist(); app.rerender();
}
async function addNet(side) {
  const n = await promptDlg(t(side === 'assets' ? 'addAsset' : 'addLiability'), ''); if (n === null) return;
  B().net[side].push({ id: uid(side[0]), name: n, vals: B().net.periods.map(() => null) });
  persist(); app.rerender();
}
async function delNet(side, rid) {
  const b = B(); const idx = b.net[side].findIndex((x) => x.id === rid); const r = b.net[side][idx];
  if (!(await confirmDlg(t('delRowQ', { n: r.name }), { ok: t('delete'), danger: true }))) return;
  b.net[side].splice(idx, 1);
  markDeleted(b, r.id);
  await toTrash('netrow', r.name, r, { budgetId: b.id, side, index: idx });
  persist(); app.rerender();
}
async function renPeriod(i) {
  const n = await promptDlg(t('renamePeriod'), B().net.periods[i]); if (n === null) return;
  B().net.periods[i] = n; B().net.periodsTs = nowTs(); persist(); app.rerender();
}

// ---------- SAŽETAK ----------
function vSummary() {
  const b = B();
  const P = calcSide(b, 'income'), R = calcSide(b, 'expense');
  const diff = P.monthly.map((x, i) => x - R.monthly[i]);
  const tot = P.total - R.total;
  const sp = avgNZ(P.monthly, P.present), sr = avgNZ(R.monthly, R.present), dp = stdevNZ(P.monthly, P.present), dr = stdevNZ(R.monthly, R.present);
  const mx = (a, pr) => { const f = counted(a, pr); return f.length ? Math.max(...f) : 0; }, mn = (a, pr) => { const f = counted(a, pr); return f.length ? Math.min(...f) : 0; };
  return '<div class="kpis">' +
    '<div class="kpi inc"><span>' + esc(t('totalIncome')) + '</span><b>' + money(P.total) + '</b></div>' +
    '<div class="kpi exp"><span>' + esc(t('totalExpenses')) + '</span><b>' + money(R.total) + '</b></div>' +
    '<div class="kpi ' + (tot >= 0 ? 'inc' : 'exp') + '"><span>' + esc(t('totalDiff')) + '</span><b>' + money(tot) + '</b><small>' + (P.total ? esc(t('savingsRate', { p: fmtNum(tot / P.total * 100, 1) })) : '') + '</small></div></div>' +
    '<div class="card chart-card"><div class="chart-head"><div class="legend grow"><i style="background:' + chartColor('income') + '"></i>' + esc(t('income')) + '<i style="background:' + chartColor('expense') + '"></i>' + esc(t('expenses')) + '<i class="ln" style="background:' + chartColor('diff') + '"></i>' + esc(t('difference')) + '</div>' +
      '<button class="icon-btn sm" data-a="sumFs" title="' + esc(t('fullscreen')) + '">' + icon('expand') + '</button></div><canvas id="sum-chart"></canvas></div>' +
    '<div class="scroll card"><table class="grid sum"><thead><tr><th class="sticky"></th>' + Array.from({ length: 12 }, (_, i) => '<th>' + esc(monthName(i, true)) + '</th>').join('') + '</tr></thead><tbody>' +
    '<tr><td class="sticky">' + esc(t('income')) + '</td>' + P.monthly.map((x) => '<td>' + fmtNum(x) + '</td>').join('') + '</tr>' +
    '<tr><td class="sticky">' + esc(t('expenses')) + '</td>' + R.monthly.map((x) => '<td>' + fmtNum(x) + '</td>').join('') + '</tr>' +
    '<tr class="tot"><td class="sticky">' + esc(t('difference')) + '</td>' + diff.map((x) => '<td class="' + (x < 0 ? 'neg' : '') + '">' + fmtNum(x) + '</td>').join('') + '</tr></tbody></table></div>' +
    '<div class="two">' +
    '<table class="stats card"><tr><th></th><th>' + esc(t('income')) + '</th><th>' + esc(t('expenses')) + '</th><th>' + esc(t('difference')) + '</th></tr>' +
    '<tr><td>' + esc(t('avgMonthly')) + '</td><td>' + fmtNum(sp) + '</td><td>' + fmtNum(sr) + '</td><td>' + fmtNum(sp - sr) + '</td></tr>' +
    '<tr><td>' + esc(t('avgDaily')) + '</td><td>' + fmtNum(P.avgDaily) + '</td><td>' + fmtNum(R.avgDaily) + '</td><td>' + fmtNum(P.avgDaily - R.avgDaily) + '</td></tr></table>' +
    '<table class="stats card"><tr><th class="th-info">' + infoBtn('statsInfo') + esc(t('monthly')) + '</th><th>' + esc(t('income')) + '</th><th>' + esc(t('expenses')) + '</th></tr>' +
    '<tr><td>' + esc(t('statMean')) + '</td><td>' + fmtNum(sp) + '</td><td>' + fmtNum(sr) + '</td></tr>' +
    '<tr><td>' + esc(t('statSd')) + '</td><td>' + fmtNum(dp) + '</td><td>' + fmtNum(dr) + '</td></tr>' +
    '<tr><td>' + esc(t('statCv')) + '</td><td>' + (sp ? fmtNum(dp / sp) : '—') + '</td><td>' + (sr ? fmtNum(dr / sr) : '—') + '</td></tr>' +
    '<tr><td>MAX</td><td>' + fmtNum(mx(P.monthly, P.present)) + '</td><td>' + fmtNum(mx(R.monthly, R.present)) + '</td></tr>' +
    '<tr><td>MIN</td><td>' + fmtNum(mn(P.monthly, P.present)) + '</td><td>' + fmtNum(mn(R.monthly, R.present)) + '</td></tr></table></div>' +
    '<p class="muted small">' + esc(t(state.settings.avgIncludeZeros ? 'statsHintZeros' : 'statsHint')) + '</p>' +
    shareSection(b, R) + customGraphsSection(b) +
    '<div class="fab-space"></div>';
}

// Udio rashoda: po naslovima ili po svim podnaslovima (cijela godina)
let shareMode = 'groups';
function shareSection(b, R) {
  let rows;
  if (shareMode === 'items') {
    rows = [];
    b.expense.forEach((g, gi) => g.items.forEach((it, ii) => { const v = R.groups[gi].rows[ii].total; if (v > 0) rows.push({ n: it.name, sub: g.name, v, color: PALETTE[gi % PALETTE.length], gid: g.id, iid: it.id }); }));
  } else rows = b.expense.map((g, i) => ({ n: g.name, v: R.groups[i].total, color: PALETTE[i % PALETTE.length], gid: g.id })).filter((x) => x.v > 0);
  rows.sort((a, c) => c.v - a.v);
  const top = rows.length ? rows[0].v : 1;
  return '<div class="sec-row"><h4 class="sec-title">' + esc(t(shareMode === 'items' ? 'expenseItemsYear' : 'expenseShare')) + '</h4>' +
    '<div class="seg sm" id="share-mode"><button data-a="shareMode" data-v="groups" class="' + (shareMode === 'groups' ? 'on' : '') + '">' + esc(t('byTitles')) + '</button><button data-a="shareMode" data-v="items" class="' + (shareMode === 'items' ? 'on' : '') + '">' + esc(t('bySubtitles')) + '</button></div></div>' +
    (rows.length ? '<div class="card hbars' + (shareMode === 'items' ? ' items' : '') + '">' + rows.map((x) =>
      '<div class="hb" data-a="' + (x.iid ? 'chartItem' : 'chartGroup') + '" data-type="expense" data-g="' + x.gid + '"' + (x.iid ? ' data-i="' + x.iid + '"' : '') + '><span>' + esc(x.n) + (x.sub ? '<em>' + esc(x.sub) + '</em>' : '') + '</span><div class="bar"><i style="width:' + (x.v / top * 100) + '%;background:' + x.color + '"></i></div><b>' + money(x.v, { dec: 0 }) + '</b><small>' + fmtNum(x.v / R.total * 100, 1) + ' %</small></div>').join('') + '</div>'
      : '<p class="muted small">' + esc(t('noData')) + '</p>');
}
// Custom grafovi koji koriste ovu tablicu
function customGraphsSection(b) {
  const list = (state.settings.customGraphs || []).filter((g) => usesBudget(g, b.id));
  return '<div class="sec-row"><h4 class="sec-title">' + esc(t('customGraphs')) + '</h4><button class="btn small" data-a="graphNewHere">' + icon('plus') + esc(t('customGraph')) + '</button></div>' +
    (list.length ? '<div class="graph-grid">' + list.map(graphCard).join('') + '</div>' : '<p class="muted small">' + esc(t('customGraphsHint')) + '</p>');
}

// ---------- Nakon iscrtavanja: grafikoni i događaji ----------
export function mountBudget(root) {
  const b = B();
  const ss = root.querySelector('[data-sort]');
  if (ss) ss.onchange = () => { state.settings.entriesSort = ss.value; saveSettings(); resetEntriesShown(); app.rerender(); };
  const sc = root.querySelector('#sum-chart');
  if (sc) {
    const P = calcSide(b, 'income').monthly, R = calcSide(b, 'expense').monthly;
    mountBarChart(sc, {
      labels: Array.from({ length: 12 }, (_, i) => monthName(i, true).slice(0, 3)),
      series: [{ values: P, color: chartColor('income') }, { values: R, color: chartColor('expense') }],
      line: { values: P.map((x, i) => (x || R[i] ? x - R[i] : null)), color: chartColor('diff') },
    }, { height: 230 });
  }
  mountGraphCards(root);
  const nc = root.querySelector('#net-chart');
  if (nc) {
    const N = calcNet(b);
    mountBarChart(nc, { labels: b.net.periods.map((p) => p.slice(0, 6)), series: [{ values: N.net.map((x) => (isNaN(x) ? 0 : x)), color: cssVar('--acc', '#2563eb') }] }, { height: 170 });
  }
  // unos u tablicu (prikaz svih mjeseci)
  root.querySelectorAll('input.cell').forEach((inp) => {
    inp.addEventListener('focus', () => setTimeout(() => inp.select(), 0));
    inp.addEventListener('change', () => {
      const v = parseAmount(inp.value);
      if (v !== null && isNaN(v)) { inp.classList.add('bad'); toast(t('errAmount')); return; }
      inp.classList.remove('bad');
      if (inp.dataset.cell) { const [type, g, i, m] = inp.dataset.cell.split('|'); setCell(type, g, i, +m, v); }
      else if (inp.dataset.net) {
        const [side, rid, p] = inp.dataset.net.split('|');
        const r = b.net[side].find((x) => x.id === rid); r.vals[+p] = v === null ? null : round2(v); r.valsTs = nowTs(); persist();
      }
      const key = inp.dataset.cell || inp.dataset.net;
      setTimeout(() => {
        const active = document.activeElement && (document.activeElement.dataset.cell || document.activeElement.dataset.net);
        const sc2 = root.querySelector('.scroll'); const sl = sc2 ? sc2.scrollLeft : 0; const st = window.scrollY;
        app.rerender();
        const s3 = document.querySelector('.scroll'); if (s3) s3.scrollLeft = sl; window.scrollTo(0, st);
        if (active) { const el = document.querySelector('[data-cell="' + active + '"],[data-net="' + active + '"]'); if (el) el.focus(); }
      }, 0);
      void key;
    });
    inp.addEventListener('keydown', (e) => {
      if (e.key !== 'Enter') return;
      e.preventDefault();
      const all = [...root.querySelectorAll('input.cell')];
      const td = inp.closest('td'), col = [...td.parentNode.children].indexOf(td);
      const next = all.slice(all.indexOf(inp) + 1).find((i) => { const c = i.closest('td'); return [...c.parentNode.children].indexOf(c) === col; });
      if (next) next.focus(); else inp.blur();
    });
  });
}

const EDIT_ACTIONS = new Set(['quickAdd', 'editEntry', 'delEntry', 'editCell', 'renGroup', 'renItem', 'addGroup', 'addItem', 'delGroup', 'delItem', 'renNet', 'addNet', 'delNet', 'renPeriod', 'toggleEdit']);
export async function budgetAction(a, d) {
  const b = B();
  if (EDIT_ACTIONS.has(a) && RO()) { toast(t(readOnlyReason() === 'locked' ? 'roToast' : 'roOfflineToast'), { kind: 'warnt' }); return; }
  if (a.startsWith('graph') && a !== 'graphNewHere') { if (await graphAction(a, d, app.rerender)) return; }
  switch (a) {
    case 'graphNewHere': { const g = newGraph(b.id); g.name = b.name + ' – ' + t('customGraph'); if (await editGraph(g, true)) app.rerender(); return; }
    case 'shareMode': shareMode = d.v; return app.rerender();
    case 'toggleReadOnly': {
      const m = metaOf(b.id); m.readOnly = !m.readOnly; saveMeta();
      toast(t(m.readOnly ? 'roOn' : 'roOff')); return app.rerender();
    }
    case 'syncMenu': { const { syncMenu } = await import('../cloudDiag.js'); return syncMenu(b); }
    case 'syncInfo': return infoSheet(t('syncInfoTitle'), t('syncInfoHtml'));
    case 'exportPrint': { const { exportDialog } = await import('../export.js'); return exportDialog(b); }
    case 'netInfo': return infoSheet(t('netWorth'), t('netInfoHtml'));
    case 'statsInfo': return infoSheet(t('statsInfoTitle'), t('statsInfoHtml'));
    case 'sharedRefresh': { const r = await pullRemote(b); toast(r.changed ? t('loadedNewer') : (r.error ? t('syncFailShort') : t('upToDate'))); return app.rerender(); }
    case 'sharedInvite': { const { invite } = await import('./shared.js'); return invite(b.id); }
    case 'quickAdd': return addNew(d.type ? { type: d.type } : {});
    case 'editEntry': return editEntry(d.id);
    case 'delEntry': return delEntry(d.id);
    case 'moreEntries': entriesShown += 30; return app.rerender();
    case 'month': state.ui.month = (state.ui.month + (+d.d) + 12) % 12; return app.rerender();
    case 'toggleMonths': {
      const tp = state.ui.tab; state.settings.allMonths[tp] = !state.settings.allMonths[tp]; saveSettings();
      toast(t(state.settings.allMonths[tp] ? 'showingAll' : 'showingOne')); return app.rerender();
    }
    case 'toggleEdit': state.ui.edit[state.ui.tab] = !state.ui.edit[state.ui.tab]; return app.rerender();
    case 'editCell': return editCell(d.type, d.g, d.i, +d.m);
    case 'renGroup': return renGroup(d.type, d.g);
    case 'renItem': return renItem(d.type, d.g, d.i);
    case 'addGroup': return addGroup(d.type);
    case 'addItem': return addItem(d.type, d.g);
    case 'delGroup': return delGroup(d.type, d.g);
    case 'delItem': return delItem(d.type, d.g, d.i);
    case 'sumFs': return summaryFullscreen();
    case 'chartSide': return chartSheet(d.type);
    case 'chartGroup': return chartSheet(d.type, d.g);
    case 'chartItem': return chartSheet(d.type, d.g, d.i);
    case 'renNet': return renNet(d.side, d.r);
    case 'addNet': return addNet(d.side);
    case 'delNet': return delNet(d.side, d.r);
    case 'renPeriod': return renPeriod(+d.p);
    case 'retrySync': { const { pushCloud } = await import('../sync.js'); const r = await pushCloud(b.id); toast(t(r.ok ? 'syncOk' : r.offline ? 'savedLocalOffline' : 'syncFailShort'), { kind: r.ok ? '' : 'warnt' }); return app.rerender(); }
  }
}
export function resetEntriesShown() { entriesShown = 30; }
export { metaOf, daysIn };
