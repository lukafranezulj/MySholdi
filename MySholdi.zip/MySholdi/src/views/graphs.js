// "Custom Graphs": vlastiti grafovi iz više tablica i godina (i u Sažetku)
import { state } from '../state.js';
import { t } from '../i18n.js';
import { esc, money, monthName, uid, clone } from '../util.js';
import { icon } from '../icons.js';
import { newGraph, loadBudgetsFor, computeGraph, toChartData, toPieParts, seriesLabel, yearSeriesLabel, yearBudgetIds, seriesToNames, seriesToIds } from '../graphs.js';
import { showFullscreen, fsTable } from '../fullscreen.js';
import { mountBarChart, mountPie, PALETTE } from '../charts.js';
import { saveSettings, readBudget } from '../storage.js';
import { sheet, confirmDlg, toast } from '../ui.js';
import { refreshWidgets } from '../widgets.js';
import { isNative } from '../native.js';

const graphs = () => { if (!state.settings.customGraphs) state.settings.customGraphs = []; return state.settings.customGraphs; };

// Kartica jednog grafa (canvas se crta u mountGraphCards)
export function graphCard(g) {
  return '<div class="card graph-card" data-graph="' + g.id + '"><div class="gc-head"><b class="grow">' + esc(g.name) + '</b>' +
    (isNative ? '<button class="icon-btn sm" data-a="graphWidget" data-id="' + g.id + '" title="' + esc(t('addAsWidget')) + '">' + icon('widgets') + '</button>' : '') +
    '<button class="icon-btn sm" data-a="graphFs" data-id="' + g.id + '" title="' + esc(t('fullscreen')) + '">' + icon('expand') + '</button>' +
    '<button class="icon-btn sm" data-a="graphEdit" data-id="' + g.id + '">' + icon('pencil') + '</button>' +
    '<button class="icon-btn sm" data-a="graphDup" data-id="' + g.id + '">' + icon('copy') + '</button>' +
    '<button class="icon-btn sm" data-a="graphDel" data-id="' + g.id + '">' + icon('trash') + '</button></div>' +
    '<div class="gc-chart"><canvas></canvas></div><div class="donut-row pie-row gc-pie"><canvas></canvas><div class="legend-list"></div></div><div class="gc-legend"></div></div>';
}
export function renderGraphs() {
  const list = graphs();
  return '<p class="muted small">' + esc(t('graphsIntro')) + '</p>' +
    '<div class="list-actions"><button class="btn primary" data-a="graphNew">' + icon('plus') + esc(t('newGraph')) + '</button></div>' +
    (list.length ? '<div class="graph-grid">' + list.map(graphCard).join('') + '</div>' : '<div class="empty">' + icon('graph', 'big') + '<p>' + esc(t('noCustomGraphs')) + '</p></div>');
}
export async function mountGraphCards(root) {
  const cards = [...root.querySelectorAll('[data-graph]')];
  if (!cards.length) return;
  const list = graphs().filter((g) => cards.some((c) => c.dataset.graph === g.id));
  const map = await loadBudgetsFor(list);
  for (const card of cards) {
    const g = graphs().find((x) => x.id === card.dataset.graph); if (!g) continue;
    const comp = computeGraph(g, map);
    const isPie = g.chart === 'pie';
    card.querySelector('.gc-chart').style.display = isPie ? 'none' : '';
    card.querySelector('.gc-pie').style.display = isPie ? '' : 'none';
    card.querySelector('.gc-legend').style.display = isPie ? 'none' : '';
    if (isPie) mountPie(card.querySelector('.gc-pie canvas'), card.querySelector('.gc-pie .legend-list'), toPieParts(comp), (v) => money(v, { dec: 0 }), 160, g.pieValues || 'money', true);
    else {
      mountBarChart(card.querySelector('.gc-chart canvas'), toChartData(comp, g.chart), { height: 200 });
      card.querySelector('.gc-legend').innerHTML = comp.series.map((s) => '<span><i style="background:' + s.color + '"></i>' + esc(s.name) + ' <b>' + money(s.total, { dec: 0 }) + '</b></span>').join('');
    }
  }
}

// Prikaz grafa preko cijelog zaslona (s podacima: legenda s ukupnim iznosima i tablica po mjesecima ili godinama)
async function fullscreenGraph(g) {
  const map = await loadBudgetsFor([g]);
  const comp = computeGraph(g, map);
  const isPie = g.chart === 'pie';
  const fmt = (v) => money(v, { dec: 0 });
  await showFullscreen({
    title: g.name, fmt,
    bars: isPie ? null : toChartData(comp, g.chart),
    pie: isPie ? toPieParts(comp) : null, pieMode: g.pieValues || 'money',
    legendHtml: isPie ? '' : comp.series.map((x) => '<span><i style="background:' + x.color + '"></i>' + esc(x.name) + ' <b>' + fmt(x.total) + '</b></span>').join(''),
    tableHtml: fsTable(comp.series.map((x) => ({ name: x.name, color: x.color })), comp.rowLabels.map((l, i) => ({ label: l, values: comp.series.map((x) => x.values[i]) })), comp.series.map((x) => x.total), fmt),
  });
}

// Uređivač grafa
// X os: mjeseci (serija = naslov iz određene tablice) ili godine (serija = naziv naslova, traži se u tablici svake godine)
export async function editGraph(g, isNew) {
  const draft = clone(g);
  draft.xAxis = draft.xAxis || 'months';
  draft.monthMode = draft.monthMode || 'pick';
  draft.pieValues = draft.pieValues || 'money';
  if (!draft.months || !draft.months.length) draft.months = [...Array(12).keys()];
  const vis = state.index.filter((x) => !(state.meta[x.id] && state.meta[x.id].hidden));
  const allIds = vis.map((x) => x.id);
  const map = new Map();
  for (const id of allIds) { const b = state.budget && state.budget.id === id ? state.budget : await readBudget(id); if (b) map.set(id, b); }
  const firstBudget = (state.budget && map.has(state.budget.id) && state.budget.id) || allIds[0];
  const yearsOf = () => (Array.isArray(draft.yearBudgets) && draft.yearBudgets.length ? draft.yearBudgets : allIds);
  const budgetOpts = (sel) => vis.map((x) => '<option value="' + x.id + '"' + (x.id === sel ? ' selected' : '') + '>' + esc(x.name) + (x.shared ? ' 👥' : '') + '</option>').join('');
  const catOpts = (bid, side) => {
    const b = map.get(bid); if (!b || side === 'diff') return '<option value="">' + esc(t('total')) + '</option>';
    return '<option value="">' + esc(t('total')) + '</option>' + b[side].map((gr) => '<optgroup label="' + esc(gr.name) + '"><option value="' + gr.id + '|">' + esc(gr.name) + ' (' + esc(t('wholeTitle')) + ')</option>' +
      gr.items.map((it) => '<option value="' + gr.id + '|' + it.id + '">' + esc(it.name || '—') + '</option>').join('') + '</optgroup>').join('');
  };
  // graf po godinama: popis naziva naslova/podnaslova iz svih uključenih tablica (bez ponavljanja)
  let nameList = [];
  const catNameOpts = (side) => {
    nameList = [];
    if (side === 'diff') return '<option value="">' + esc(t('total')) + '</option>';
    const groups = new Map();
    yearsOf().forEach((id) => { const b = map.get(id); if (!b) return; b[side].forEach((gr) => {
      const k = gr.name.trim().toLowerCase(); if (!groups.has(k)) groups.set(k, { name: gr.name, items: new Map() });
      gr.items.forEach((it) => { const ik = String(it.name || '').trim().toLowerCase(); if (ik && !groups.get(k).items.has(ik)) groups.get(k).items.set(ik, it.name); });
    }); });
    let h = '<option value="">' + esc(t('total')) + '</option>';
    groups.forEach((gr) => {
      nameList.push({ gname: gr.name, iname: null });
      h += '<optgroup label="' + esc(gr.name) + '"><option value="' + (nameList.length - 1) + '">' + esc(gr.name) + ' (' + esc(t('wholeTitle')) + ')</option>';
      gr.items.forEach((nm) => { nameList.push({ gname: gr.name, iname: nm }); h += '<option value="' + (nameList.length - 1) + '">' + esc(nm) + '</option>'; });
      h += '</optgroup>';
    });
    return h;
  };
  const label = (s) => (draft.xAxis === 'years' ? yearSeriesLabel(s) : seriesLabel(s, map));
  // svaka serija ima svoju boju – dodir na kvadratić otvara odabir boje
  const seriesHtml = () => draft.series.map((s, i) => '<div class="ser-row"><label class="ser-color" style="background:' + s.color + '"><input type="color" data-ser-color="' + i + '" value="' + s.color + '"></label><span class="grow">' + esc(label(s)) + '</span><button class="icon-btn xs" data-del-ser="' + i + '">' + icon('x') + '</button></div>').join('') || '<p class="muted small">' + esc(t('noSeries')) + '</p>';
  const yearChips = () => vis.map((x) => { const b = map.get(x.id); return '<button data-yb="' + x.id + '" class="' + (yearsOf().includes(x.id) ? 'on' : '') + '">' + esc(x.name) + (b && !String(x.name).includes(String(b.year)) ? ' · ' + b.year : '') + '</button>'; }).join('');
  // boja koju će dobiti sljedeći podatak (prva neiskorištena iz palete; korisnik je može promijeniti)
  const autoColor = () => { const used = draft.series.map((x) => (x.color || '').toLowerCase()); return PALETTE.find((c) => !used.includes(c.toLowerCase())) || PALETTE[draft.series.length % PALETTE.length]; };
  let nextColor = autoColor();
  const seg = (id, cur, opts, cls) => '<div class="seg ' + (cls || '') + '" id="' + id + '">' + opts.map(([k, l]) => '<button data-v="' + k + '" class="' + (cur === k ? 'on' : '') + '">' + esc(t(l)) + '</button>').join('') + '</div>';
  const res = await sheet({
    title: isNew ? t('newGraph') : t('editGraph'), wide: true,
    body: '<label class="fld-label">' + esc(t('graphName')) + '</label><input class="fld" id="g-name" value="' + esc(draft.name) + '">' +
      '<label class="fld-label">' + esc(t('chartKind')) + '</label>' + seg('g-kind', draft.chart, [['bar', 'barChart'], ['line', 'lineChart'], ['pie', 'pieChart']], 'three') +
      '<div id="g-pv-wrap"' + (draft.chart === 'pie' ? '' : ' hidden') + '><p class="muted small">' + esc(t('pieHint')) + '</p><label class="fld-label">' + esc(t('pieValues')) + '</label>' + seg('g-pv', draft.pieValues, [['money', 'pv_money'], ['pct', 'pv_pct'], ['both', 'pv_both']], 'three') + '</div>' +
      '<label class="fld-label">' + esc(t('xAxis')) + '</label>' + seg('g-x', draft.xAxis, [['months', 'xMonths'], ['years', 'xYears']]) +
      '<div id="g-years-wrap"' + (draft.xAxis === 'years' ? '' : ' hidden') + '><p class="muted small">' + esc(t('xYearsHint')) + '</p><label class="fld-label">' + esc(t('yearTables')) + ' <button class="link" id="g-yall">' + esc(t('all')) + '</button></label><div class="chips" id="g-years">' + yearChips() + '</div></div>' +
      '<label class="fld-label" id="g-mlabel">' + esc(t(draft.xAxis === 'years' ? 'monthsSummed' : 'monthsToShow')) + '</label>' + seg('g-mmode', draft.monthMode, [['pick', 'monthsPicked'], ['current', 'monthCurrent']]) +
      '<div id="g-mpick"' + (draft.monthMode === 'current' ? ' hidden' : '') + '><div class="chips-head"><button class="link" id="g-all">' + esc(t('all')) + '</button></div><div class="chips" id="g-months">' +
      Array.from({ length: 12 }, (_, m) => '<button data-m="' + m + '" class="' + (draft.months.includes(m) ? 'on' : '') + '">' + esc(monthName(m, true)) + '</button>').join('') + '</div></div>' +
      '<p class="muted small" id="g-mcur"' + (draft.monthMode === 'current' ? '' : ' hidden') + '>' + esc(t('monthCurrentHint', { m: monthName(new Date().getMonth()) })) + '</p>' +
      '<label class="fld-label">' + esc(t('seriesList')) + '</label><div id="g-series">' + seriesHtml() + '</div>' +
      '<div class="card pad add-ser"><b>' + esc(t('addSeries')) + '</b>' +
      '<div class="row2"><div id="s-budget-wrap"' + (draft.xAxis === 'years' ? ' hidden' : '') + '><label class="fld-label">' + esc(t('budgetSource')) + '</label><select class="fld" id="s-budget">' + budgetOpts(firstBudget) + '</select></div>' +
      '<div><label class="fld-label">' + esc(t('side')) + '</label><select class="fld" id="s-side"><option value="expense">' + esc(t('expenses')) + '</option><option value="income">' + esc(t('income')) + '</option><option value="diff">' + esc(t('difference')) + '</option></select></div></div>' +
      '<label class="fld-label">' + esc(t('titleOrSubtitle')) + '</label><select class="fld" id="s-cat"></select>' +
      '<div class="next-color"><span>' + esc(t('nextColor')) + '</span><label class="ser-color big" id="s-color-sw" style="background:' + nextColor + '"><input type="color" id="s-color" value="' + nextColor + '"></label><small class="muted">' + esc(t('nextColorHint')) + '</small></div>' +
      '<button class="btn block" id="s-add">' + icon('plus') + esc(t('addSeries')) + '</button><p class="muted small" id="s-hint"' + (draft.xAxis === 'years' ? ' hidden' : '') + '>' + esc(t('seriesHint')) + '</p></div>',
    actions: [{ label: t('cancel'), value: null }, { label: t('save'), value: 'ok', cls: 'primary' }],
    onMount: (el) => {
      const q = (x) => el.querySelector(x);
      const refreshCats = () => { q('#s-cat').innerHTML = draft.xAxis === 'years' ? catNameOpts(q('#s-side').value) : catOpts(q('#s-budget').value, q('#s-side').value); };
      refreshCats();
      q('#s-budget').onchange = refreshCats; q('#s-side').onchange = refreshCats;
      const segClick = (id, fn) => { q(id).onclick = (e) => { const b = e.target.closest('button'); if (!b) return; q(id).querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b)); fn(b.dataset.v); }; };
      const redrawSeries = () => { q('#g-series').innerHTML = seriesHtml(); rebind(); };
      segClick('#g-kind', (v) => { draft.chart = v; q('#g-pv-wrap').hidden = v !== 'pie'; });
      segClick('#g-pv', (v) => { draft.pieValues = v; });
      segClick('#g-x', (v) => {
        if (v === draft.xAxis) return;
        // postojeće serije se pretvaraju (naslov iz tablice ↔ naziv naslova)
        draft.series = v === 'years' ? seriesToNames(draft.series, map) : seriesToIds(draft.series, map.get(firstBudget));
        draft.xAxis = v;
        q('#g-years-wrap').hidden = v !== 'years'; q('#s-budget-wrap').hidden = v === 'years'; q('#s-hint').hidden = v === 'years';
        q('#g-mlabel').textContent = t(v === 'years' ? 'monthsSummed' : 'monthsToShow');
        refreshCats(); redrawSeries();
      });
      segClick('#g-mmode', (v) => { draft.monthMode = v; q('#g-mpick').hidden = v === 'current'; q('#g-mcur').hidden = v !== 'current'; });
      q('#g-years').onclick = (e) => {
        const b = e.target.closest('button'); if (!b) return;
        const cur = yearsOf().slice(); const id = b.dataset.yb;
        const next = cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id];
        if (!next.length) return;
        draft.yearBudgets = next.length === allIds.length ? null : next;
        b.classList.toggle('on'); refreshCats();
      };
      q('#g-yall').onclick = (e) => { e.preventDefault(); draft.yearBudgets = null; q('#g-years').querySelectorAll('button').forEach((x) => x.classList.add('on')); refreshCats(); };
      q('#g-months').onclick = (e) => { const b = e.target.closest('button'); if (!b) return; const m = +b.dataset.m; draft.months = draft.months.includes(m) ? draft.months.filter((x) => x !== m) : [...draft.months, m]; b.classList.toggle('on'); };
      q('#g-all').onclick = (e) => { e.preventDefault(); const all = draft.months.length < 12; draft.months = all ? [...Array(12).keys()] : []; q('#g-months').querySelectorAll('button').forEach((x) => x.classList.toggle('on', all)); };
      const setNext = (c) => { nextColor = c; q('#s-color').value = c; q('#s-color-sw').style.background = c; };
      q('#s-color').oninput = () => setNext(q('#s-color').value);
      function rebind() {
        q('#g-series').querySelectorAll('[data-del-ser]').forEach((b) => b.onclick = () => { draft.series.splice(+b.dataset.delSer, 1); redrawSeries(); setNext(autoColor()); });
        q('#g-series').querySelectorAll('[data-ser-color]').forEach((inp) => inp.oninput = () => { draft.series[+inp.dataset.serColor].color = inp.value; inp.parentElement.style.background = inp.value; });
      }
      rebind();
      q('#s-add').onclick = () => {
        const side = q('#s-side').value, v = q('#s-cat').value;
        if (draft.xAxis === 'years') {
          const n = v === '' ? { gname: null, iname: null } : nameList[+v];
          draft.series.push({ id: uid('s'), side, gname: n.gname, iname: n.iname, color: nextColor });
        } else {
          const [gid, iid] = (v || '|').split('|');
          draft.series.push({ id: uid('s'), budgetId: q('#s-budget').value, side, gid: gid || null, iid: iid || null, color: nextColor });
        }
        redrawSeries(); setNext(autoColor());
      };
    },
    onAction: (v, el) => {
      if (v !== 'ok') return null;
      draft.name = el.querySelector('#g-name').value.trim() || t('customGraph');
      if (!draft.series.length) { toast(t('noSeries')); return false; }
      if (!draft.months.length) draft.months = [...Array(12).keys()];
      return draft;
    },
  });
  if (!res) return null;
  const list = graphs();
  const i = list.findIndex((x) => x.id === res.id);
  if (i >= 0) list[i] = res; else list.push(res);
  await saveSettings(); refreshWidgets();
  return res;
}

export async function graphAction(a, d, rerender) {
  const list = graphs();
  if (a === 'graphNew') { const g = await editGraph(newGraph(state.budget ? state.budget.id : (state.index[0] || {}).id), true); if (g) rerender(); return true; }
  const g = list.find((x) => x.id === d.id);
  if (!g) return false;
  if (a === 'graphEdit') { if (await editGraph(g, false)) rerender(); return true; }
  if (a === 'graphFs') { await fullscreenGraph(g); return true; }
  if (a === 'graphWidget') { const { addGraphWidget } = await import('./widgetsView.js'); await addGraphWidget(g.id, true); return true; }
  if (a === 'graphDup') { list.push({ ...clone(g), id: uid('cg'), name: g.name + ' (2)' }); await saveSettings(); rerender(); return true; }
  if (a === 'graphDel') {
    if (!(await confirmDlg(t('delGraphQ', { n: g.name }), { ok: t('delete'), danger: true }))) return true;
    state.settings.customGraphs = list.filter((x) => x !== g); await saveSettings(); refreshWidgets(); rerender(); return true;
  }
  return false;
}
