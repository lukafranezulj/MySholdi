// "Custom Graphs": vlastiti grafovi iz više tablica i godina (i u Sažetku)
import { state } from '../state.js';
import { t } from '../i18n.js';
import { esc, money, monthName, uid, clone } from '../util.js';
import { icon } from '../icons.js';
import { newGraph, loadBudgetsFor, computeGraph, toChartData, toPieParts, seriesLabel } from '../graphs.js';
import { mountBarChart, mountPie, PALETTE } from '../charts.js';
import { saveSettings, readBudget } from '../storage.js';
import { sheet, confirmDlg, toast } from '../ui.js';
import { refreshWidgets } from '../widgets.js';
import { isNative } from '../native.js';

const graphs = () => { if (!state.settings.customGraphs) state.settings.customGraphs = []; return state.settings.customGraphs; };

// Kartica jednog grafa (canvas se crta u mountGraphCards)
export function graphCard(g) {
  return '<div class="card graph-card" data-graph="' + g.id + '"><div class="gc-head"><b class="grow">' + esc(g.name) + '</b>' +
    (isNative ? '<button class="icon-btn sm" data-a="graphWidget" data-id="' + g.id + '" title="' + esc(t('addAsWidget')) + '">' + icon('widgets') + '</button>' : '') +
    '<button class="icon-btn sm" data-a="graphFs" data-id="' + g.id + '" title="' + esc(t('fullscreen')) + '">' + icon('expand') + '</button>' +
    '<button class="icon-btn sm" data-a="graphEdit" data-id="' + g.id + '">' + icon('pencil') + '</button>' +
    '<button class="icon-btn sm" data-a="graphDup" data-id="' + g.id + '">' + icon('copy') + '</button>' +
    '<button class="icon-btn sm" data-a="graphDel" data-id="' + g.id + '">' + icon('trash') + '</button></div>' +
    '<div class="gc-chart"><canvas></canvas></div><div class="donut-row pie-row gc-pie"><canvas></canvas><div class="legend-list"></div></div><div class="gc-legend"></div></div>';
}
export function renderGraphs() {
  const list = graphs();
  return '<p class="muted small">' + esc(t('graphsIntro')) + '</p>' +
    '<div class="list-actions"><button class="btn primary" data-a="graphNew">' + icon('plus') + esc(t('newGraph')) + '</button></div>' +
    (list.length ? '<div class="graph-grid">' + list.map(graphCard).join('') + '</div>' : '<div class="empty">' + icon('graph', 'big') + '<p>' + esc(t('noCustomGraphs')) + '</p></div>');
}
export async function mountGraphCards(root) {
  const cards = [...root.querySelectorAll('[data-graph]')];
  if (!cards.length) return;
  const list = graphs().filter((g) => cards.some((c) => c.dataset.graph === g.id));
  const map = await loadBudgetsFor(list);
  for (const card of cards) {
    const g = graphs().find((x) => x.id === card.dataset.graph); if (!g) continue;
    const comp = computeGraph(g, map);
    const isPie = g.chart === 'pie';
    card.querySelector('.gc-chart').style.display = isPie ? 'none' : '';
    card.querySelector('.gc-pie').style.display = isPie ? '' : 'none';
    card.querySelector('.gc-legend').style.display = isPie ? 'none' : '';
    if (isPie) mountPie(card.querySelector('.gc-pie canvas'), card.querySelector('.gc-pie .legend-list'), toPieParts(comp), (v) => money(v, { dec: 0 }), 160);
    else {
      mountBarChart(card.querySelector('.gc-chart canvas'), toChartData(comp, g.chart), { height: 200 });
      card.querySelector('.gc-legend').innerHTML = comp.series.map((s) => '<span><i style="background:' + s.color + '"></i>' + esc(s.name) + ' <b>' + money(s.total, { dec: 0 }) + '</b></span>').join('');
    }
  }
}

// Prikaz grafa preko cijelog zaslona (s podacima: legenda s ukupnim iznosima i tablica po mjesecima).
// Izlaz: tipka Natrag ili X u gornjem desnom kutu.
async function fullscreenGraph(g) {
  const map = await loadBudgetsFor([g]);
  const comp = computeGraph(g, map);
  const isPie = g.chart === 'pie';
  const fmt = (v) => money(v, { dec: 0 });
  const table = '<div class="fs-table-wrap"><table class="fs-table"><thead><tr><th></th>' + comp.series.map((x) => '<th><i style="background:' + x.color + '"></i>' + esc(x.name) + '</th>').join('') + '</tr></thead><tbody>' +
    comp.months.map((m, i) => '<tr><td>' + esc(monthName(m)) + '</td>' + comp.series.map((x) => '<td>' + fmt(x.values[i]) + '</td>').join('') + '</tr>').join('') +
    '<tr class="tot"><td>' + esc(t('total')) + '</td>' + comp.series.map((x) => '<td>' + fmt(x.total) + '</td>').join('') + '</tr></tbody></table></div>';
  let onResize = null;
  await sheet({
    title: g.name, cls: 'fs-sheet',
    body: '<div class="fs-chart">' + (isPie ? '<div class="donut-row pie-row"><canvas></canvas><div class="legend-list"></div></div>' : '<canvas></canvas>') + '</div>' +
      (isPie ? '' : '<div class="gc-legend fs-legend">' + comp.series.map((x) => '<span><i style="background:' + x.color + '"></i>' + esc(x.name) + ' <b>' + fmt(x.total) + '</b></span>').join('') + '</div>') + table,
    onMount: (el) => {
      el.querySelector('.sheet-head [data-close]').title = t('exitFullscreen');
      const draw = () => {
        if (isPie) {
          const sz = Math.max(160, Math.min(el.clientWidth - 40, window.innerHeight * 0.55, 420));
          mountPie(el.querySelector('.fs-chart canvas'), el.querySelector('.fs-chart .legend-list'), toPieParts(comp), fmt, sz);
        } else {
          const h = Math.max(220, Math.min(window.innerHeight * 0.58, 620));
          mountBarChart(el.querySelector('.fs-chart canvas'), toChartData(comp, g.chart), { height: h });
        }
      };
      setTimeout(draw, 30);
      let rt; onResize = () => { clearTimeout(rt); rt = setTimeout(draw, 120); };
      window.addEventListener('resize', onResize);
    },
  });
  if (onResize) window.removeEventListener('resize', onResize);
}

// Uređivač grafa
export async function editGraph(g, isNew) {
  const draft = clone(g);
  const allIds = state.index.filter((x) => !(state.meta[x.id] && state.meta[x.id].hidden)).map((x) => x.id);
  const map = new Map();
  for (const id of allIds) { const b = state.budget && state.budget.id === id ? state.budget : await readBudget(id); if (b) map.set(id, b); }
  const budgetOpts = (sel) => state.index.filter((x) => !(state.meta[x.id] && state.meta[x.id].hidden)).map((x) => '<option value="' + x.id + '"' + (x.id === sel ? ' selected' : '') + '>' + esc(x.name) + (x.shared ? ' 👥' : '') + '</option>').join('');
  const catOpts = (bid, side) => {
    const b = map.get(bid); if (!b || side === 'diff') return '<option value="">' + esc(t('total')) + '</option>';
    return '<option value="">' + esc(t('total')) + '</option>' + b[side].map((gr) => '<optgroup label="' + esc(gr.name) + '"><option value="' + gr.id + '|">' + esc(gr.name) + ' (' + esc(t('wholeTitle')) + ')</option>' +
      gr.items.map((it) => '<option value="' + gr.id + '|' + it.id + '">' + esc(it.name || '—') + '</option>').join('') + '</optgroup>').join('');
  };
  // svaka serija ima svoju boju – dodir na kvadratić otvara odabir boje
  const seriesHtml = () => draft.series.map((s, i) => '<div class="ser-row"><label class="ser-color" style="background:' + s.color + '"><input type="color" data-ser-color="' + i + '" value="' + s.color + '"></label><span class="grow">' + esc(seriesLabel(s, map)) + '</span><button class="icon-btn xs" data-del-ser="' + i + '">' + icon('x') + '</button></div>').join('') || '<p class="muted small">' + esc(t('noSeries')) + '</p>';
  const firstBudget = (state.budget && state.budget.id) || allIds[0];
  // boja koju će dobiti sljedeći podatak (prva neiskorištena iz palete; korisnik je može promijeniti)
  const autoColor = () => { const used = draft.series.map((x) => (x.color || '').toLowerCase()); return PALETTE.find((c) => !used.includes(c.toLowerCase())) || PALETTE[draft.series.length % PALETTE.length]; };
  let nextColor = autoColor();
  const res = await sheet({
    title: isNew ? t('newGraph') : t('editGraph'), wide: true,
    body: '<label class="fld-label">' + esc(t('graphName')) + '</label><input class="fld" id="g-name" value="' + esc(draft.name) + '">' +
      '<label class="fld-label">' + esc(t('chartKind')) + '</label><div class="seg three" id="g-kind">' + [['bar', 'barChart'], ['line', 'lineChart'], ['pie', 'pieChart']].map(([k, l]) => '<button data-v="' + k + '" class="' + (draft.chart === k ? 'on' : '') + '">' + esc(t(l)) + '</button>').join('') + '</div>' +
      '<p class="muted small" id="g-pie-hint"' + (draft.chart === 'pie' ? '' : ' hidden') + '>' + esc(t('pieHint')) + '</p>' +
      '<label class="fld-label">' + esc(t('monthsToShow')) + ' <button class="link" id="g-all">' + esc(t('all')) + '</button></label><div class="chips" id="g-months">' +
      Array.from({ length: 12 }, (_, m) => '<button data-m="' + m + '" class="' + (draft.months.includes(m) ? 'on' : '') + '">' + esc(monthName(m, true)) + '</button>').join('') + '</div>' +
      '<label class="fld-label">' + esc(t('seriesList')) + '</label><div id="g-series">' + seriesHtml() + '</div>' +
      '<div class="card pad add-ser"><b>' + esc(t('addSeries')) + '</b>' +
      '<div class="row2"><div><label class="fld-label">' + esc(t('budgetSource')) + '</label><select class="fld" id="s-budget">' + budgetOpts(firstBudget) + '</select></div>' +
      '<div><label class="fld-label">' + esc(t('side')) + '</label><select class="fld" id="s-side"><option value="expense">' + esc(t('expenses')) + '</option><option value="income">' + esc(t('income')) + '</option><option value="diff">' + esc(t('difference')) + '</option></select></div></div>' +
      '<label class="fld-label">' + esc(t('titleOrSubtitle')) + '</label><select class="fld" id="s-cat">' + catOpts(firstBudget, 'expense') + '</select>' +
      '<div class="next-color"><span>' + esc(t('nextColor')) + '</span><label class="ser-color big" id="s-color-sw" style="background:' + nextColor + '"><input type="color" id="s-color" value="' + nextColor + '"></label><small class="muted">' + esc(t('nextColorHint')) + '</small></div>' +
      '<button class="btn block" id="s-add">' + icon('plus') + esc(t('addSeries')) + '</button><p class="muted small">' + esc(t('seriesHint')) + '</p></div>',
    actions: [{ label: t('cancel'), value: null }, { label: t('save'), value: 'ok', cls: 'primary' }],
    onMount: (el) => {
      const q = (s) => el.querySelector(s);
      const refreshCats = () => { q('#s-cat').innerHTML = catOpts(q('#s-budget').value, q('#s-side').value); };
      q('#s-budget').onchange = refreshCats; q('#s-side').onchange = refreshCats;
      q('#g-kind').onclick = (e) => { const b = e.target.closest('button'); if (!b) return; draft.chart = b.dataset.v; q('#g-kind').querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b)); q('#g-pie-hint').hidden = draft.chart !== 'pie'; };
      q('#g-months').onclick = (e) => { const b = e.target.closest('button'); if (!b) return; const m = +b.dataset.m; draft.months = draft.months.includes(m) ? draft.months.filter((x) => x !== m) : [...draft.months, m]; b.classList.toggle('on'); };
      q('#g-all').onclick = (e) => { e.preventDefault(); const all = draft.months.length < 12; draft.months = all ? [...Array(12).keys()] : []; q('#g-months').querySelectorAll('button').forEach((x) => x.classList.toggle('on', all)); };
      const bindDel = () => {
        q('#g-series').querySelectorAll('[data-del-ser]').forEach((b) => b.onclick = () => { draft.series.splice(+b.dataset.delSer, 1); q('#g-series').innerHTML = seriesHtml(); bindDel(); });
        q('#g-series').querySelectorAll('[data-ser-color]').forEach((inp) => inp.oninput = () => { draft.series[+inp.dataset.serColor].color = inp.value; inp.parentElement.style.background = inp.value; });
      };
      const setNext = (c) => { nextColor = c; q('#s-color').value = c; q('#s-color-sw').style.background = c; };
      q('#s-color').oninput = () => setNext(q('#s-color').value);
      const bindDel0 = bindDel;
      const rebind = () => { bindDel0(); q('#g-series').querySelectorAll('[data-del-ser]').forEach((b) => { const f = b.onclick; b.onclick = () => { f(); setNext(autoColor()); rebind(); }; }); };
      rebind();
      q('#s-add').onclick = () => {
        const [gid, iid] = (q('#s-cat').value || '|').split('|');
        draft.series.push({ id: uid('s'), budgetId: q('#s-budget').value, side: q('#s-side').value, gid: gid || null, iid: iid || null, color: nextColor });
        q('#g-series').innerHTML = seriesHtml(); rebind();
        setNext(autoColor());
      };
    },
    onAction: (v, el) => {
      if (v !== 'ok') return null;
      draft.name = el.querySelector('#g-name').value.trim() || t('customGraph');
      if (!draft.series.length) { toast(t('noSeries')); return false; }
      if (!draft.months.length) draft.months = [...Array(12).keys()];
      return draft;
    },
  });
  if (!res) return null;
  const list = graphs();
  const i = list.findIndex((x) => x.id === res.id);
  if (i >= 0) list[i] = res; else list.push(res);
  await saveSettings(); refreshWidgets();
  return res;
}

export async function graphAction(a, d, rerender) {
  const list = graphs();
  if (a === 'graphNew') { const g = await editGraph(newGraph(state.budget ? state.budget.id : (state.index[0] || {}).id), true); if (g) rerender(); return true; }
  const g = list.find((x) => x.id === d.id);
  if (!g) return false;
  if (a === 'graphEdit') { if (await editGraph(g, false)) rerender(); return true; }
  if (a === 'graphFs') { await fullscreenGraph(g); return true; }
  if (a === 'graphWidget') { const { addGraphWidget } = await import('./widgetsView.js'); await addGraphWidget(g.id, true); return true; }
  if (a === 'graphDup') { list.push({ ...clone(g), id: uid('cg'), name: g.name + ' (2)' }); await saveSettings(); rerender(); return true; }
  if (a === 'graphDel') {
    if (!(await confirmDlg(t('delGraphQ', { n: g.name }), { ok: t('delete'), danger: true }))) return true;
    state.settings.customGraphs = list.filter((x) => x !== g); await saveSettings(); refreshWidgets(); rerender(); return true;
  }
  return false;
}
