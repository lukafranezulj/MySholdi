// "Custom Graphs": vlastiti grafovi iz više tablica i godina (i u Sažetku)
import { state } from '../state.js';
import { t } from '../i18n.js';
import { esc, money, monthName, uid, clone } from '../util.js';
import { icon } from '../icons.js';
import { newGraph, loadBudgetsFor, computeGraph, toChartData, toPieParts, seriesLabel, yearBudgetIds, catLabel, pointSeriesLabel, seriesToPoints, namesToPoints, pointsToSeries } from '../graphs.js';
import { showFullscreen, fsTable } from '../fullscreen.js';
import { mountBarChart, mountPie, PALETTE } from '../charts.js';
import { saveSettings, readBudget } from '../storage.js';
import { sheet, confirmDlg, toast } from '../ui.js';
import { refreshWidgets } from '../widgets.js';
import { isNative } from '../native.js';

const graphs = () => { if (!state.settings.customGraphs) state.settings.customGraphs = []; return state.settings.customGraphs; };

// Kartica jednog grafa (canvas se crta u mountGraphCards)
export function graphCard(g) {
  return '<div class="card graph-card" data-graph="' + g.id + '"><div class="gc-head"><b class="grow">' + esc(g.name) + '</b>' +
    (isNative ? '<button class="icon-btn sm" data-a="graphWidget" data-id="' + g.id + '" title="' + esc(t('addAsWidget')) + '">' + icon('widgets') + '</button>' : '') +
    '<button class="icon-btn sm" data-a="graphFs" data-id="' + g.id + '" title="' + esc(t('fullscreen')) + '">' + icon('expand') + '</button>' +
    '<button class="icon-btn sm" data-a="graphEdit" data-id="' + g.id + '">' + icon('pencil') + '</button>' +
    '<button class="icon-btn sm" data-a="graphDup" data-id="' + g.id + '">' + icon('copy') + '</button>' +
    '<button class="icon-btn sm" data-a="graphDel" data-id="' + g.id + '">' + icon('trash') + '</button></div>' +
    '<div class="gc-chart"><canvas></canvas></div><div class="donut-row pie-row gc-pie"><canvas></canvas><div class="legend-list"></div></div><div class="gc-legend"></div></div>';
}
export function renderGraphs() {
  const list = graphs();
  return '<p class="muted small">' + esc(t('graphsIntro')) + '</p>' +
    '<div class="list-actions"><button class="btn primary" data-a="graphNew">' + icon('plus') + esc(t('newGraph')) + '</button></div>' +
    (list.length ? '<div class="graph-grid">' + list.map(graphCard).join('') + '</div>' : '<div class="empty">' + icon('graph', 'big') + '<p>' + esc(t('noCustomGraphs')) + '</p></div>');
}
export async function mountGraphCards(root) {
  const cards = [...root.querySelectorAll('[data-graph]')];
  if (!cards.length) return;
  const list = graphs().filter((g) => cards.some((c) => c.dataset.graph === g.id));
  const map = await loadBudgetsFor(list);
  for (const card of cards) {
    const g = graphs().find((x) => x.id === card.dataset.graph); if (!g) continue;
    const comp = computeGraph(g, map);
    const isPie = g.chart === 'pie';
    card.querySelector('.gc-chart').style.display = isPie ? 'none' : '';
    card.querySelector('.gc-pie').style.display = isPie ? '' : 'none';
    card.querySelector('.gc-legend').style.display = isPie ? 'none' : '';
    if (isPie) mountPie(card.querySelector('.gc-pie canvas'), card.querySelector('.gc-pie .legend-list'), toPieParts(comp), (v) => money(v, { dec: 0 }), 160, g.pieValues || 'money', true);
    else {
      mountBarChart(card.querySelector('.gc-chart canvas'), toChartData(comp, g.chart), { height: 200 });
      card.querySelector('.gc-legend').innerHTML = comp.series.map((s) => '<span><i style="background:' + s.color + '"></i>' + esc(s.name) + ' <b>' + money(s.total, { dec: 0 }) + '</b></span>').join('');
    }
  }
}

// Prikaz grafa preko cijelog zaslona (s podacima: legenda s ukupnim iznosima i tablica po mjesecima ili godinama)
async function fullscreenGraph(g) {
  const map = await loadBudgetsFor([g]);
  const comp = computeGraph(g, map);
  const isPie = g.chart === 'pie';
  const fmt = (v) => money(v, { dec: 0 });
  await showFullscreen({
    title: g.name, fmt,
    bars: isPie ? null : toChartData(comp, g.chart),
    pie: isPie ? toPieParts(comp) : null, pieMode: g.pieValues || 'money',
    legendHtml: isPie ? '' : comp.series.map((x) => '<span><i style="background:' + x.color + '"></i>' + esc(x.name) + ' <b>' + fmt(x.total) + '</b></span>').join(''),
    tableHtml: fsTable(comp.series.map((x) => ({ name: x.name, color: x.color })), comp.rowLabels.map((l, i) => ({ label: l, values: comp.series.map((x) => x.values[i]) })), comp.series.map((x) => x.total), fmt),
  });
}

// Uređivač grafa
// X os mjeseci: serija = naslov/podnaslov iz jedne tablice.
// X os godine: serija (linija) = niz točaka; za svaku godinu korisnik bira tablicu i naslov/podnaslov,
// pa linija spaja i naslove koji se u različitim godinama zovu drugačije.
export async function editGraph(g, isNew) {
  const draft = clone(g);
  draft.xAxis = draft.xAxis || 'months';
  draft.monthMode = draft.monthMode || 'pick';
  draft.pieValues = draft.pieValues || 'money';
  if (!draft.months || !draft.months.length) draft.months = [...Array(12).keys()];
  const vis = state.index.filter((x) => !(state.meta[x.id] && state.meta[x.id].hidden));
  const allIds = vis.map((x) => x.id);
  const map = new Map();
  for (const id of allIds) { const b = state.budget && state.budget.id === id ? state.budget : await readBudget(id); if (b) map.set(id, b); }
  const firstBudget = (state.budget && map.has(state.budget.id) && state.budget.id) || allIds[0];
  // stari graf po godinama (serije po nazivu) → točke
  if (draft.xAxis === 'years' && draft.series.length && !draft.series.some((x) => Array.isArray(x.points))) draft.series = namesToPoints(draft.series, yearBudgetIds(draft), map);
  const years = () => draft.xAxis === 'years';
  const yearOf = (id) => (map.get(id) ? map.get(id).year : '');
  const budgetOpts = (sel) => vis.map((x) => '<option value="' + x.id + '"' + (x.id === sel ? ' selected' : '') + '>' + esc(x.name) + (map.get(x.id) && !String(x.name).includes(String(map.get(x.id).year)) ? ' (' + map.get(x.id).year + ')' : '') + (x.shared ? ' 👥' : '') + '</option>').join('');
  const catOpts = (bid, side) => {
    const b = map.get(bid); if (!b || side === 'diff') return '<option value="">' + esc(t('total')) + '</option>';
    return '<option value="">' + esc(t('total')) + '</option>' + b[side].map((gr) => '<optgroup label="' + esc(gr.name) + '"><option value="' + gr.id + '|">' + esc(gr.name) + ' (' + esc(t('wholeTitle')) + ')</option>' +
      gr.items.map((it) => '<option value="' + gr.id + '|' + it.id + '">' + esc(it.name || '—') + '</option>').join('') + '</optgroup>').join('');
  };
  // popis serija: kod godina svaka linija ima naziv i točke (godina · naslov)
  const seriesHtml = () => {
    if (!draft.series.length) return '<p class="muted small">' + esc(t(years() ? 'noPoints' : 'noSeries')) + '</p>';
    if (!years()) return draft.series.map((x, i) => '<div class="ser-row"><label class="ser-color" style="background:' + x.color + '"><input type="color" data-ser-color="' + i + '" value="' + x.color + '"></label><span class="grow">' + esc(seriesLabel(x, map)) + '</span><button class="icon-btn xs" data-del-ser="' + i + '">' + icon('x') + '</button></div>').join('');
    return draft.series.map((x, i) => {
      const pts = (x.points || []).slice().sort((a, b) => yearOf(a.budgetId) - yearOf(b.budgetId));
      return '<div class="line-card"><div class="ser-row"><label class="ser-color" style="background:' + x.color + '"><input type="color" data-ser-color="' + i + '" value="' + x.color + '"></label>' +
        '<input class="fld sm grow" data-ser-name="' + i + '" value="' + esc(x.name || '') + '" placeholder="' + esc(pointSeriesLabel({ ...x, name: '' }, map)) + '">' +
        '<button class="icon-btn xs" data-del-ser="' + i + '" title="' + esc(t('delete')) + '">' + icon('x') + '</button></div>' +
        '<div class="pt-chips">' + (pts.length ? pts.map((p) => '<span class="pt-chip"><b>' + esc(String(yearOf(p.budgetId) || '?')) + '</b> ' + esc(catLabel(p, map.get(p.budgetId))) +
          '<button data-del-pt="' + i + ':' + p.id + '" title="' + esc(t('delete')) + '">×</button></span>').join('') : '<small class="muted">' + esc(t('noPoints')) + '</small>') + '</div></div>';
    }).join('');
  };
  const lineOpts = () => draft.series.map((x, i) => '<option value="' + i + '">' + esc(t('lineN', { n: i + 1 })) + ' – ' + esc(pointSeriesLabel(x, map)) + '</option>').join('') + '<option value="new">+ ' + esc(t('newLine')) + '</option>';
  // boja koju će dobiti sljedeći podatak/linija (prva neiskorištena iz palete; korisnik je može promijeniti)
  const autoColor = () => { const used = draft.series.map((x) => (x.color || '').toLowerCase()); return PALETTE.find((c) => !used.includes(c.toLowerCase())) || PALETTE[draft.series.length % PALETTE.length]; };
  let nextColor = autoColor();
  const seg = (id, cur, opts, cls) => '<div class="seg ' + (cls || '') + '" id="' + id + '">' + opts.map(([k, l]) => '<button data-v="' + k + '" class="' + (cur === k ? 'on' : '') + '">' + esc(t(l)) + '</button>').join('') + '</div>';
  const res = await sheet({
    title: isNew ? t('newGraph') : t('editGraph'), wide: true,
    body: '<label class="fld-label">' + esc(t('graphName')) + '</label><input class="fld" id="g-name" value="' + esc(draft.name) + '">' +
      '<label class="fld-label">' + esc(t('chartKind')) + '</label>' + seg('g-kind', draft.chart, [['line', 'lineChart'], ['bar', 'barChart'], ['pie', 'pieChart']], 'three') +
      '<div id="g-pv-wrap"' + (draft.chart === 'pie' ? '' : ' hidden') + '><p class="muted small">' + esc(t('pieHint')) + '</p><label class="fld-label">' + esc(t('pieValues')) + '</label>' + seg('g-pv', draft.pieValues, [['money', 'pv_money'], ['pct', 'pv_pct'], ['both', 'pv_both']], 'three') + '</div>' +
      '<label class="fld-label">' + esc(t('xAxis')) + '</label>' + seg('g-x', draft.xAxis, [['months', 'xMonths'], ['years', 'xYears']]) +
      '<p class="muted small" id="g-yhint"' + (years() ? '' : ' hidden') + '>' + esc(t('xYearsPointsHint')) + '</p>' +
      '<label class="fld-label" id="g-mlabel">' + esc(t(years() ? 'monthsSummed' : 'monthsToShow')) + '</label>' + seg('g-mmode', draft.monthMode, [['pick', 'monthsPicked'], ['current', 'monthCurrent']]) +
      '<div id="g-mpick"' + (draft.monthMode === 'current' ? ' hidden' : '') + '><div class="chips-head"><button class="link" id="g-all">' + esc(t('all')) + '</button></div><div class="chips" id="g-months">' +
      Array.from({ length: 12 }, (_, m) => '<button data-m="' + m + '" class="' + (draft.months.includes(m) ? 'on' : '') + '">' + esc(monthName(m, true)) + '</button>').join('') + '</div></div>' +
      '<p class="muted small" id="g-mcur"' + (draft.monthMode === 'current' ? '' : ' hidden') + '>' + esc(t('monthCurrentHint', { m: monthName(new Date().getMonth()) })) + '</p>' +
      '<label class="fld-label" id="g-slabel">' + esc(t(years() ? 'linesList' : 'seriesList')) + '</label><div id="g-series">' + seriesHtml() + '</div>' +
      '<div class="card pad add-ser"><b id="s-title">' + esc(t(years() ? 'addPoint' : 'addSeries')) + '</b>' +
      '<div id="s-line-wrap"' + (years() ? '' : ' hidden') + '><label class="fld-label">' + esc(t('toLine')) + '</label><select class="fld" id="s-line">' + lineOpts() + '</select></div>' +
      '<div class="row2"><div><label class="fld-label" id="s-blabel">' + esc(t(years() ? 'budgetYear' : 'budgetSource')) + '</label><select class="fld" id="s-budget">' + budgetOpts(firstBudget) + '</select></div>' +
      '<div><label class="fld-label">' + esc(t('side')) + '</label><select class="fld" id="s-side"><option value="expense">' + esc(t('expenses')) + '</option><option value="income">' + esc(t('income')) + '</option><option value="diff">' + esc(t('difference')) + '</option></select></div></div>' +
      '<label class="fld-label">' + esc(t('titleOrSubtitle')) + '</label><select class="fld" id="s-cat"></select>' +
      '<div class="next-color" id="s-color-row"><span>' + esc(t('nextColor')) + '</span><label class="ser-color big" id="s-color-sw" style="background:' + nextColor + '"><input type="color" id="s-color" value="' + nextColor + '"></label><small class="muted">' + esc(t('nextColorHint')) + '</small></div>' +
      '<button class="btn block" id="s-add">' + icon('plus') + '<span id="s-add-l">' + esc(t(years() ? 'addPoint' : 'addSeries')) + '</span></button><p class="muted small" id="s-hint"' + (years() ? ' hidden' : '') + '>' + esc(t('seriesHint')) + '</p></div>',
    actions: [{ label: t('cancel'), value: null }, { label: t('save'), value: 'ok', cls: 'primary' }],
    onMount: (el) => {
      const q = (x) => el.querySelector(x);
      const refreshCats = () => { q('#s-cat').innerHTML = catOpts(q('#s-budget').value, q('#s-side').value); };
      refreshCats();
      q('#s-budget').onchange = refreshCats; q('#s-side').onchange = refreshCats;
      const segClick = (id, fn) => { q(id).onclick = (e) => { const b = e.target.closest('button'); if (!b) return; q(id).querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b)); fn(b.dataset.v); }; };
      // boja se bira za novu liniju; kod dodavanja točke u postojeću liniju nije potrebna
      const syncColorRow = () => { q('#s-color-row').hidden = years() && q('#s-line').value !== 'new'; };
      const refreshLines = (sel) => { q('#s-line').innerHTML = lineOpts(); q('#s-line').value = sel !== undefined ? String(sel) : (draft.series.length ? String(draft.series.length - 1) : 'new'); syncColorRow(); };
      const redrawSeries = () => { q('#g-series').innerHTML = seriesHtml(); rebind(); };
      const setNext = (c) => { nextColor = c; q('#s-color').value = c; q('#s-color-sw').style.background = c; };
      const setMode = () => {
        const y = years();
        q('#s-line-wrap').hidden = !y; q('#s-hint').hidden = y; q('#g-yhint').hidden = !y;
        q('#g-mlabel').textContent = t(y ? 'monthsSummed' : 'monthsToShow');
        q('#g-slabel').textContent = t(y ? 'linesList' : 'seriesList');
        q('#s-title').textContent = t(y ? 'addPoint' : 'addSeries'); q('#s-add-l').textContent = t(y ? 'addPoint' : 'addSeries');
        q('#s-blabel').textContent = t(y ? 'budgetYear' : 'budgetSource');
        refreshLines(); redrawSeries();
      };
      segClick('#g-kind', (v) => { draft.chart = v; q('#g-pv-wrap').hidden = v !== 'pie'; });
      segClick('#g-pv', (v) => { draft.pieValues = v; });
      segClick('#g-x', (v) => {
        if (v === draft.xAxis) return;
        draft.series = v === 'years' ? seriesToPoints(draft.series, map) : pointsToSeries(draft.series);
        draft.xAxis = v; setMode(); setNext(autoColor());
      });
      segClick('#g-mmode', (v) => { draft.monthMode = v; q('#g-mpick').hidden = v === 'current'; q('#g-mcur').hidden = v !== 'current'; });
      q('#g-months').onclick = (e) => { const b = e.target.closest('button'); if (!b) return; const m = +b.dataset.m; draft.months = draft.months.includes(m) ? draft.months.filter((x) => x !== m) : [...draft.months, m]; b.classList.toggle('on'); };
      q('#g-all').onclick = (e) => { e.preventDefault(); const all = draft.months.length < 12; draft.months = all ? [...Array(12).keys()] : []; q('#g-months').querySelectorAll('button').forEach((x) => x.classList.toggle('on', all)); };
      q('#s-color').oninput = () => setNext(q('#s-color').value);
      q('#s-line').onchange = syncColorRow;
      function rebind() {
        q('#g-series').querySelectorAll('[data-del-ser]').forEach((b) => b.onclick = () => { draft.series.splice(+b.dataset.delSer, 1); redrawSeries(); if (years()) refreshLines(); setNext(autoColor()); });
        q('#g-series').querySelectorAll('[data-ser-color]').forEach((inp) => inp.oninput = () => { draft.series[+inp.dataset.serColor].color = inp.value; inp.parentElement.style.background = inp.value; });
        q('#g-series').querySelectorAll('[data-ser-name]').forEach((inp) => inp.oninput = () => { draft.series[+inp.dataset.serName].name = inp.value; });
        q('#g-series').querySelectorAll('[data-del-pt]').forEach((b) => b.onclick = () => {
          const [i, pid] = b.dataset.delPt.split(':'); const x = draft.series[+i];
          x.points = x.points.filter((p) => p.id !== pid); redrawSeries();
        });
      }
      refreshLines(); rebind(); syncColorRow();
      q('#s-add').onclick = () => {
        const side = q('#s-side').value, [gid, iid] = (q('#s-cat').value || '|').split('|');
        const bid = q('#s-budget').value;
        if (years()) {
          const pt = { id: uid('p'), budgetId: bid, side, gid: gid || null, iid: iid || null };
          let li = q('#s-line').value;
          if (li === 'new') { draft.series.push({ id: uid('s'), name: '', color: nextColor, points: [] }); li = draft.series.length - 1; setNext(autoColor()); }
          const line = draft.series[+li];
          // ista godina u istoj liniji: nova točka zamjenjuje staru (osim ako je ista tablica – onda se zbrajaju)
          line.points = line.points.filter((p) => yearOf(p.budgetId) !== yearOf(bid) || p.budgetId === bid);
          line.points.push(pt);
          redrawSeries(); refreshLines(li);
          // sljedeća tablica čije godine još nema u ovoj liniji
          const have = new Set(line.points.map((p) => yearOf(p.budgetId)));
          const nextB = vis.find((x) => !have.has(yearOf(x.id)));
          if (nextB) { q('#s-budget').value = nextB.id; refreshCats(); }
          toast(t('pointAdded', { y: yearOf(bid) }));
        } else {
          draft.series.push({ id: uid('s'), budgetId: bid, side, gid: gid || null, iid: iid || null, color: nextColor });
          redrawSeries(); setNext(autoColor());
        }
      };
    },
    onAction: (v, el) => {
      if (v !== 'ok') return null;
      draft.name = el.querySelector('#g-name').value.trim() || t('customGraph');
      if (draft.xAxis === 'years') draft.series = draft.series.filter((x) => (x.points || []).length);
      if (!draft.series.length) { toast(t(draft.xAxis === 'years' ? 'noPoints' : 'noSeries')); return false; }
      if (!draft.months.length) draft.months = [...Array(12).keys()];
      delete draft.yearBudgets;
      return draft;
    },
  });
  if (!res) return null;
  const list = graphs();
  const i = list.findIndex((x) => x.id === res.id);
  if (i >= 0) list[i] = res; else list.push(res);
  await saveSettings(); refreshWidgets();
  return res;
}

export async function graphAction(a, d, rerender) {
  const list = graphs();
  if (a === 'graphNew') { const g = await editGraph(newGraph(state.budget ? state.budget.id : (state.index[0] || {}).id), true); if (g) rerender(); return true; }
  const g = list.find((x) => x.id === d.id);
  if (!g) return false;
  if (a === 'graphEdit') { if (await editGraph(g, false)) rerender(); return true; }
  if (a === 'graphFs') { await fullscreenGraph(g); return true; }
  if (a === 'graphWidget') { const { addGraphWidget } = await import('./widgetsView.js'); await addGraphWidget(g.id, true); return true; }
  if (a === 'graphDup') { list.push({ ...clone(g), id: uid('cg'), name: g.name + ' (2)' }); await saveSettings(); rerender(); return true; }
  if (a === 'graphDel') {
    if (!(await confirmDlg(t('delGraphQ', { n: g.name }), { ok: t('delete'), danger: true }))) return true;
    state.settings.customGraphs = list.filter((x) => x !== g); await saveSettings(); refreshWidgets(); rerender(); return true;
  }
  return false;
}
