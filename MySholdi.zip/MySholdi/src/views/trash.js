// Koš za smeće
import { state } from '../state.js';
import { t } from '../i18n.js';
import { esc, fmtDateTime } from '../util.js';
import { icon } from '../icons.js';
import { restore, deleteForever, emptyTrash, daysLeft, TRASH_DAYS } from '../trash.js';
import { confirmDlg, toast } from '../ui.js';
import { app } from '../app.js';

const KIND_IC = { budget: 'table', group: 'folder', item: 'menu', entry: 'coins', netrow: 'wallet' };

export function renderTrash() {
  const list = state.trash;
  const bname = (id) => (state.index.find((x) => x.id === id) || {}).name || t('deletedBudget');
  return '<p class="muted small">' + esc(t('trashHint', { d: TRASH_DAYS })) + '</p>' +
    (list.length ? '<div class="list-actions"><button class="btn danger" data-a="trashEmpty">' + icon('trash') + esc(t('emptyTrash')) + '</button></div>' +
      '<div class="card list">' + list.map((x) => '<div class="entry">' +
        '<div class="entry-ic">' + icon(KIND_IC[x.kind] || 'trash') + '</div>' +
        '<div class="entry-main"><b>' + esc(x.label) + '</b><small>' + esc(t('kind_' + x.kind)) + (x.ctx && x.ctx.budgetId ? ' · ' + esc(bname(x.ctx.budgetId)) : '') + '</small>' +
        '<small>' + esc(t('deletedAt')) + ' ' + esc(fmtDateTime(x.deletedAt)) + ' · ' + esc(t('daysLeft', { d: daysLeft(x) })) + '</small></div>' +
        '<button class="icon-btn sm" data-a="trashRestore" data-id="' + x.id + '" title="' + esc(t('restore')) + '">' + icon('restore') + '</button>' +
        '<button class="icon-btn sm" data-a="trashDelete" data-id="' + x.id + '" title="' + esc(t('deleteForever')) + '">' + icon('x') + '</button></div>').join('') + '</div>'
      : '<div class="empty">' + icon('trash', 'big') + '<p>' + esc(t('trashEmpty')) + '</p></div>');
}

export async function trashAction(a, d) {
  if (a === 'trashRestore') {
    const r = await restore(d.id);
    toast(r.ok ? t('restored') : (r.msg || t('restoreFailed')));
  } else if (a === 'trashDelete') {
    if (!(await confirmDlg(t('deleteForeverQ'), { ok: t('deleteForever'), danger: true }))) return;
    await deleteForever(d.id);
  } else if (a === 'trashEmpty') {
    if (!(await confirmDlg(t('emptyTrashQ'), { ok: t('emptyTrash'), danger: true }))) return;
    await emptyTrash();
  }
  app.rerender();
}
