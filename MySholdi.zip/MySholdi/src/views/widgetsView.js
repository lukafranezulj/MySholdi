// Ekran "Widgets": više widgeta, svaki sa svojim izgledom; dodavanje na početni zaslon
import { state } from '../state.js';
import { t } from '../i18n.js';
import { esc } from '../util.js';
import { icon } from '../icons.js';
import { renderWidget, WIDGET_KINDS, WIDGET_SIZE, THEMES, ACCENTS, CHART_TYPES, dataFor, refreshWidgets, newDesign, ensureDesigns, designName } from '../widgets.js';
import { saveSettings } from '../storage.js';
import { pinWidget, isNative } from '../native.js';
import { app } from '../app.js';
import { sheet, toast, confirmDlg } from '../ui.js';

let selId = null;
const designs = () => { ensureDesigns(); return state.settings.widgetDesigns; };
const nameOf = (d) => designName(d, designs().filter((x) => x.kind === d.kind).indexOf(d));

export function renderWidgets() {
  const list = designs();
  if (!list.find((d) => d.id === selId)) selId = list[0] && list[0].id;
  const cfg = list.find((d) => d.id === selId);
  const opt = (v, l, cur) => '<option value="' + esc(v) + '"' + (String(v) === String(cur ?? '') ? ' selected' : '') + '>' + esc(l) + '</option>';
  const tog = (k, lbl) => '<label class="set-row toggle"><div><b>' + esc(t(lbl)) + '</b></div><input type="checkbox" data-w="' + k + '"' + (cfg[k] ? ' checked' : '') + '><span class="sw"></span></label>';
  return '<p class="muted small">' + esc(t('widgetsIntro')) + '</p>' +
    '<div class="w-list">' + list.map((d) => '<button class="w-chip ' + (d.id === selId ? 'on' : '') + '" data-a="wSel" data-id="' + d.id + '"><canvas data-thumb="' + d.id + '"></canvas><span>' + esc(nameOf(d)) + '</span><small>' + esc(t('w_' + d.kind)) + '</small></button>').join('') +
    '<button class="w-chip add" data-a="wNew">' + icon('plus') + '<span>' + esc(t('newWidget')) + '</span></button></div>' +
    (cfg ? '<div class="w-editor"><div class="w-preview" id="w-prev"></div>' +
      '<div class="w-btns"><button class="btn primary" data-a="wPin">' + icon('pin') + esc(t('addToHome')) + '</button>' +
      '<button class="btn" data-a="wDup">' + icon('copy') + esc(t('duplicate')) + '</button>' +
      '<button class="btn" data-a="wDel">' + icon('trash') + esc(t('delete')) + '</button></div>' +
      '<p class="muted small">' + esc(t('w_' + cfg.kind + '_hint')) + '</p>' +
      '<h4 class="sec-title">' + esc(t('design')) + '</h4><div class="card pad wform">' +
      '<label class="fld-label">' + esc(t('widgetName')) + '</label><input class="fld" data-w="name" value="' + esc(cfg.name || '') + '" placeholder="' + esc(nameOf(cfg)) + '">' +
      (cfg.kind !== 'add1' ? '<label class="fld-label">' + esc(t('budgetSource')) + '</label><select class="fld" data-w="budgetId">' + opt('', t('activeBudget'), cfg.budgetId || '') +
        state.index.filter((x) => !(state.meta[x.id] && state.meta[x.id].hidden)).map((x) => opt(x.id, x.name, cfg.budgetId)).join('') + '</select>' : '') +
      '<label class="fld-label">' + esc(t('widgetTitle')) + '</label><input class="fld" data-w="title" value="' + esc(cfg.title || '') + '" placeholder="' + esc(t('automatic')) + '">' +
      '<label class="fld-label">' + esc(t('theme')) + '</label><div class="seg four" id="w-theme">' + THEMES.map((th) => '<button data-v="' + th + '" class="' + (cfg.theme === th ? 'on' : '') + '">' + esc(t('theme_' + th)) + '</button>').join('') + '</div>' +
      '<label class="fld-label">' + esc(t('accentColor')) + '</label><div class="swatches" id="w-acc">' + ACCENTS.map((c) => '<button data-v="' + c + '" style="background:' + c + '" class="' + (cfg.accent === c ? 'on' : '') + '"></button>').join('') +
      '<label class="sw-custom"><input type="color" data-w="accent" value="' + esc(cfg.accent) + '"></label></div>' +
      '<label class="fld-label">' + esc(t('opacity')) + ' <span id="w-op">' + cfg.opacity + ' %</span></label><input type="range" min="20" max="100" step="5" data-w="opacity" value="' + cfg.opacity + '">' +
      '<label class="fld-label">' + esc(t('cornerRadius')) + ' <span id="w-rad">' + cfg.radius + '</span></label><input type="range" min="0" max="' + (cfg.kind === 'add1' ? 75 : 40) + '" step="2" data-w="radius" value="' + cfg.radius + '">' +
      (cfg.kind === 'month' ? tog('showDiff', 'showDiff') + tog('showDaily', 'showDaily') : '') +
      (cfg.kind === 'add1' || cfg.kind === 'add2' ? '<label class="fld-label">' + esc(t('entryType')) + '</label><select class="fld" data-w="entryType">' + opt('expense', t('expense'), cfg.entryType) + opt('income', t('incomeOne'), cfg.entryType) + '</select>' + (cfg.kind === 'add2' ? tog('showMonth', 'showMonthTotal') : '') : '') +
      (cfg.kind === 'chart' ? '<label class="fld-label">' + esc(t('chartType')) + '</label><select class="fld" data-w="chart">' + CHART_TYPES.map((c) => opt(c, t('chart_' + c), cfg.chart)).join('') + '</select>' +
        (cfg.chart === 'custom' ? '<label class="fld-label">' + esc(t('customGraph')) + '</label><select class="fld" data-w="graphId">' + opt('', '—', cfg.graphId || '') +
          (state.settings.customGraphs || []).map((g) => opt(g.id, g.name, cfg.graphId)).join('') + '</select>' +
          ((state.settings.customGraphs || []).length ? '' : '<p class="muted small">' + esc(t('noCustomGraphs')) + '</p>') : '') : '') +
      (cfg.kind === 'quick' ? '<label class="fld-label">' + esc(t('entriesCount')) + '</label><select class="fld" data-w="count">' + [2, 3, 4].map((n) => opt(String(n), String(n), String(cfg.count))).join('') + '</select>' : '') +
      '</div></div>' : '');
}

async function drawCanvas(cv, d, maxW) {
  const cnv = renderWidget(d, await dataFor(d), 2);
  const [W, H] = WIDGET_SIZE[d.kind];
  cv.width = cnv.width; cv.height = cnv.height;
  cv.getContext('2d').drawImage(cnv, 0, 0);
  const scale = Math.min(1, maxW / W);
  cv.style.width = W * scale + 'px'; cv.style.height = H * scale + 'px';
}
async function drawPreview(root) {
  const el = root.querySelector('#w-prev'); if (!el) return;
  const d = designs().find((x) => x.id === selId); if (!d) return;
  const cv = document.createElement('canvas');
  el.innerHTML = ''; el.appendChild(cv);
  await drawCanvas(cv, d, Math.min(el.clientWidth - 24, WIDGET_SIZE[d.kind][0] * (d.kind === 'add1' ? 1 : 1.25)));
  const th = root.querySelector('[data-thumb="' + d.id + '"]'); if (th) drawCanvas(th, d, 92);
}

export function mountWidgets(root, rerender) {
  designs().forEach((d) => { const th = root.querySelector('[data-thumb="' + d.id + '"]'); if (th) drawCanvas(th, d, 92); });
  drawPreview(root);
  const cfg = () => designs().find((d) => d.id === selId);
  if (!cfg()) return;
  const changed = (full) => { saveSettings(); if (full) rerender(); else drawPreview(root); refreshWidgets(); };
  const th = root.querySelector('#w-theme');
  if (th) th.onclick = (e) => { const b = e.target.closest('button'); if (!b) return; cfg().theme = b.dataset.v; th.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b)); changed(); };
  const acc = root.querySelector('#w-acc');
  if (acc) acc.onclick = (e) => { const b = e.target.closest('button'); if (!b) return; cfg().accent = b.dataset.v; acc.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === b)); changed(); };
  root.querySelectorAll('[data-w]').forEach((inp) => {
    const ev = inp.tagName === 'SELECT' || inp.type === 'checkbox' ? 'change' : 'input';
    inp.addEventListener(ev, () => {
      const k = inp.dataset.w;
      let v = inp.type === 'checkbox' ? inp.checked : inp.value;
      if (k === 'opacity' || k === 'radius' || k === 'count') v = +v;
      if ((k === 'budgetId' || k === 'graphId') && !v) v = null;
      cfg()[k] = v;
      if (k === 'opacity') root.querySelector('#w-op').textContent = v + ' %';
      if (k === 'radius') root.querySelector('#w-rad').textContent = v;
      if (k === 'accent') root.querySelectorAll('#w-acc button').forEach((x) => x.classList.remove('on'));
      if (k === 'name') { const ch = root.querySelector('.w-chip.on span'); if (ch) ch.textContent = nameOf(cfg()); }
      changed(k === 'chart');
    });
  });
}

// Novi widget s grafom iz kartice Custom grafovi
export async function addGraphWidget(graphId, open = true) {
  const g = (state.settings.customGraphs || []).find((x) => x.id === graphId); if (!g) return;
  const nd = { ...newDesign('chart'), chart: 'custom', graphId, name: g.name };
  designs().push(nd); selId = nd.id; await saveSettings(); refreshWidgets();
  toast(t('graphWidgetAdded', { n: g.name }));
  if (open) app.go('widgets');
}

export async function widgetsAction(a, d, rerender) {
  const list = designs();
  if (a === 'wSel') { selId = d.id; return rerender(); }
  if (a === 'wNew') {
    const acts = WIDGET_KINDS.map((x) => ({ label: t('w_' + x) + ' – ' + t('w_' + x + '_size'), value: x }));
    acts.push({ label: t('w_customGraph') + ' – ' + t('w_chart_size'), value: 'cg', cls: 'primary' });
    const k = await sheet({ title: t('newWidget'), body: '', cls: 'menu-sheet', actions: acts });
    if (!k) return;
    if (k === 'cg') {
      const gs = state.settings.customGraphs || [];
      if (!gs.length) { toast(t('noCustomGraphs')); return; }
      const gid = gs.length === 1 ? gs[0].id : await sheet({ title: t('chooseGraph'), body: '', cls: 'menu-sheet', actions: gs.map((g) => ({ label: g.name, value: g.id })) });
      if (!gid) return;
      await addGraphWidget(gid, false); return rerender();
    }
    const nd = newDesign(k); list.push(nd); selId = nd.id; await saveSettings(); refreshWidgets(); return rerender();
  }
  const cur = list.find((x) => x.id === selId); if (!cur) return;
  if (a === 'wDup') { const nd = { ...JSON.parse(JSON.stringify(cur)), id: newDesign(cur.kind).id, name: '' }; list.push(nd); selId = nd.id; await saveSettings(); refreshWidgets(); return rerender(); }
  if (a === 'wDel') {
    if (list.filter((x) => x.kind === cur.kind).length <= 1) { toast(t('lastDesign')); return; }
    if (!(await confirmDlg(t('delWidgetQ', { n: nameOf(cur) }), { ok: t('delete'), danger: true }))) return;
    state.settings.widgetDesigns = list.filter((x) => x !== cur); selId = null; await saveSettings(); refreshWidgets(); return rerender();
  }
  if (a === 'wPin') {
    let r = null;
    refreshWidgets.flush();
    try { r = await pinWidget(cur.kind, cur.id); } catch (e) { r = { supported: false }; }
    if (r && r.supported) { toast(t('pinRequested')); return; }
    await sheet({
      title: t('addToHome'),
      body: '<p class="dlg-text">' + esc(isNative ? t('pinManual') : t('pinWeb')) + '</p><ol class="steps"><li>' + esc(t('pinStep1')) + '</li><li>' + esc(t('pinStep2')) + '</li><li>' + esc(t('pinStep3', { w: t('w_' + cur.kind) })) + '</li><li>' + esc(t('pinStep4')) + '</li></ol>',
      actions: [{ label: t('ok'), value: true, cls: 'primary' }],
    });
  }
}
