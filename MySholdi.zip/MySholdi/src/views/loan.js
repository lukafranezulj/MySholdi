// Kalkulator kredita: po rati, po iznosu, po trajanju (+ napredno: inflacija, naknada, otplatni plan)
import { state } from '../state.js';
import { t } from '../i18n.js';
import { esc, money, fmtNum, parseAmount, debounce, clamp } from '../util.js';
import { icon } from '../icons.js';
import { computeLoan } from '../loanCalc.js';
import { saveSettings } from '../storage.js';

const FIELDS = {
  amount: { min: 0, max: 1000000, step: 500, unit: 'cur' },
  payment: { min: 0, max: 10000, step: 5, unit: 'cur' },
  rate: { min: 0, max: 25, step: 0.05, unit: '%' },
  term: { min: 1, max: 480, step: 1, unit: 'm' },
  inflation: { min: -5, max: 20, step: 0.1, unit: '%' },
  fee: { min: 0, max: 5, step: 0.05, unit: '%' },
};
const MODE_FIELDS = { payment: ['payment', 'rate', 'term'], amount: ['amount', 'rate', 'term'], term: ['amount', 'rate', 'payment'] };
const saveLater = debounce(() => saveSettings(), 600);

const L = () => state.settings.loan;
const termMonths = () => Math.round((+L().years || 0) * 12 + (+L().months || 0));
const fmtTerm = (m) => {
  const y = Math.floor(m / 12), mm = m % 12;
  return (y ? y + ' ' + t(y === 1 ? 'yearOne' : 'yearsShort') : '') + (y && mm ? ' ' : '') + (mm || !y ? mm + ' ' + t('monthsShort') : '');
};

function field(k) {
  const f = FIELDS[k];
  const lbl = { amount: 'loanAmount', payment: 'monthlyBudget', rate: 'interestRate', term: 'loanTerm', inflation: 'inflation', fee: 'processingFee' }[k];
  if (k === 'term') {
    const m = termMonths();
    return '<div class="lfield"><div class="lf-top"><label>' + esc(t(lbl)) + '</label><div class="term-in">' +
      '<input class="fld sm" data-term="years" inputmode="numeric" value="' + Math.floor(m / 12) + '"><span>' + esc(t('yearsShort')) + '</span>' +
      '<input class="fld sm" data-term="months" inputmode="numeric" value="' + (m % 12) + '"><span>' + esc(t('monthsShort')) + '</span></div></div>' +
      '<input type="range" data-range="term" min="' + f.min + '" max="' + f.max + '" step="1" value="' + clamp(m, f.min, f.max) + '"><div class="lf-scale"><span>1 ' + esc(t('monthsShort')) + '</span><span>40 ' + esc(t('yearsShort')) + '</span></div></div>';
  }
  const v = +L()[k] || 0;
  const unit = f.unit === 'cur' ? state.settings.currency : '%';
  return '<div class="lfield"><div class="lf-top"><label>' + esc(t(lbl)) + '</label><div class="num-in"><input class="fld sm" data-num="' + k + '" inputmode="decimal" value="' + esc(fmtNum(v, f.step < 1 ? 2 : 0)) + '"><span>' + esc(unit) + '</span></div></div>' +
    '<input type="range" data-range="' + k + '" min="' + f.min + '" max="' + Math.max(f.max, v) + '" step="' + f.step + '" value="' + v + '"></div>';
}

export function renderLoan() {
  const mode = L().mode;
  const modes = [['payment', 'modePayment', 'modePaymentHint'], ['amount', 'modeAmount', 'modeAmountHint'], ['term', 'modeTerm', 'modeTermHint']];
  return '<div class="seg three" id="loan-mode">' + modes.map(([k, l], i) => '<button data-mode="' + k + '" class="' + (k === mode ? 'on' : '') + '">' + (i + 1) + '. ' + esc(t(l)) + '</button>').join('') + '</div>' +
    '<p class="muted small">' + esc(t(modes.find((x) => x[0] === mode)[2])) + '</p>' +
    '<div class="card pad">' + MODE_FIELDS[mode].map(field).join('') + '</div>' +
    '<div id="loan-results"></div>' +
    '<details class="card pad adv" ' + (L().advanced ? 'open' : '') + ' id="loan-adv"><summary>' + icon('settings') + esc(t('advanced')) + '</summary>' +
    field('inflation') + field('fee') + '<div id="loan-adv-res"></div></details>' +
    '<details class="card pad" id="loan-plan"><summary>' + icon('table') + esc(t('amortization')) + '</summary><div id="loan-plan-body"></div></details>' +
    '<p class="muted small">' + esc(t('loanDisclaimer')) + '</p>';
}

function results() {
  const r = computeLoan(L());
  const mode = L().mode;
  const row = (k, v, cls = '') => '<div class="res ' + cls + '"><span>' + esc(t(k)) + '</span><b>' + v + '</b></div>';
  if (r.error) return '<div class="card pad warnbox">' + icon('warn') + esc(t(r.error, { a: money(r.amount * (+L().rate || 0) / 1200) })) + '</div>';
  return '<div class="card pad results">' +
    row('loanAmount', money(r.amount), mode === 'payment' ? 'hl' : '') +
    row('loanTerm', fmtTerm(r.months), mode === 'term' ? 'hl' : '') +
    row('interestRate', fmtNum(+L().rate || 0) + ' %') +
    row('monthlyPayment', money(r.payment), mode === 'amount' ? 'hl' : '') +
    (mode !== 'amount' ? row('monthlyBudget', money(+L().payment || 0)) : '') +
    row('monthlyAnnuity', money(r.payment) + '<small>' + esc(t('firstSplit', { p: money(r.firstPrincipal), i: money(r.firstInterest) })) + '</small>') +
    (mode === 'term' && Math.abs(r.lastPay - r.payment) > 0.01 ? row('lastPayment', money(r.lastPay)) : '') +
    row('totalPaid', money(r.total)) +
    row('totalInterest', money(r.interest), 'exp') +
    '<div class="split-bar"><i style="width:' + (r.total ? r.amount / r.total * 100 : 0) + '%"></i></div>' +
    '<div class="split-lg"><span><i class="p"></i>' + esc(t('principal')) + ' ' + fmtNum(r.total ? r.amount / r.total * 100 : 0, 1) + ' %</span><span><i class="k"></i>' + esc(t('interest')) + ' ' + fmtNum(r.total ? r.interest / r.total * 100 : 0, 1) + ' %</span></div>' +
    '</div>';
}
function advResults() {
  const r = computeLoan(L());
  if (r.error || !r.total) return '';
  const row = (k, v, cls = '') => '<div class="res ' + cls + '"><span>' + esc(t(k)) + '</span><b>' + v + '</b></div>';
  return '<div class="results adv-res">' +
    row('realCost', money(r.realCost), 'hl') +
    row('realInterest', money(r.realInterest)) +
    row('nominalTotal', money(r.total)) +
    (r.feeAmt ? row('feeAmount', money(r.feeAmt)) + row('totalWithFee', money(r.totalWithFee)) : '') +
    row('eks', isNaN(r.eks) ? '—' : fmtNum(r.eks) + ' %') +
    '<p class="muted small">' + esc(t('realCostHint', { p: fmtNum(+L().inflation || 0, 1) })) + '</p></div>';
}
function plan() {
  const r = computeLoan(L());
  if (!r.years.length) return '<p class="muted">—</p>';
  return '<div class="scroll"><table class="grid plan"><thead><tr><th>' + esc(t('yearCol')) + '</th><th>' + esc(t('paid')) + '</th><th>' + esc(t('principal')) + '</th><th>' + esc(t('interest')) + '</th><th>' + esc(t('remaining')) + '</th></tr></thead><tbody>' +
    r.years.map((y) => '<tr><td>' + y.y + '.</td><td>' + fmtNum(y.pay) + '</td><td>' + fmtNum(y.principal) + '</td><td>' + fmtNum(y.interest) + '</td><td>' + fmtNum(y.balance) + '</td></tr>').join('') + '</tbody></table></div>';
}

export function mountLoan(root, rerender) {
  const upd = () => {
    root.querySelector('#loan-results').innerHTML = results();
    root.querySelector('#loan-adv-res').innerHTML = advResults();
    const pb = root.querySelector('#loan-plan-body'); if (root.querySelector('#loan-plan').open) pb.innerHTML = plan();
    saveLater();
  };
  upd();
  root.querySelector('#loan-mode').onclick = (e) => { const b = e.target.closest('button'); if (!b) return; L().mode = b.dataset.mode; saveSettings(); rerender(); };
  root.querySelector('#loan-adv').addEventListener('toggle', (e) => { L().advanced = e.target.open; saveLater(); });
  root.querySelector('#loan-plan').addEventListener('toggle', (e) => { if (e.target.open) root.querySelector('#loan-plan-body').innerHTML = plan(); });
  const setTermInputs = () => {
    const m = termMonths();
    const y = root.querySelector('[data-term="years"]'), mm = root.querySelector('[data-term="months"]');
    if (y && document.activeElement !== y) y.value = Math.floor(m / 12);
    if (mm && document.activeElement !== mm) mm.value = m % 12;
  };
  root.querySelectorAll('input[data-range]').forEach((rg) => rg.addEventListener('input', () => {
    const k = rg.dataset.range, v = +rg.value;
    if (k === 'term') { L().years = Math.floor(v / 12); L().months = v % 12; setTermInputs(); }
    else { L()[k] = v; const n = root.querySelector('[data-num="' + k + '"]'); if (n) n.value = fmtNum(v, FIELDS[k].step < 1 ? 2 : 0); }
    upd();
  }));
  root.querySelectorAll('input[data-num]').forEach((inp) => {
    inp.addEventListener('focus', () => setTimeout(() => inp.select(), 0));
    inp.addEventListener('input', () => {
      const k = inp.dataset.num, v = parseAmount(inp.value);
      if (v === null || isNaN(v)) return;
      L()[k] = v;
      const rg = root.querySelector('[data-range="' + k + '"]');
      if (rg) { if (v > +rg.max) rg.max = v; rg.value = v; }
      upd();
    });
    inp.addEventListener('blur', () => { inp.value = fmtNum(+L()[inp.dataset.num] || 0, FIELDS[inp.dataset.num].step < 1 ? 2 : 0); });
  });
  root.querySelectorAll('input[data-term]').forEach((inp) => {
    inp.addEventListener('focus', () => setTimeout(() => inp.select(), 0));
    inp.addEventListener('input', () => {
      const y = Math.max(0, parseInt(root.querySelector('[data-term="years"]').value, 10) || 0);
      const m = Math.max(0, parseInt(root.querySelector('[data-term="months"]').value, 10) || 0);
      const tot = clamp(y * 12 + m, 1, 600);
      L().years = Math.floor(tot / 12); L().months = tot % 12;
      const rg = root.querySelector('[data-range="term"]'); if (rg) rg.value = Math.min(tot, 480);
      upd();
    });
    inp.addEventListener('blur', setTermInputs);
  });
}
