// Postavke: jezik, valuta, spremanje i sinkronizacija, mjesta pohrane
import { state } from '../state.js';
import { t, setLang } from '../i18n.js';
import { esc, fmtDateTime, chartColor, debounce } from '../util.js';
import { PALETTE, applyPalette } from '../charts.js';
import { icon } from '../icons.js';
import { saveSettings, appFolderUri } from '../storage.js';
import { metaOf, saveNow, syncStatus, retryPending } from '../sync.js';
import { getInfo, isNative } from '../native.js';
import { linkCreate, unlink, importFromFile } from '../cloud.js';
import { readBudget } from '../storage.js';
import { confirmDlg, toast } from '../ui.js';
import { statusBadge } from './budgets.js';
import { app } from '../app.js';
import { APP_VERSION } from '../config.js';
import { lockEnabled, setupPin, disableLock } from '../lock.js';
import { biometricAvailable } from '../native.js';

let bioOk = null;

const CURRENCIES = ['EUR', 'USD', 'GBP', 'CHF', 'BAM', 'RSD', 'HUF', 'PLN', 'CZK', 'SEK', 'NOK', 'DKK', 'CAD', 'AUD', 'JPY'];
let folder = null;

export function renderSettings() {
  const s = state.settings;
  const custom = !CURRENCIES.includes(s.currency);
  const tog = (k, lbl, hint) => '<label class="set-row toggle"><div><b>' + esc(t(lbl)) + '</b>' + (hint ? '<small>' + esc(t(hint)) + '</small>' : '') + '</div>' +
    '<input type="checkbox" data-set="' + k + '"' + (s[k] ? ' checked' : '') + '><span class="sw"></span></label>';
  return '<h4 class="sec-title">' + esc(t('general')) + '</h4><div class="card">' +
    '<div class="set-row"><div><b>' + esc(t('language')) + '</b></div><div class="seg sm" id="set-lang">' +
    '<button data-v="hr" class="' + (s.lang === 'hr' ? 'on' : '') + '">Hrvatski</button><button data-v="en" class="' + (s.lang === 'en' ? 'on' : '') + '">English</button></div></div>' +
    '<div class="set-row"><div><b>' + esc(t('currency')) + '</b><small>' + esc(t('currencyHint')) + '</small></div><div class="cur-pick">' +
    '<select class="fld sm" id="set-cur">' + CURRENCIES.map((c) => '<option' + (c === s.currency ? ' selected' : '') + '>' + c + '</option>').join('') +
    '<option value="__custom"' + (custom ? ' selected' : '') + '>' + esc(t('customCurrency')) + '</option></select>' +
    '<input class="fld sm" id="set-cur-custom" maxlength="8" placeholder="KM" value="' + esc(custom ? s.currency : '') + '"' + (custom ? '' : ' hidden') + '></div></div>' +

    '<div class="set-row"><div><b>' + esc(t('layoutMode')) + '</b><small>' + esc(t('layoutHint')) + '</small></div></div>' +
    '<div class="set-row"><div class="seg four grow" id="set-layout">' + [['auto', 'layoutAuto'], ['phone', 'layoutPhone'], ['tablet', 'layoutTablet'], ['pc', 'layoutPc']].map(([v, l]) =>
      '<button data-v="' + v + '" class="' + ((s.layout || 'auto') === v ? 'on' : '') + '">' + esc(t(l)) + '</button>').join('') + '</div></div>' +
    '<div class="set-row"><div><b>' + esc(t('yourName')) + '</b><small>' + esc(t('yourNameHint')) + '</small></div><input class="fld sm wide-in" id="set-user" maxlength="30" value="' + esc(s.userName || '') + '"></div></div>' +

    '<h4 class="sec-title">' + esc(t('tablesSection')) + '</h4><div class="card">' +
    '<label class="set-row toggle"><div><b>' + esc(t('showNetSetting')) + '</b><small>' + esc(t('showNetHint')) + '</small></div><input type="checkbox" data-set="showNet"' + (s.showNet ? ' checked' : '') + '><span class="sw"></span></label>' +
    '<label class="set-row toggle"><div><b>' + esc(t('avgZerosSetting')) + '</b><small>' + esc(t('avgZerosHint')) + '</small></div><input type="checkbox" data-set="avgIncludeZeros"' + (s.avgIncludeZeros ? ' checked' : '') + '><span class="sw"></span></label>' +
    '</div>' +

    '<h4 class="sec-title">' + esc(t('chartColors')) + '</h4><div class="card">' +
    [['income', 'income'], ['expense', 'expenses'], ['diff', 'difference']].map(([k, l]) => '<div class="set-row"><div><b>' + esc(t(l)) + '</b></div><label class="color-pick" style="background:' + esc(chartColor(k)) + '"><input type="color" data-color="' + k + '" value="' + esc(chartColor(k)) + '"></label></div>').join('') +
    '<div class="set-row col"><div class="grow"><b>' + esc(t('categoryPalette')) + '</b><small>' + esc(t('categoryPaletteHint')) + '</small><div class="pal-row">' +
    PALETTE.map((c, i) => '<label class="color-pick sm" style="background:' + c + '"><input type="color" data-pal="' + i + '" value="' + c + '"></label>').join('') + '</div>' +
    '<button class="btn small ghost" data-a="resetColors">' + icon('restore') + esc(t('resetColors')) + '</button></div></div></div>' +

    '<h4 class="sec-title">' + esc(t('security')) + '</h4><div class="card">' +
    '<label class="set-row toggle"><div><b>' + esc(t('lockApp')) + '</b><small>' + esc(t('lockAppHint')) + '</small></div><input type="checkbox" id="set-lock"' + (lockEnabled() ? ' checked' : '') + '><span class="sw"></span></label>' +
    (lockEnabled() ? '<label class="set-row toggle' + (bioOk === false ? ' disabled' : '') + '"><div><b>' + esc(t('biometric')) + '</b><small>' + esc(bioOk === false ? t('biometricNA') : t('biometricHint')) + '</small></div><input type="checkbox" id="set-bio"' + (s.lock && s.lock.biometric ? ' checked' : '') + (bioOk === false ? ' disabled' : '') + '><span class="sw"></span></label>' +
      '<div class="set-row"><div><b>' + esc(t('lockAfter')) + '</b></div><select class="fld sm" id="set-after">' + [[0, 'lockNow'], [60, 'lock1m'], [300, 'lock5m']].map(([v, k]) => '<option value="' + v + '"' + ((s.lock.after || 0) === v ? ' selected' : '') + '>' + esc(t(k)) + '</option>').join('') + '</select></div>' +
      '<div class="set-row"><div><b>' + esc(t('changePin')) + '</b><small>' + esc(t('pinForgot')) + '</small></div><button class="btn small" data-a="setPin">' + icon('lock') + esc(t('changePin')) + '</button></div>' : '') +
    '</div>' +

    '<h4 class="sec-title">' + esc(t('saving')) + '</h4><div class="card">' +
    tog('autosave', 'autosave', 'autosaveHint') + tog('notifyFailures', 'notifyFailures', 'notifyFailuresHint') +
    tog('sharedOfflineReadOnly', 'sharedOfflineSetting', 'sharedOfflineHint') + '</div>' +

    '<h4 class="sec-title">' + esc(t('storage')) + '</h4><div class="card">' +
    '<div class="set-row col"><div class="st-ic">' + icon('folder') + '</div><div><b>' + esc(t('appFolder')) + '</b><small class="mono" id="app-folder">' + esc(folder || '…') + '</small>' +
    '<small>' + esc(t('appFolderHint')) + '</small></div></div>' +
    '<div class="set-row col"><div class="st-ic">' + icon('cloud') + '</div><div><b>' + esc(t('cloudAndLocal')) + '</b><small>' + esc(t('cloudHint')) + '</small></div></div>' +
    state.index.filter((x) => !metaOf(x.id).hidden).map((x) => {
      const m = metaOf(x.id);
      return '<div class="store-row"><div class="grow"><b>' + esc(x.name) + '</b>' + statusBadge(x.id) +
        (m.link ? '<small class="mono">' + esc(m.link.name || '') + '</small>' : '') +
        (m.lastCloudAt ? '<small>' + esc(t('lastCloudSave')) + ': ' + esc(fmtDateTime(m.lastCloudAt)) + '</small>' : '') +
        (m.pending && m.lastError ? '<small class="bad">' + esc(m.lastError) + '</small>' : '') + '</div>' +
        '<div class="store-btns">' +
        '<button class="btn small" data-a="setLink" data-id="' + x.id + '">' + icon('link') + esc(t(m.link ? 'changeLocation' : 'linkCloud')) + '</button>' +
        (m.link ? '<button class="btn small" data-a="setSave" data-id="' + x.id + '">' + icon('upload') + esc(t('saveNow')) + '</button>' +
          '<button class="btn small ghost" data-a="setUnlink" data-id="' + x.id + '">' + icon('unlink') + esc(t('unlink')) + '</button>' : '') +
        '</div></div>';
    }).join('') +
    '<div class="store-row"><button class="btn block" data-a="setImport">' + icon('download') + esc(t('loadFromFile')) + '</button></div>' +
    (Object.values(state.meta).some((m) => m.pending) ? '<div class="store-row"><button class="btn block primary" data-a="setRetry">' + icon('restore') + esc(t('retryAll')) + '</button></div>' : '') +
    '</div>' +
    '<h4 class="sec-title">' + esc(t('about')) + '</h4><div class="card"><div class="set-row"><div><b>MySholdi</b><small>' + esc(t('version')) + ' ' + APP_VERSION + ' · ' + (isNative ? 'Android' : 'Web') + '</small><small>' + esc(t('aboutText')) + '</small></div></div></div>';
}

export function mountSettings(root) {
  if (!folder) {
    Promise.all([appFolderUri(), getInfo()]).then(([uri, info]) => {
      folder = (isNative && info.filesDir ? info.filesDir + '/MySholdi' : uri) || info.filesDir;
      const el = document.getElementById('app-folder'); if (el) el.textContent = folder;
    });
  }
  root.querySelector('#set-lang').onclick = async (e) => {
    const b = e.target.closest('button'); if (!b) return;
    state.settings.lang = b.dataset.v; setLang(b.dataset.v); await saveSettings(); app.rerender(); app.refreshWidgets();
  };
  const cur = root.querySelector('#set-cur'), cc = root.querySelector('#set-cur-custom');
  cur.onchange = async () => {
    if (cur.value === '__custom') { cc.hidden = false; cc.focus(); return; }
    cc.hidden = true; state.settings.currency = cur.value; await saveSettings(); app.refreshWidgets(); toast(t('saved'));
  };
  cc.onchange = async () => { const v = cc.value.trim(); if (!v) return; state.settings.currency = v; await saveSettings(); app.refreshWidgets(); toast(t('saved')); };
  root.querySelectorAll('[data-set]').forEach((c) => c.onchange = async () => { state.settings[c.dataset.set] = c.checked; await saveSettings(); app.refreshWidgets(); });
  // boje grafova
  root.querySelectorAll('[data-color]').forEach((inp) => inp.oninput = () => {
    state.settings.colors[inp.dataset.color] = inp.value; inp.parentElement.style.background = inp.value; saveColors();
  });
  root.querySelectorAll('[data-pal]').forEach((inp) => inp.oninput = () => {
    const pal = [...PALETTE]; pal[+inp.dataset.pal] = inp.value; state.settings.colors.palette = pal; applyPalette(pal);
    inp.parentElement.style.background = inp.value; saveColors();
  });
  root.querySelector('#set-layout').onclick = async (e) => {
    const b = e.target.closest('button'); if (!b) return;
    state.settings.layout = b.dataset.v; await saveSettings(); app.applyLayout(); app.rerender();
  };
  const user = root.querySelector('#set-user');
  user.onchange = async () => { state.settings.userName = user.value.trim(); await saveSettings(); toast(t('saved')); };
  if (bioOk === null) biometricAvailable().then((ok) => { bioOk = ok; if (lockEnabled()) app.rerender(); });
  root.querySelector('#set-lock').onchange = async (e) => {
    if (e.target.checked) { if (!(await setupPin())) e.target.checked = false; else toast(t('lockOn')); }
    else await disableLock();
    app.rerender();
  };
  const bio = root.querySelector('#set-bio');
  if (bio) bio.onchange = async () => { state.settings.lock.biometric = bio.checked; await saveSettings(); };
  const after = root.querySelector('#set-after');
  if (after) after.onchange = async () => { state.settings.lock.after = +after.value; await saveSettings(); };
}

const saveColors = debounce(() => { saveSettings(); app.refreshWidgets(); }, 400);

export async function settingsAction(a, d) {
  if (a === 'resetColors') {
    state.settings.colors = { income: '#16a34a', expense: '#dc2626', diff: '#2563eb', palette: null };
    applyPalette(null); await saveSettings(); app.refreshWidgets(); return app.rerender();
  }
  if (a === 'setPin') { if (await setupPin()) toast(t('saved')); return; }
  if (a === 'setImport') { const b = await importFromFile(); if (b) await app.openBudget(b.id); return; }
  if (a === 'setRetry') { await retryPending(); toast(Object.values(state.meta).some((m) => m.pending) ? t('syncFailShort') : t('syncOk')); return app.rerender(); }
  const b = state.budget && state.budget.id === d.id ? state.budget : await readBudget(d.id);
  if (!b) return;
  if (a === 'setLink') await linkCreate(b);
  else if (a === 'setSave') { const r = await saveNow(b); toast(t(r.ok ? 'syncOk' : 'syncFailShort')); }
  else if (a === 'setUnlink') { if (await confirmDlg(t('unlinkQ'))) await unlink(d.id); }
  app.rerender();
  void syncStatus;
}
