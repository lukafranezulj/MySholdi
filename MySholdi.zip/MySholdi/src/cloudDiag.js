// Kad spremanje u oblak ne uspije: izbornik (nova lokacija, provjera pristupa, odspajanje) i provjera korak po korak
import { t } from './i18n.js';
import { esc, fmtDateTime } from './util.js';
import { metaOf, pushCloud, refreshOnline } from './sync.js';
import { linkCreate, unlink } from './cloud.js';
import { checkDocument, readDocument, appInstalled, isNative } from './native.js';
import { normalizeBudget } from './model.js';
import { sheet, confirmDlg, toast } from './ui.js';
import { app } from './app.js';

export async function syncMenu(b) {
  const v = await sheet({
    title: t('syncProblem'), body: '', cls: 'menu-sheet',
    actions: [
      { label: t('retry'), value: 'retry' },
      { label: t('saveNewLocation'), value: 'new', cls: 'primary' },
      { label: t('checkAccess'), value: 'check' },
      { label: t('unlinkLocalOnly'), value: 'unlink' },
    ],
  });
  if (v === 'retry') { const r = await pushCloud(b.id); toast(t(r.ok ? 'syncOk' : r.offline ? 'savedLocalOffline' : 'syncFailShort')); }
  if (v === 'new') { await linkCreate(b); }
  if (v === 'check') return checkAccess(b);
  if (v === 'unlink' && await confirmDlg(t('unlinkQ'))) { await unlink(b.id); toast(t('savedLocal')); }
  app.rerender();
}

// Provjera pristupa datoteci u oblaku: pokazuje do kojeg koraka sve radi i gdje zapinje
export async function checkAccess(b) {
  const m = metaOf(b.id);
  const steps = [];
  const add = (ok, label, detail = '', hint = '') => steps.push({ ok, label, detail, hint });
  const online = await refreshOnline();
  add(online, t('chkInternet'), '', t('chkInternetHint'));
  if (!m.link) { add(false, t('chkLinked'), '', t('chkLinkedHint')); return showSteps(b, steps); }
  add(true, t('chkLinked'), m.link.provider + ' · ' + (m.link.name || ''));
  const pkg = /OneDrive/.test(m.link.provider) ? 'com.microsoft.skydrive' : /Drive/.test(m.link.provider) ? 'com.google.android.apps.docs' : /Dropbox/.test(m.link.provider) ? 'com.dropbox.android' : null;
  if (pkg && isNative) add(await appInstalled(pkg), t('chkApp', { p: m.link.provider }), '', t('chkAppHint', { p: m.link.provider }));
  let info = null;
  try { info = await checkDocument(m.link.uri); } catch (e) { info = { error: String(e.message || e) }; }
  if (info && info.web) {
    add(info.exists, t('chkExists'), '', t('chkExistsHint'));
  } else if (info) {
    add(!!info.permRead, t('chkPermission'), info.permWrite ? t('chkReadWrite') : (info.permRead ? t('chkReadOnly') : ''), t('chkPermissionHint'));
    add(!!info.exists, t('chkExists'), info.exists ? (info.name || '') + (info.lastModified ? ' · ' + fmtDateTime(info.lastModified) : '') : (info.queryError || ''), t('chkExistsHint'));
    add(!!info.readable, t('chkReadable'), info.readError || '', t('chkReadableHint'));
    if (info.exists) add(info.writable !== false, t('chkWritable'), '', t('chkWritableHint'));
  }
  // sadržaj: je li to ova tablica
  let contentOk = false, detail = '';
  try {
    const txt = await readDocument(m.link.uri);
    if (!txt || !txt.trim()) { contentOk = true; detail = t('chkEmptyFile'); }
    else { const r = normalizeBudget(JSON.parse(txt)); contentOk = r.id === b.id; detail = contentOk ? r.entries.length + ' ' + t('entriesWord') : t('chkOtherTable', { n: r.name }); }
  } catch (e) { detail = String(e.message || e); }
  add(contentOk, t('chkContent'), detail, t('chkContentHint'));
  return showSteps(b, steps);
}

async function showSteps(b, steps) {
  const firstBad = steps.findIndex((s) => !s.ok);
  const body = '<div class="chk-list">' + steps.map((s, i) => '<div class="chk ' + (s.ok ? 'ok' : (i === firstBad ? 'bad' : 'skip')) + '">' +
    '<span class="chk-ic">' + (s.ok ? '✓' : '✗') + '</span><div><b>' + esc(s.label) + '</b>' + (s.detail ? '<small>' + esc(s.detail) + '</small>' : '') +
    (!s.ok && i === firstBad && s.hint ? '<p class="chk-hint">' + esc(s.hint) + '</p>' : '') + '</div></div>').join('') + '</div>' +
    '<p class="dlg-text"><b>' + esc(firstBad < 0 ? t('chkAllOk') : t('chkStopsAt', { s: steps[firstBad].label })) + '</b></p>';
  const v = await sheet({
    title: t('checkAccess'), body,
    actions: firstBad < 0 ? [{ label: t('retry'), value: 'retry', cls: 'primary' }] : [{ label: t('close'), value: null }, { label: t('saveNewLocation'), value: 'new', cls: 'primary' }],
  });
  if (v === 'retry') { const r = await pushCloud(b.id); toast(t(r.ok ? 'syncOk' : 'syncFailShort')); }
  if (v === 'new') await linkCreate(b);
  app.rerender();
}
