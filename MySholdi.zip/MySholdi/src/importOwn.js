// "Prebaci svoju tablicu": upute + prompt za AI alat (ChatGPT, Claude, Gemini…) koji postojeću
// tablicu pretvori u MySholdi format; rezultat se zalijepi ovdje ili učita kao .json datoteka
import { state } from './state.js';
import { t, getLang } from './i18n.js';
import { esc } from './util.js';
import { icon } from './icons.js';
import { normalizeBudget, fromLegacy, FORMAT } from './model.js';
import { writeBudget } from './storage.js';
import { sheet, toast } from './ui.js';
import { importFromFile } from './cloud.js';
import { app } from './app.js';

export function aiPrompt() {
  const y = new Date().getFullYear();
  if (getLang() === 'en') return `Convert my income and expense spreadsheet (attached / below) into JSON for the MojiSholdi app. Return ONLY the JSON, no explanation, in exactly this shape:

{
  "format": "${FORMAT}",
  "name": "My sheet",
  "year": ${y},
  "income": [
    { "name": "Income title", "items": [ { "name": "Subtitle", "vals": [12 numbers: January … December] } ] }
  ],
  "expense": [
    { "name": "Expense title (e.g. Housing)", "items": [ { "name": "Subtitle (e.g. Utilities)", "vals": [12 numbers] } ] }
  ],
  "net": {
    "periods": ["March", "June", "September", "December"],
    "assets": [ { "name": "Asset", "vals": [4 numbers] } ],
    "liabilities": [ { "name": "Debt", "vals": [4 numbers] } ]
  }
}

Rules:
- "vals" has exactly 12 values (January–December); an empty month is null; numbers use a decimal point, no currency or spaces (e.g. 1234.5).
- Keep the titles (categories) and subtitles (rows) as in my spreadsheet. If it has no titles, group the rows into sensible titles (Housing, Food and drinks, Transport…).
- If a cell contains a formula or a sum (e.g. =9600+5000), write the calculated value.
- Do NOT copy "Total", "Average" and other calculated rows – the app calculates them.
- If there is no net-worth data, leave "assets" and "liabilities" as empty lists.
- If the spreadsheet has several years, make a separate JSON for each year.
- Give me the result as a downloadable file MojiSholdi.json (or as a single JSON code block).`;
  return `Pretvori moju tablicu prihoda i rashoda (u prilogu / ispod) u JSON za aplikaciju MojiSholdi. Vrati SAMO JSON, bez objašnjenja, točno u ovom obliku:

{
  "format": "${FORMAT}",
  "name": "Moja tablica",
  "year": ${y},
  "income": [
    { "name": "Naslov prihoda", "items": [ { "name": "Podnaslov", "vals": [12 brojeva: siječanj … prosinac] } ] }
  ],
  "expense": [
    { "name": "Naslov rashoda (npr. Stanovanje)", "items": [ { "name": "Podnaslov (npr. Režije)", "vals": [12 brojeva] } ] }
  ],
  "net": {
    "periods": ["Ožujak", "Lipanj", "Rujan", "Prosinac"],
    "assets": [ { "name": "Stavka imovine", "vals": [4 broja] } ],
    "liabilities": [ { "name": "Dug", "vals": [4 broja] } ]
  }
}

Pravila:
- "vals" ima točno 12 vrijednosti (siječanj–prosinac); prazan mjesec je null; brojevi s decimalnom točkom, bez valute i razmaka (npr. 1234.5).
- Naslove (kategorije) i podnaslove (retke) zadrži kao u mojoj tablici. Ako tablica nema naslove, grupiraj retke u smislene naslove (Stanovanje, Hrana i piće, Prijevoz…).
- Ako je u ćeliji formula ili zbroj (npr. =9600+5000), upiši izračunatu vrijednost.
- Retke "Ukupno", "Prosjek" i ostale izračunate retke NE prepisuj – aplikacija ih računa sama.
- Ako nema podataka o neto imovini, ostavi "assets" i "liabilities" kao prazne liste.
- Ako tablica ima više godina, napravi zaseban JSON za svaku godinu.
- Rezultat mi daj kao datoteku MojiSholdi.json za preuzimanje (ili kao jedan JSON blok koda).`;
}

// Izdvajanje JSON-a iz teksta koji je vratio AI (može biti u ```json blokovima)
export function extractJson(text) {
  let s = String(text || '').trim();
  const fence = s.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fence) s = fence[1];
  const a = s.indexOf('{'), b = s.lastIndexOf('}');
  if (a < 0 || b < a) throw new Error('nojson');
  return JSON.parse(s.slice(a, b + 1));
}

async function importParsed(data) {
  let b;
  if (data && data.prihodi && data.rashodi && data.imovina) b = fromLegacy(data, t('importedSheet'));
  else b = normalizeBudget({ ...data, format: FORMAT, id: undefined, entries: [] });
  let name = b.name || t('importedSheet'), n = 2;
  while (state.index.some((x) => x.name.toLowerCase() === name.toLowerCase())) name = b.name + ' (' + n++ + ')';
  b.name = name;
  await writeBudget(b);
  toast(t('imported', { n: b.name }));
  await app.openBudget(b.id);
}

export async function importOwnDialog() {
  const steps = t('importOwnSteps').split('|').map((s) => '<li>' + esc(s) + '</li>').join('');
  await sheet({
    title: t('importOwnTitle'), wide: true, cls: 'import-own-sheet',
    body: '<p class="dlg-text">' + esc(t('importOwnIntro')) + '</p><ol class="steps">' + steps + '</ol>' +
      '<label class="fld-label">' + esc(t('promptLabel')) + '</label><textarea class="fld prompt-box" id="io-prompt" readonly rows="8">' + esc(aiPrompt()) + '</textarea>' +
      '<button class="btn block primary" id="io-copy">' + icon('copy') + esc(t('copyPrompt')) + '</button>' +
      '<h4 class="sec-title">' + esc(t('importResult')) + '</h4>' +
      '<textarea class="fld paste-box" id="io-json" rows="5" placeholder="' + esc(t('pasteJsonHere')) + '"></textarea><div class="fld-err" id="io-err"></div>' +
      '<div class="w-btns"><button class="btn primary" id="io-import">' + icon('download') + esc(t('importPasted')) + '</button>' +
      '<button class="btn" id="io-file">' + icon('folder') + esc(t('importJsonFile')) + '</button></div>' +
      '<p class="muted small">' + esc(t('importOwnNote')) + '</p>',
    actions: [{ label: t('close'), value: null }],
    onMount: (el, done) => {
      el.querySelector('#io-copy').onclick = async () => {
        const txt = aiPrompt();
        try { await navigator.clipboard.writeText(txt); toast(t('promptCopied')); }
        catch (e) { const ta = el.querySelector('#io-prompt'); ta.focus(); ta.select(); try { document.execCommand('copy'); toast(t('promptCopied')); } catch (e2) { toast(t('selectAndCopy')); } }
      };
      el.querySelector('#io-import').onclick = async () => {
        const err = el.querySelector('#io-err'); err.textContent = '';
        let data;
        try { data = extractJson(el.querySelector('#io-json').value); } catch (e) { err.textContent = t('errPasteJson'); return; }
        try { done(null); await importParsed(data); } catch (e) { toast(t('errNotBudget'), { kind: 'bad' }); }
      };
      el.querySelector('#io-file').onclick = async () => { done(null); const b = await importFromFile(); if (b) await app.openBudget(b.id); };
    },
  });
}
