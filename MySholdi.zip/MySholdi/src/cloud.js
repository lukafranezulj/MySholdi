// Povezivanje tablica s datotekama u oblaku (Google Drive, Dropbox, OneDrive), na vlastitom serveru (WebDAV) ili lokalno
import { APP_NAME } from './config.js';
import { state } from './state.js';
import { createDocument, openDocument, releaseDocument, exportCopy, fsaSupported, isNative } from './native.js';
import { writeBudget, saveMeta, writeBase, deleteBase, saveSettings } from './storage.js';
import { metaOf, pushCloud } from './sync.js';
import { normalizeBudget, fromLegacy, FORMAT } from './model.js';
import { sheet, toast } from './ui.js';
import { t } from './i18n.js';
import { esc, uid } from './util.js';

// Prepoznavanje pružatelja iz URI-ja (content://<authority>/...)
export function providerOf(uri) {
  const u = String(uri || '');
  if (u.startsWith('web:')) return t('provWeb');
  if (u.startsWith('fsa:')) return t('provPc');
  if (u.startsWith('srv:')) { const id = u.slice(4).split(':')[0]; const sv = (state.settings.servers || []).find((x) => x.id === id); return t('provServer') + (sv ? ' · ' + sv.name : ''); }
  if (/com\.google\.android\.apps\.docs/.test(u)) return 'Google Drive';
  if (/dropbox/i.test(u)) return 'Dropbox';
  if (/skydrive|onedrive/i.test(u)) return 'OneDrive';
  if (/nextcloud|owncloud/i.test(u)) return 'Nextcloud';
  if (/mega/i.test(u)) return 'MEGA';
  if (/externalstorage/.test(u)) return t('provLocal');
  if (/providers\.downloads/.test(u)) return t('provDownloads');
  return t('provOther');
}
export const fileNameFor = (b) => (APP_NAME + ' - ' + b.name).replace(/[\\/:*?"<>|]/g, '_') + '.json';

// iCloud na Androidu: Apple ne daje pristup iCloud Driveu drugim aplikacijama, pa se objašnjavaju mogućnosti
export async function icloudAndroid(b) {
  const v = await sheet({
    title: 'iCloud Drive', cls: 'info-sheet', body: '<div class="info-body">' + t('icloudAndroidHtml') + '</div>',
    actions: b ? [{ label: t('close'), value: null }, { label: t('exportCopy'), value: 'export', cls: 'primary' }] : [{ label: t('close'), value: null, cls: 'primary' }],
  });
  if (v === 'export' && b) await exportBudget(b);
}

// Odabir oblaka prije prozora za odabir datoteke:
//  - Android: Google Drive / Dropbox / OneDrive / mobitel (sustavni izbornik) ili iCloud (upute)
//  - preglednik na računalu (Chrome, Edge): upute kako doći do mape Google Drivea, iClouda, Dropboxa, OneDrivea
//  - preglednik bez pristupa datotekama (Safari na iPhoneu/iPadu, Firefox): učitava se kopija, sprema se izvozom
// Vraća 'pick' (sustavni izbornik / datoteka), 'server' (vlastiti server) ili false (odustano)
async function cloudChoice(save, b) {
  if (window.__testCloud) return 'pick';
  const srvAct = { label: '🖥 ' + t('ownServer'), value: 'server' };
  if (isNative) {
    const v = await sheet({
      title: t(save ? 'cloudSaveTitle' : 'cloudOpenTitle'), cls: 'menu-sheet', body: '<p class="dlg-text">' + esc(t('cloudChoiceText')) + '</p>',
      actions: [{ label: t('cloudGdOther'), value: 'pick', cls: 'primary' }, srvAct, { label: 'iCloud', value: 'icloud' }, { label: t('cancel'), value: null }],
    });
    if (v === 'icloud') { await icloudAndroid(b); return false; }
    return v === 'pick' || v === 'server' ? v : false;
  }
  const off = (el) => { if (el.querySelector('#wp-off') && el.querySelector('#wp-off').checked) { state.settings.webPickHintOff = true; saveSettings(); } };
  const fsa = fsaSupported();
  const hasSrv = (state.settings.servers || []).length > 0;
  if (!save) {
    if (state.settings.webPickHintOff) {
      if (!hasSrv) return 'pick';
      const v = await sheet({ title: t('cloudOpenTitle'), cls: 'menu-sheet', body: '', actions: [{ label: t('chooseFile'), value: 'pick', cls: 'primary' }, srvAct, { label: t('cancel'), value: null }] });
      return v || false;
    }
    const v = await sheet({
      title: t('webOpenTitle'), cls: 'info-sheet',
      body: '<div class="info-body">' + hintBody(false, fsa) + '</div><label class="chk-line"><input type="checkbox" id="wp-off"> ' + esc(t('dontShowAgain')) + '</label>',
      actions: [{ label: t('cancel'), value: null }, srvAct, { label: t('chooseFile'), value: 'pick', cls: 'primary' }],
      onAction: (v, el) => { if (v) off(el); return v; },
    });
    return v || false;
  }
  // spremanje: Chrome/Edge na računalu biraju mjesto; ostali preglednici ne mogu trajno povezati datoteku –
  // nudi se izvoz kopije ili vlastiti server (on radi u svakom pregledniku)
  const v = await sheet({
    title: t('webSaveTitle'), cls: 'info-sheet', body: '<div class="info-body">' + hintBody(true, fsa) + '</div>',
    actions: [{ label: t('cancel'), value: null }, srvAct, fsa ? { label: t('chooseLocation'), value: 'pick', cls: 'primary' } : { label: t('exportCopy'), value: 'export', cls: 'primary' }],
  });
  if (v === 'export' && b) await exportBudget(b);
  return v === 'pick' || v === 'server' ? v : false;
}

// Na kojem je uređaju web inačica otvorena (upute za taj uređaj idu prve)
function platformInfo() {
  const ua = navigator.userAgent || '';
  const plat = /Android/i.test(ua) ? 'android' : (/iPhone|iPad|iPod/i.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1)) ? 'ios' : 'pc';
  return { plat, brave: !!(navigator.brave && navigator.brave.isBrave) };
}
// Upute za učitavanje/spremanje: računalo, Android, iPhone/iPad
function hintBody(save, fsa) {
  const { plat, brave } = platformInfo();
  const pc = t(save ? (fsa ? 'hPcSaveFsa' : 'hPcSaveBasic') : (fsa ? 'hPcOpenFsa' : 'hPcOpenBasic')) + (brave && !fsa ? t('hBrave') : '');
  const sec = { pc, android: t(save ? 'hAndroidSave' : 'hAndroidOpen'), ios: t(save ? 'hIosSave' : 'hIosOpen') };
  const title = { pc: t('platPc'), android: t('platAndroid'), ios: 'iPhone / iPad' };
  const order = [plat, ...['pc', 'android', 'ios'].filter((x) => x !== plat)];
  return order.map((k, i) => '<div class="plat-sec' + (i === 0 ? ' cur' : '') + '"><h4>' + esc(title[k]) + (i === 0 ? ' <small>' + esc(t('thisDevice')) + '</small>' : '') + '</h4>' + sec[k] + '</div>').join('') +
    (save ? '' : '<p class="muted small">' + t('hNoInstall') + '</p>');
}

// Stvaranje nove datoteke na odabranom mjestu i povezivanje
// direct: odmah sustavni izbornik (bez pitanja); via: 'server' – odmah vlastiti server
export async function linkCreate(b, { direct = false, via = null } = {}) {
  try {
    const how = via || (direct ? 'pick' : await cloudChoice(true, b));
    if (!how) return false;
    let r;
    if (how === 'server') { const { serverSaveFlow } = await import('./serverUI.js'); r = await serverSaveFlow(fileNameFor(b)); }
    else r = await createDocument(fileNameFor(b));
    if (!r || !r.uri) return false;
    const m = metaOf(b.id);
    if (m.link && m.link.uri !== r.uri) releaseDocument(m.link.uri);
    m.link = { uri: r.uri, name: r.name || fileNameFor(b), provider: providerOf(r.uri) };
    m.dirty = true; await saveMeta();
    const res = await pushCloud(b.id);
    toast(res.ok ? t('linkedOk', { p: m.link.provider }) : t('syncFailShort'));
    return true;
  } catch (e) {
    const msg = String(e && e.message);
    if (/nolink/.test(msg)) toast(t('webNoFileLink'));
    else if (!/cancel|abort/i.test(msg)) toast(t('errFile') + ': ' + (e.message || e));
    return false;
  }
}
// Ponovno povezivanje iste datoteke (nakon ponovne instalacije ili izgubljenog dopuštenja):
// izbornik se otvara u mapi stare datoteke; dopušta se samo datoteka iste tablice (ili prazna)
export async function relinkFile(b) {
  const m = metaOf(b.id);
  let r;
  try { r = await openDocument(m.link ? { initialUri: m.link.uri } : {}); }
  catch (e) { if (!/cancel|abort/i.test(String(e && e.message))) toast(t('errFile')); return false; }
  if (!r) return false;
  if (r.data && r.data.trim()) {
    let other;
    try { other = normalizeBudget(JSON.parse(r.data)); } catch (e) { toast(t('errNotBudget')); return false; }
    if (other.id !== b.id) { toast(t('relinkOther', { n: other.name }), { kind: 'bad' }); return false; }
  }
  if (m.link && m.link.uri !== r.uri) releaseDocument(m.link.uri);
  m.link = { uri: r.uri, name: r.name || (m.link && m.link.name) || fileNameFor(b), provider: providerOf(r.uri) };
  m.dirty = true; await saveMeta();
  const res = await pushCloud(b.id);   // pročita datoteku, spoji izmjene i zapiše
  toast(res.ok ? t('relinkedOk', { p: m.link.provider }) : t('syncFailShort'));
  return true;
}
export async function unlink(id) {
  const m = metaOf(id);
  if (m.link) releaseDocument(m.link.uri);
  m.link = null; m.pending = false; m.dirty = false;
  await saveMeta();
  await deleteBase(id);
}

// Učitavanje tablice iz datoteke (npr. na novom mobitelu)
export async function importFromFile({ shared = false } = {}) {
  let r;
  const how = await cloudChoice(false);
  if (!how) return null;
  if (how === 'server') { const { serverOpenFlow } = await import('./serverUI.js'); r = await serverOpenFlow(); }
  else { try { r = await openDocument(); } catch (e) { if (!/cancel|abort/i.test(String(e && e.message))) toast(t('errFile')); return null; } }
  if (!r) return null;
  let data;
  try { data = JSON.parse(r.data); } catch (e) { toast(t('errNotBudget')); return null; }
  let b, legacy = false;
  try {
    if (data && data.prihodi && data.rashodi && data.imovina) { legacy = true; b = fromLegacy(data, (r.name || 'Tablica').replace(/\.json$/i, '')); }
    else b = normalizeBudget(data);
  } catch (e) { toast(t('errNotBudget')); return null; }

  const existing = state.index.find((x) => x.id === b.id);
  if (existing) {
    const ch = await sheet({
      title: t('importExistsTitle'),
      body: '<p class="dlg-text">' + esc(t('importExists', { n: existing.name })) + '</p>',
      actions: [{ label: t('cancel'), value: null }, { label: t('keepBoth'), value: 'both' }, { label: t('replace'), value: 'replace', cls: 'primary' }],
    });
    if (!ch) return null;
    if (ch === 'both') { b.id = uid('b'); legacy = true; }
  }
  // jedinstveno ime
  let name = b.name, n = 2;
  while (state.index.some((x) => x.id !== b.id && x.name.toLowerCase() === name.toLowerCase())) name = b.name + ' (' + n++ + ')';
  b.name = name;
  if (shared) b.shared = true;
  await writeBudget(b);
  const m = metaOf(b.id);
  // datoteka MySholdi formata postaje mjesto sinkronizacije (ako nije kopija)
  if (!legacy && data.format === FORMAT && !String(r.uri).startsWith('webfile:')) {
    m.link = { uri: r.uri, name: r.name, provider: providerOf(r.uri) };
    m.pending = false; m.dirty = false; m.lastCloudAt = Date.now();
    await writeBase(b);   // zajednička polazna verzija za spajanje izmjena
  }
  await saveMeta();
  toast(t('imported', { n: b.name }));
  return b;
}

export async function exportBudget(b) {
  try { await exportCopy(fileNameFor(b), JSON.stringify(b, null, 1)); toast(t('exported')); }
  catch (e) { if (!/cancel/i.test(String(e && e.message))) toast(t('errFile')); }
}
