# MojiSholdi server

Mali WebDAV server za spremanje i sinkronizaciju tablica MojiSholdi na vlastitom računalu, Raspberry Piju ili NAS-u. Ne treba nikakav dodatni paket, samo **Node.js 18+** (nodejs.org).

## Pokretanje

```bash
node mojisholdi-server.mjs --user luka --pass tajna
```

Server ispiše adresu, npr. `http://192.168.1.20:8090/`. Tu adresu, korisničko ime i lozinku upiši u aplikaciji: **Postavke → Vlastiti serveri → Dodaj server**. Zatim kod spremanja tablice odaberi **Vlastiti server**.

| Opcija | Značenje | Zadano |
|---|---|---|
| `--port` | port | 8090 |
| `--dir` | mapa s podacima | `./mojisholdi-podaci` |
| `--user`, `--pass` | prijava (obavezno izvan kućne mreže) | – |
| `--cert`, `--key` | https certifikat i ključ (PEM) | – |

Isto se može zadati varijablama `MS_PORT`, `MS_DIR`, `MS_USER`, `MS_PASS`, `MS_CERT`, `MS_KEY`.

## Savjeti

* **Kućna mreža:** mobitel i računalo moraju biti na istoj Wi-Fi mreži. Na Windowsu dopusti Node.js u vatrozidu.
* **Preko interneta:** proslijedi port na ruteru ili koristi VPN (npr. Tailscale, WireGuard). Preko interneta koristi **https** (`--cert`/`--key`, npr. Let's Encrypt).
* **Web inačica na https stranici** (github.io) može se spojiti samo na **https** server. Lokalna HTML datoteka može i na http.
* **Stalni rad:** na Linuxu/Raspberry Piju pokreni kao uslugu (systemd) ili s `pm2`; na Windowsu preko Planera zadataka pri pokretanju.
* **Zajednička tablica:** svi članovi dodaju isti server i odaberu istu datoteku. Aplikacija izmjene spaja, pa se ničiji unosi ne gube.
* **Sigurnosna kopija:** sve tablice su obične `.json` datoteke u mapi `--dir`.

Umjesto ovog servera može se koristiti bilo koji WebDAV: Nextcloud / ownCloud (`https://…/remote.php/dav/files/KORISNIK/`), Synology ili QNAP NAS (WebDAV u postavkama), Apache/nginx WebDAV, `rclone serve webdav`.
