#!/usr/bin/env node
// MojiSholdi server – mali WebDAV server za spremanje i sinkronizaciju tablica.
// Pokreće se na računalu, Raspberry Piju ili NAS-u s Node.js 18+ (bez dodatnih paketa):
//
//   node mojisholdi-server.mjs --user luka --pass tajna            (port 8090, mapa ./mojisholdi-podaci)
//   node mojisholdi-server.mjs --port 8090 --dir D:\MojiSholdi --user luka --pass tajna
//   node mojisholdi-server.mjs --cert cert.pem --key key.pem ...    (https)
//
// U aplikaciji: Postavke → Vlastiti serveri → Dodaj server → adresa koju server ispiše pri pokretanju.
// Podržano: GET, HEAD, PUT, DELETE, MKCOL, PROPFIND (Depth 0/1), OPTIONS; Basic prijava; CORS
// (i Private Network Access) za web inačicu; zapis datoteke je atomaran (privremena datoteka + preimenovanje).
import http from 'node:http';
import https from 'node:https';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';

// ---- postavke iz argumenata ili varijabli okruženja ----
const args = Object.fromEntries(process.argv.slice(2).reduce((a, x, i, arr) => (x.startsWith('--') ? [...a, [x.slice(2), arr[i + 1] && !arr[i + 1].startsWith('--') ? arr[i + 1] : 'true']] : a), []));
const PORT = +(args.port || process.env.MS_PORT || 8090);
const ROOT = path.resolve(args.dir || process.env.MS_DIR || './mojisholdi-podaci');
const USER = args.user || process.env.MS_USER || '';
const PASS = args.pass || process.env.MS_PASS || '';
const CERT = args.cert || process.env.MS_CERT, KEY = args.key || process.env.MS_KEY;
const MAX = 20 * 1024 * 1024; // najveća datoteka 20 MB

if (!USER || !PASS) {
  console.log('Upozorenje: bez --user i --pass server je dostupan svima u mreži.');
}
fs.mkdirSync(ROOT, { recursive: true });

// ---- pomoćne funkcije ----
const safeEq = (a, b) => { const x = Buffer.from(a), y = Buffer.from(b); return x.length === y.length && crypto.timingSafeEqual(x, y); };
function authorized(req) {
  if (!USER && !PASS) return true;
  const h = req.headers.authorization || '';
  if (!h.startsWith('Basic ')) return false;
  const [u, ...p] = Buffer.from(h.slice(6), 'base64').toString('utf8').split(':');
  return safeEq(u, USER) && safeEq(p.join(':'), PASS);
}
// put iz URL-a → put na disku (bez izlaska iz mape s podacima)
function resolvePath(urlPath) {
  let rel;
  try { rel = decodeURIComponent(urlPath.split('?')[0]); } catch (e) { return null; }
  const full = path.resolve(ROOT, '.' + path.posix.normalize('/' + rel));
  return full === ROOT || full.startsWith(ROOT + path.sep) ? full : null;
}
const xmlEsc = (s) => String(s).replace(/[<>&'"]/g, (c) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' }[c]));
const hrefOf = (full, isDir) => '/' + path.relative(ROOT, full).split(path.sep).filter(Boolean).map(encodeURIComponent).join('/') + (isDir && full !== ROOT ? '/' : '');
function propXml(full, st) {
  const isDir = st.isDirectory();
  return '<d:response><d:href>' + xmlEsc(hrefOf(full, isDir)) + '</d:href><d:propstat><d:prop>' +
    '<d:resourcetype>' + (isDir ? '<d:collection/>' : '') + '</d:resourcetype>' +
    (isDir ? '' : '<d:getcontentlength>' + st.size + '</d:getcontentlength><d:getcontenttype>application/json</d:getcontenttype>') +
    '<d:getlastmodified>' + st.mtime.toUTCString() + '</d:getlastmodified><d:getetag>"' + st.size.toString(16) + '-' + st.mtimeMs.toString(16) + '"</d:getetag>' +
    '</d:prop><d:status>HTTP/1.1 200 OK</d:status></d:propstat></d:response>';
}
function cors(req, res) {
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Methods', 'GET, HEAD, PUT, DELETE, MKCOL, PROPFIND, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type, Depth, Destination, Overwrite, If-Match, If-None-Match');
  res.setHeader('Access-Control-Expose-Headers', 'ETag, Last-Modified, DAV');
  res.setHeader('Access-Control-Max-Age', '600');
  // Chrome: web stranica (npr. github.io) smije pristupiti serveru u kućnoj mreži
  if (req.headers['access-control-request-private-network']) res.setHeader('Access-Control-Allow-Private-Network', 'true');
  res.setHeader('DAV', '1');
}
const send = (res, code, body = '', type = 'text/plain; charset=utf-8') => { res.writeHead(code, { 'Content-Type': type }); res.end(body); };
const readBody = (req) => new Promise((ok, fail) => {
  const chunks = []; let size = 0;
  req.on('data', (c) => { size += c.length; if (size > MAX) { fail(new Error('too large')); req.destroy(); } else chunks.push(c); });
  req.on('end', () => ok(Buffer.concat(chunks))); req.on('error', fail);
});

// ---- obrada zahtjeva ----
async function handle(req, res) {
  cors(req, res);
  if (req.method === 'OPTIONS') return send(res, 204);
  if (!authorized(req)) { res.setHeader('WWW-Authenticate', 'Basic realm="MojiSholdi", charset="UTF-8"'); return send(res, 401, 'Prijava je potrebna'); }
  const full = resolvePath(req.url);
  if (!full) return send(res, 403, 'Zabranjeno');
  let st = null; try { st = await fsp.stat(full); } catch (e) { }
  switch (req.method) {
    case 'GET': case 'HEAD': {
      if (!st) return send(res, 404, 'Nema datoteke');
      if (st.isDirectory()) return send(res, 200, 'MojiSholdi server radi.\n');
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': st.size, 'Last-Modified': st.mtime.toUTCString(), ETag: '"' + st.size.toString(16) + '-' + st.mtimeMs.toString(16) + '"', 'Cache-Control': 'no-store' });
      if (req.method === 'HEAD') return res.end();
      return fs.createReadStream(full).pipe(res);
    }
    case 'PUT': {
      if (st && st.isDirectory()) return send(res, 405, 'To je mapa');
      try { await fsp.access(path.dirname(full)); } catch (e) { return send(res, 409, 'Mapa ne postoji'); }
      const body = await readBody(req);
      const tmp = full + '.tmp-' + process.pid + '-' + Date.now();
      await fsp.writeFile(tmp, body); await fsp.rename(tmp, full);
      return send(res, st ? 204 : 201);
    }
    case 'DELETE': {
      if (!st) return send(res, 404);
      if (full === ROOT) return send(res, 403);
      await fsp.rm(full, { recursive: true, force: true });
      return send(res, 204);
    }
    case 'MKCOL': {
      if (st) return send(res, 405, 'Već postoji');
      try { await fsp.access(path.dirname(full)); } catch (e) { return send(res, 409, 'Nadređena mapa ne postoji'); }
      await fsp.mkdir(full); return send(res, 201);
    }
    case 'PROPFIND': {
      await readBody(req).catch(() => null);
      if (!st) return send(res, 404);
      const depth = String(req.headers.depth ?? '1');
      let xml = '<?xml version="1.0" encoding="utf-8"?><d:multistatus xmlns:d="DAV:">' + propXml(full, st);
      if (st.isDirectory() && depth !== '0') {
        for (const name of await fsp.readdir(full)) {
          if (name.startsWith('.') || name.includes('.tmp-')) continue;
          try { const p = path.join(full, name); xml += propXml(p, await fsp.stat(p)); } catch (e) { }
        }
      }
      return send(res, 207, xml + '</d:multistatus>', 'application/xml; charset=utf-8');
    }
    default: return send(res, 405, 'Nepodržana metoda');
  }
}

const server = CERT && KEY
  ? https.createServer({ cert: fs.readFileSync(CERT), key: fs.readFileSync(KEY) }, (q, r) => handle(q, r).catch((e) => send(r, 500, String(e.message))))
  : http.createServer((q, r) => handle(q, r).catch((e) => send(r, 500, String(e.message))));
server.listen(PORT, () => {
  const proto = CERT && KEY ? 'https' : 'http';
  const ips = Object.values(os.networkInterfaces()).flat().filter((i) => i && i.family === 'IPv4' && !i.internal).map((i) => i.address);
  console.log('MojiSholdi server radi. Podaci: ' + ROOT);
  console.log('Adresa za aplikaciju (Postavke → Vlastiti serveri):');
  (ips.length ? ips : ['localhost']).forEach((ip) => console.log('  ' + proto + '://' + ip + ':' + PORT + '/'));
  if (USER) console.log('Korisnik: ' + USER);
});
