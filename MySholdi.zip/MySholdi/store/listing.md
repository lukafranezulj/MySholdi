# Tekstovi za Google Play

## Hrvatski

**Naziv:** MojiSholdi

**Kratki opis (≤ 80 znakova):**
Prihodi, rashodi i neto imovina na jednom mjestu – sinkronizacija s Driveom.

**Puni opis:**
MojiSholdi je jednostavna aplikacija za praćenje osobnih financija po mjesecima, nastala po uzoru na provjerenu tablicu prihoda i rashoda.

• Brzi unos: pritisni +, odaberi rashod ili prihod, mjesec, iznos i kategoriju – iznos se odmah pribraja.
• Naslovna s pregledom mjeseca i popisom zadnjih unosa (datum, vrijeme, iznos, kategorija); svaki unos možeš urediti ili obrisati.
• Prihodi i rashodi po naslovima i podnaslovima – pregled jednog mjeseca ili svih mjeseci kao u tablici.
• Kategorije su intuitivne i potpuno prilagodljive: preimenuj, dodaj ili obriši naslove i podnaslove.
• Grafikoni za svaki naslov i podnaslov, udio kategorija i sažetak godine sa statistikom.
• Neto imovina po kvartalima i „bogatstvo“ – koliko mjeseci možeš živjeti od svoje imovine.
• Kalkulator kredita: po rati, po iznosu ili po trajanju, s inflacijom (stvarni trošak u današnjem novcu), naknadom i otplatnim planom.
• Widgeti za početni zaslon: trenutni mjesec, grafikon i brzi unos – sam biraš izgled.
• Više proračunskih tablica (npr. po godinama) i primjer tablice s prosjekom za Hrvatsku.
• Zajedničke tablice: cijelo kućanstvo upisuje u istu tablicu na Google Driveu ili Dropboxu.
• Custom grafovi – usporedi kategorije i godine.
• Zaključavanje PIN-om i otiskom prsta.
• Spremanje na Google Drive, Dropbox, OneDrive ili lokalno; automatska sinkronizacija 5 s nakon izmjene, a bez interneta se sve sprema lokalno i šalje kasnije.
• Na novom mobitelu samo učitaj svoju datoteku i nastavi gdje si stao.
• Koš za smeće – obrisano se čuva 30 dana.
• Hrvatski i engleski jezik, valuta po izboru (zadano EUR).

Bez oglasa, bez registracije i bez prikupljanja podataka – tvoje financije ostaju tvoje.

## English

**Name:** MojiSholdi

**Short description (≤ 80 chars):**
Income, expenses and net worth in one place – syncs with Google Drive.

**Full description:**
MojiSholdi is a simple personal finance app for tracking money month by month, modelled on a proven income and expense spreadsheet.

• Quick add: tap +, choose expense or income, month, amount and category – it is added instantly.
• Home screen with the month overview and your latest entries (date, time, amount, category); edit or delete any entry.
• Income and expenses by titles and subtitles – view one month or all months like a spreadsheet.
• Intuitive, fully customizable categories: rename, add or delete titles and subtitles.
• Charts for every title and subtitle, category shares and a yearly summary with statistics.
• Quarterly net worth and "wealth" – how many months you could live off your assets.
• Loan calculator: by payment, by amount or by term, with inflation (real cost in today's money), fees and an amortization plan.
• Home screen widgets: current month, chart and quick add – with your own design.
• Multiple budget sheets (e.g. one per year) and an example sheet.
• Shared sheets: the whole household adds to the same sheet on Google Drive or Dropbox.
• Custom graphs – compare categories and years.
• Lock with PIN and fingerprint.
• Save to Google Drive, Dropbox, OneDrive or locally; automatic sync 5 s after a change, and when offline everything is kept locally and uploaded later.
• On a new phone just open your file and continue where you left off.
• Trash – deleted items are kept for 30 days.
• Croatian and English, any currency (EUR by default).

No ads, no sign-up and no data collection – your finances stay yours.
