# Tekstovi za Google Play

## Hrvatski

**Naziv:** MojiSholdi

**Kratki opis (≤ 80 znakova):**
Prihodi, rashodi i imovina – sinkronizacija s Driveom ili vlastitim serverom.

**Puni opis:**
MojiSholdi je jednostavna aplikacija za praćenje osobnih financija po mjesecima, nastala po uzoru na provjerenu tablicu prihoda i rashoda.

• Brzi unos: pritisni +, odaberi rashod ili prihod, mjesec, iznos i kategoriju – iznos se odmah pribraja.
• Naslovna s pregledom mjeseca i popisom zadnjih unosa (datum, vrijeme, iznos, kategorija); svaki unos možeš urediti ili obrisati.
• Prihodi i rashodi po naslovima i podnaslovima – pregled jednog mjeseca ili svih mjeseci kao u tablici.
• Kategorije su intuitivne i potpuno prilagodljive: preimenuj, dodaj ili obriši naslove i podnaslove.
• Grafikoni za svaki naslov i podnaslov, udio kategorija i sažetak godine sa statistikom.
• Neto imovina po kvartalima i „bogatstvo“ – koliko mjeseci možeš živjeti od svoje imovine.
• Kalkulator kredita: po rati, po iznosu ili po trajanju, s inflacijom (stvarni trošak u današnjem novcu), naknadom i otplatnim planom.
• Widgeti za početni zaslon: trenutni mjesec, rashodi ovog mjeseca (pie graf), grafikon i brzi unos – sam biraš izgled.
• Više proračunskih tablica (npr. po godinama) i primjer tablice s prosjekom za Hrvatsku.
• Zajedničke tablice: cijelo kućanstvo upisuje u istu tablicu na Google Driveu, Dropboxu ili vlastitom serveru – izmjene se spajaju, ničiji unosi se ne gube.
• Custom grafovi – usporedi kategorije, mjesece i godine (i kad se naslovi u različitim godinama zovu drugačije), preko cijelog zaslona.
• Zaključavanje PIN-om i otiskom prsta.
• Spremanje na Google Drive, Dropbox, OneDrive, vlastiti server (Nextcloud, NAS, WebDAV) ili lokalno; automatska sinkronizacija, a bez interneta se sve sprema lokalno i šalje kasnije.
• Svijetla i tamna tema te animirana pozadina kartica.
• Web inačica za računalo i tablet.
• Na novom mobitelu samo učitaj svoju datoteku i nastavi gdje si stao.
• Koš za smeće – obrisano se čuva 30 dana.
• Hrvatski i engleski jezik, valuta po izboru (zadano EUR).

Bez oglasa, bez registracije i bez prikupljanja podataka – tvoje financije ostaju tvoje.

## English

**Name:** MojiSholdi

**Short description (≤ 80 chars):**
Income, expenses and net worth – sync with Google Drive or your own server.

**Full description:**
MojiSholdi is a simple personal finance app for tracking money month by month, modelled on a proven income and expense spreadsheet.

• Quick add: tap +, choose expense or income, month, amount and category – it is added instantly.
• Home screen with the month overview and your latest entries (date, time, amount, category); edit or delete any entry.
• Income and expenses by titles and subtitles – view one month or all months like a spreadsheet.
• Intuitive, fully customizable categories: rename, add or delete titles and subtitles.
• Charts for every title and subtitle, category shares and a yearly summary with statistics.
• Quarterly net worth and "wealth" – how many months you could live off your assets.
• Loan calculator: by payment, by amount or by term, with inflation (real cost in today's money), fees and an amortization plan.
• Home screen widgets: current month, this month's expenses (pie chart), chart and quick add – with your own design.
• Multiple budget sheets (e.g. one per year) and an example sheet.
• Shared sheets: the whole household adds to the same sheet on Google Drive, Dropbox or your own server – changes are merged and nobody's entries are lost.
• Custom graphs – compare categories, months and years (even when titles are named differently in different years), in full screen.
• Lock with PIN and fingerprint.
• Save to Google Drive, Dropbox, OneDrive, your own server (Nextcloud, NAS, WebDAV) or locally; automatic sync, and when offline everything is kept locally and uploaded later.
• Light and dark theme and an animated background.
• Web version for computers and tablets.
• On a new phone just open your file and continue where you left off.
• Trash – deleted items are kept for 30 days.
• Croatian and English, any currency (EUR by default).

No ads, no sign-up and no data collection – your finances stay yours.

## Bilješke izdanja / Release notes (1.5.0, ≤ 500 znakova)

**hr-HR**
Novo ime: MojiSholdi. Vlastiti server (Nextcloud, NAS, WebDAV) za osobne i zajedničke tablice. Grafovi po godinama s odabirom točaka iz svake tablice. Widget „Rashodi ovog mjeseca“ (pie). Svijetla/tamna tema i animirana pozadina. Graf sažetka preko cijelog zaslona. Nakon ponovne instalacije aplikacija pamti gdje su bile datoteke.

**en-US**
New name: MojiSholdi. Your own server (Nextcloud, NAS, WebDAV) for personal and shared sheets. Year graphs with points picked from each sheet. "Expenses this month" pie widget. Light/dark theme and animated background. Full-screen summary chart. After reinstalling, the app remembers where your files were.
