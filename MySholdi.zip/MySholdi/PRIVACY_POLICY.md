# MojiSholdi – Pravila privatnosti / Privacy Policy

_Zadnje ažuriranje / Last updated: 25. 11. 2026._

## Hrvatski

**MojiSholdi** je aplikacija za praćenje osobnih financija. Razvojni programer ne prikuplja, ne pohranjuje i ne dijeli tvoje osobne podatke.

* **Gdje su podaci:** sve tablice (prihodi, rashodi, neto imovina), postavke i koš za smeće spremaju se samo na tvom uređaju, u privatnoj mapi aplikacije.
* **Oblak:** ako sam odabereš mjesto spremanja (npr. Google Drive, Dropbox, OneDrive ili mapu na uređaju), aplikacija preko Androidovog sustavnog izbornika datoteka zapisuje datoteku na to mjesto, u **tvoj** račun. Razvojni programer nema pristup tim datotekama. Na njih se primjenjuju pravila privatnosti odabranog pružatelja usluge.
* **Vlastiti server:** ako sam dodaš svoj server (WebDAV, npr. Nextcloud ili NAS), aplikacija tablice šalje izravno na taj server s korisničkim imenom i lozinkom koje si upisao. Lozinka se sprema samo na tvom uređaju. Razvojni programer nema pristup ni serveru ni podacima.
* **Sigurnosna kopija Androida:** ako je na uređaju uključena sigurnosna kopija Google računa, Android može kopirati podatke aplikacije u tvoj Google račun i vratiti ih nakon ponovne instalacije. To radi Android, a razvojni programer nema pristup kopiji.
* **Bez analitike i oglasa:** aplikacija ne sadrži oglase, alate za praćenje ni analitiku i ne šalje podatke razvojnom programeru ni trećim stranama.
* **Dopuštenja:** *Internet* i *stanje mreže* služe samo za sinkronizaciju s mjestom koje si odabrao (oblak ili vlastiti server). *Obavijesti* služe samo za upozorenje kad spremanje u oblak ne uspije. *Biometrija* služi samo za otključavanje aplikacije: provjeru obavlja Android, a aplikacija ne dobiva ni ne sprema biometrijske podatke.
* **Zajedničke tablice:** datoteku dijeliš ti preko svog Google Drivea ili Dropboxa. Ime koje upišeš u postavkama sprema se uz tvoje unose u toj datoteci i vide ga osobe s kojima je dijeliš.
* **Brisanje podataka:** podatke brišeš u aplikaciji (brisanje tablice, pražnjenje koša za smeće) ili deinstalacijom aplikacije. Datoteke koje si spremio u oblak brišeš u tom servisu.
* **Djeca:** aplikacija nije namijenjena djeci mlađoj od 13 godina.
* **Promjene:** izmjene ovih pravila objavit će se na ovoj stranici.
* **Kontakt:** lukafrane.zulj@gmail.com

## English

**MojiSholdi** is a personal finance app. The developer does not collect, store or share your personal data.

* **Where data is stored:** all sheets (income, expenses, net worth), settings and the trash are stored only on your device, in the app's private folder.
* **Cloud:** if you choose a save location (e.g. Google Drive, Dropbox, OneDrive or a device folder), the app writes a file there through Android's system file picker, into **your own** account. The developer has no access to these files; the chosen provider's privacy policy applies.
* **Own server:** if you add your own server (WebDAV, e.g. Nextcloud or a NAS), the app sends sheets directly to that server with the username and password you entered. The password is stored only on your device. The developer has no access to the server or the data.
* **Android backup:** if Google account backup is enabled on your device, Android may copy the app's data to your Google account and restore it after reinstalling. Android does this; the developer has no access to the backup.
* **No analytics or ads:** the app contains no ads, trackers or analytics and sends no data to the developer or third parties.
* **Permissions:** *Internet* and *network state* are used only for syncing to the location you chose (cloud or your own server); *notifications* only to warn you when a cloud save fails; *biometrics* only to unlock the app – Android performs the check and the app never receives or stores biometric data.
* **Shared sheets:** you share the file through your own Google Drive or Dropbox. The name you enter in settings is stored with your entries in that file and is visible to the people you share it with.
* **Deleting data:** delete data in the app (delete a sheet, empty the trash) or by uninstalling the app. Files you saved to a cloud service are deleted in that service.
* **Children:** the app is not directed at children under 13.
* **Changes:** updates to this policy will be published on this page.
* **Contact:** lukafrane.zulj@gmail.com
